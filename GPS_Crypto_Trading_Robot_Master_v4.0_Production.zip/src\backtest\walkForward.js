'use strict';

const Backtester = require('./engine');
const dataFeed = require('../market/dataFeed');
const logger = require('../utils/logger');

/**
 * Walk-Forward Validation Engine
 * Runs rolling calibration and test windows across historical data
 * to measure out-of-sample consistency and parameter degradation.
 */
class WalkForwardEngine {
  constructor(strategyConfig = {}, riskConfig = {}) {
    this.strategyConfig = strategyConfig;
    this.riskConfig = riskConfig;
  }

  /**
   * Run rolling walk-forward validation
   *
   * @param {string} symbol
   * @param {object} options - { windows: 3, maxCandles: 2000, trainRatio: 0.6 }
   */
  async run(symbol, options = {}) {
    const {
      windows = 3,
      maxCandles = 2000,
      trainRatio = 0.6,
    } = options;

    logger.info(`WALK-FORWARD: ${symbol} — fetching historical data for ${windows} rolling windows...`);

    const [candles4H, candles1H, candles15M] = await Promise.all([
      dataFeed.getHistoricalCandles(symbol, '4h', Math.min(maxCandles, 2000)),
      dataFeed.getHistoricalCandles(symbol, '1h', Math.min(maxCandles * 4, 5000)),
      dataFeed.getHistoricalCandles(symbol, '15m', Math.min(maxCandles * 16, 10000)),
    ]);

    if (!candles4H || candles4H.length < 150) {
      return {
        status: 'INCOMPLETE',
        reason: 'INSUFFICIENT HISTORICAL CANDLES: Need at least 150 4H candles for multi-window walk-forward validation',
        symbol,
      };
    }

    const total4H = candles4H.length;
    const windowResults = [];
    const stepSize = Math.floor(total4H / (windows + 1));
    const windowSpan = stepSize * 2;

    for (let w = 0; w < windows; w++) {
      const startIdx = w * stepSize;
      const endIdx = Math.min(total4H, startIdx + windowSpan);
      const window4H = candles4H.slice(startIdx, endIdx);

      const splitIdx = Math.floor(window4H.length * trainRatio);
      const train4H = window4H.slice(0, splitIdx);
      const test4H = window4H.slice(splitIdx);

      const tester = new Backtester(this.strategyConfig, this.riskConfig);

      const trainResult = tester._runOnCandles(symbol, train4H, candles1H, candles15M, `Window-${w + 1}-Train`);
      const testResult  = tester._runOnCandles(symbol, test4H,  candles1H, candles15M, `Window-${w + 1}-Test`);

      const trainDate = `${new Date(train4H[0].time).toISOString().slice(0, 10)} → ${new Date(train4H[train4H.length - 1].time).toISOString().slice(0, 10)}`;
      const testDate  = `${new Date(test4H[0].time).toISOString().slice(0, 10)} → ${new Date(test4H[test4H.length - 1].time).toISOString().slice(0, 10)}`;

      windowResults.push({
        window: w + 1,
        trainPeriod: trainDate,
        testPeriod: testDate,
        inSample: trainResult,
        outOfSample: testResult,
      });
    }

    // Summary Consistency Metrics
    const oosTrades = windowResults.reduce((s, w) => s + w.outOfSample.totalTrades, 0);
    const oosWins = windowResults.reduce((s, w) => s + w.outOfSample.wins, 0);
    const oosProfit = windowResults.reduce((s, w) => s + w.outOfSample.netProfit, 0);
    const avgWinRate = oosTrades > 0 ? parseFloat((oosWins / oosTrades * 100).toFixed(2)) : 0;

    const sampleNotice = oosTrades < 20
      ? 'STATISTICALLY INSUFFICIENT: Fewer than 20 out-of-sample trades across walk-forward windows. Results indicate robustness trends but require longer historical validation.'
      : 'ADEQUATE SAMPLE: Sufficient trades across walk-forward windows.';

    return {
      status: 'COMPLETE',
      symbol,
      windowsCount: windows,
      totalCandles4H: total4H,
      windows: windowResults,
      aggregateOOS: {
        totalTrades: oosTrades,
        wins: oosWins,
        winRate: avgWinRate,
        netProfit: parseFloat(oosProfit.toFixed(4)),
        sampleNotice,
      },
    };
  }
}

module.exports = WalkForwardEngine;
