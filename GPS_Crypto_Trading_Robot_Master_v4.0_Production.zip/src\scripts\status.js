'use strict';

const journal = require('../journal/store');
const config  = require('../config');

const state = {
  running:   journal.getState('robot_running'),
  mode:      journal.getState('robot_mode') || config.mode,
  markets:   journal.getState('market_count') || 0,
  scans:     journal.getState('scan_count') || 0,
  lastScan:  journal.getState('last_scan'),
  perf:      journal.getState('performance'),
  emergency: journal.getState('emergency_stop'),
};

console.log('\n═══ GPS TRADING ROBOT — STATUS ═══\n');
console.log(`  Running:      ${state.running ? 'YES' : 'NO'}`);
console.log(`  Mode:         ${state.mode}`);
console.log(`  Markets:      ${state.markets}`);
console.log(`  Scans run:    ${state.scans}`);
console.log(`  Last scan:    ${state.lastScan ? new Date(state.lastScan).toISOString() : 'never'}`);
console.log(`  Emergency:    ${state.emergency ? '⛔ YES' : 'No'}`);

if (state.perf) {
  console.log(`\n  ── Paper Performance ──`);
  console.log(`  Trades:     ${state.perf.totalTrades}`);
  console.log(`  Open:       ${state.perf.openTrades}`);
  console.log(`  Win Rate:   ${state.perf.winRate}%`);
  console.log(`  Net P&L:    ${state.perf.netPnl}`);
  console.log(`  Return:     ${state.perf.returnPct}%`);
}

// Recent signals
const signals = journal.getRecentSignals(5);
if (signals.length) {
  console.log(`\n  ── Recent Signals ──`);
  for (const s of signals) {
    console.log(`  ${s.symbol.padEnd(14)} ${(s.direction || '').padEnd(6)} ${s.score}/100  ${s.decision}`);
  }
}

process.exit(0);
