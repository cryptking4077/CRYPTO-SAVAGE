'use strict';

const { getAssetCluster } = require('../risk/engine');
const config = require('../config');

/**
 * Pure calculation engine for Dashboard metrics, trade economics, and analytics.
 */

/**
 * Calculate financial and risk metrics for a single position/trade
 */
function calculateTradeMetrics(trade, currentPrice = null, leverage = 10) {
  const entry = parseFloat(trade.entry || 0);
  const stopLoss = parseFloat(trade.stopLoss || trade.stop_loss || 0);
  const takeProfit = parseFloat(trade.takeProfit || trade.take_profit || 0);
  const positionSize = parseFloat(trade.positionSize || trade.position_size || 0);
  const direction = (trade.direction || 'LONG').toUpperCase();
  const markPrice = currentPrice !== null ? parseFloat(currentPrice) : (parseFloat(trade.exitPrice || trade.exit_price || entry));

  const lev = Math.max(1, parseInt(leverage || 10, 10));
  const notional = parseFloat((positionSize * markPrice).toFixed(4));
  const margin = parseFloat((notional / lev).toFixed(4));

  const riskPerUnit = Math.abs(entry - stopLoss);
  const riskAmount = parseFloat((riskPerUnit * positionSize).toFixed(4));

  const rewardPerUnit = Math.abs(takeProfit - entry);
  const expectedReward = parseFloat((rewardPerUnit * positionSize).toFixed(4));

  const riskRewardRatio = riskAmount > 0 ? parseFloat((expectedReward / riskAmount).toFixed(2)) : 0;

  // Unrealized or realized PnL
  let unrealizedPnl = 0;
  if (direction === 'LONG') {
    unrealizedPnl = (markPrice - entry) * positionSize;
  } else {
    unrealizedPnl = (entry - markPrice) * positionSize;
  }
  unrealizedPnl = parseFloat(unrealizedPnl.toFixed(4));

  // Current R multiple
  const currentR = riskAmount > 0 ? parseFloat((unrealizedPnl / riskAmount).toFixed(2)) : 0;

  // Distance percentages
  let distanceToSL = 0;
  let distanceToTP = 0;
  if (markPrice > 0) {
    if (direction === 'LONG') {
      distanceToSL = parseFloat((((markPrice - stopLoss) / markPrice) * 100).toFixed(2));
      distanceToTP = parseFloat((((takeProfit - markPrice) / markPrice) * 100).toFixed(2));
    } else {
      distanceToSL = parseFloat((((stopLoss - markPrice) / markPrice) * 100).toFixed(2));
      distanceToTP = parseFloat((((markPrice - takeProfit) / markPrice) * 100).toFixed(2));
    }
  }

  // Visual trade progress: SL (0%) ── ENTRY ── ● CURRENT ── TP (100%)
  const totalRange = Math.abs(takeProfit - stopLoss);
  let progressPct = 0;
  if (totalRange > 0) {
    if (direction === 'LONG') {
      progressPct = ((markPrice - stopLoss) / totalRange) * 100;
    } else {
      progressPct = ((stopLoss - markPrice) / totalRange) * 100;
    }
    progressPct = parseFloat(Math.max(0, Math.min(100, progressPct)).toFixed(1));
  }

  // Remaining risk and reward
  const remainingRisk = parseFloat(Math.max(0, unrealizedPnl + riskAmount).toFixed(2));
  const remainingReward = parseFloat(Math.max(0, expectedReward - unrealizedPnl).toFixed(2));

  // Regime and cluster extraction
  let regimeStr = 'UNCERTAIN';
  if (trade.regime) {
    if (typeof trade.regime === 'object') regimeStr = trade.regime.regime || 'UNCERTAIN';
    else {
      try {
        const parsed = JSON.parse(trade.regime);
        regimeStr = parsed.regime || trade.regime;
      } catch (_) {
        regimeStr = trade.regime;
      }
    }
  }

  const cluster = trade.cluster || getAssetCluster(trade.symbol);

  return {
    symbol: trade.symbol,
    direction,
    mode: trade.mode || 'PAPER',
    strategyId: trade.strategyId || trade.strategy_id || 'gps_v1',
    strategyName: trade.strategyName || trade.strategy_name || 'GPS',
    strategyVersion: trade.strategyVersion || trade.strategy_version || '1.0.0',
    score: trade.score || 0,
    entry,
    currentPrice: markPrice,
    stopLoss,
    takeProfit,
    positionSize,
    notional,
    leverage: lev,
    margin,
    riskAmount,
    expectedReward,
    riskRewardRatio,
    unrealizedPnl,
    currentR,
    distanceToSL,
    distanceToTP,
    progressPct,
    remainingRisk,
    remainingReward,
    regime: regimeStr,
    cluster,
    fee: parseFloat(trade.fee || 0),
    slippage: parseFloat(trade.slippage || 0),
    openTime: trade.openTime || trade.open_time || Date.now(),
  };
}

/**
 * Calculate comprehensive Portfolio & Command Center overview
 */
function calculatePortfolioMetrics(openTrades = [], startingBalance = config.accountBalance, leverage = 10, closedTrades = [], maxExposurePct = 0.3) {
  const startBal = parseFloat(startingBalance || config.accountBalance);
  const lev = Math.max(1, parseInt(leverage || 10, 10));

  let realizedPnl = 0;
  for (const t of closedTrades) {
    realizedPnl += parseFloat(t.pnl || 0);
  }
  realizedPnl = parseFloat(realizedPnl.toFixed(4));

  let capitalDeployed = 0;
  let marginUsed = 0;
  let unrealizedPnl = 0;
  let currentRisk = 0;
  let expectedTotalReward = 0;

  for (const t of openTrades) {
    capitalDeployed += t.notional || 0;
    marginUsed += t.margin || 0;
    unrealizedPnl += t.unrealizedPnl || 0;
    currentRisk += t.riskAmount || 0;
    expectedTotalReward += t.expectedReward || 0;
  }

  capitalDeployed = parseFloat(capitalDeployed.toFixed(2));
  marginUsed = parseFloat(marginUsed.toFixed(2));
  unrealizedPnl = parseFloat(unrealizedPnl.toFixed(4));
  currentRisk = parseFloat(currentRisk.toFixed(2));
  expectedTotalReward = parseFloat(expectedTotalReward.toFixed(2));

  const netPnl = parseFloat((realizedPnl + unrealizedPnl).toFixed(4));
  const currentEquity = parseFloat((startBal + netPnl).toFixed(4));
  const availableCapital = parseFloat(Math.max(0, currentEquity - marginUsed).toFixed(2));

  const portfolioExposurePct = currentEquity > 0
    ? parseFloat(((capitalDeployed / currentEquity) * 100).toFixed(1))
    : 0;

  const currentRiskPct = currentEquity > 0
    ? parseFloat(((currentRisk / currentEquity) * 100).toFixed(2))
    : 0;

  return {
    startingBalance: startBal,
    currentEquity,
    realizedPnl,
    unrealizedPnl,
    netPnl,
    capitalDeployed,
    marginUsed,
    availableCapital,
    portfolioExposurePct,
    maxPortfolioExposurePct: parseFloat((maxExposurePct * 100).toFixed(1)),
    currentRisk,
    currentRiskPct,
    expectedTotalReward,
    openPositionsCount: openTrades.length,
    leverage: lev,
  };
}

/**
 * Calculate full performance analytics from closed trade history
 */
function calculatePerformanceStats(closedTrades = [], startingBalance = config.accountBalance) {
  const startBal = parseFloat(startingBalance || config.accountBalance);
  const totalTrades = closedTrades.length;

  if (totalTrades === 0) {
    return {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      breakevenTrades: 0,
      winRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netPnl: 0,
      profitFactor: 0,
      expectancy: 0,
      avgWin: 0,
      avgLoss: 0,
      winLossRatio: 0,
      avgR: 0,
      largestWin: 0,
      largestLoss: 0,
      maxConsecutiveWins: 0,
      maxConsecutiveLosses: 0,
      avgDurationMs: 0,
      tpCount: 0,
      slCount: 0,
      otherExitCount: 0,
      tpPct: 0,
      slPct: 0,
      peakEquity: startBal,
      currentEquity: startBal,
      currentDrawdown: 0,
      currentDrawdownPct: 0,
      maxDrawdown: 0,
      maxDrawdownPct: 0,
      equityCurve: [{ timestamp: Date.now(), equity: startBal, pnl: 0 }],
      cumulativePnl: [{ timestamp: Date.now(), cumPnl: 0 }],
      rDistribution: [
        { bucket: '< -2R', count: 0 },
        { bucket: '-2R to -1R', count: 0 },
        { bucket: '-1R to -0.5R', count: 0 },
        { bucket: '-0.5R to 0R', count: 0 },
        { bucket: '0R to +0.5R', count: 0 },
        { bucket: '+0.5R to +1R', count: 0 },
        { bucket: '+1R to +2R', count: 0 },
        { bucket: '> +2R', count: 0 },
      ],
      byStrategy: [],
      byRegime: [],
      byCluster: [],
      bySymbol: [],
    };
  }

  // Sort chronologically ascending for equity curve calculation
  const sorted = [...closedTrades].sort((a, b) => (a.close_time || a.closeTime || 0) - (b.close_time || b.closeTime || 0));

  let wins = 0;
  let losses = 0;
  let breakeven = 0;
  let grossProfit = 0;
  let grossLoss = 0;
  let largestWin = 0;
  let largestLoss = 0;
  let curWinStreak = 0;
  let curLossStreak = 0;
  let maxConsecutiveWins = 0;
  let maxConsecutiveLosses = 0;
  let totalDurationMs = 0;
  let totalR = 0;
  let rCount = 0;
  let tpCount = 0;
  let slCount = 0;
  let otherExitCount = 0;

  const rBuckets = {
    'lt_neg2': 0,
    'neg2_to_neg1': 0,
    'neg1_to_neg05': 0,
    'neg05_to_0': 0,
    '0_to_05': 0,
    '05_to_1': 0,
    '1_to_2': 0,
    'gt_2': 0,
  };

  const strategyMap = {};
  const regimeMap = {};
  const clusterMap = {};
  const symbolMap = {};

  let currentEquity = startBal;
  let peakEquity = startBal;
  let maxDrawdown = 0;
  let maxDrawdownPct = 0;

  const equityCurve = [{ timestamp: sorted[0].open_time || Date.now(), equity: startBal, pnl: 0 }];
  const cumulativePnl = [{ timestamp: sorted[0].open_time || Date.now(), cumPnl: 0 }];
  let runningCumPnl = 0;

  for (const t of sorted) {
    const pnl = parseFloat(t.pnl || 0);
    const entry = parseFloat(t.entry || 0);
    const sl = parseFloat(t.stop_loss || t.stopLoss || 0);
    const psize = parseFloat(t.position_size || t.positionSize || 0);
    const risk = Math.abs(entry - sl) * psize;

    // R outcome calculation
    let rOutcome = 0;
    if (risk > 0) {
      rOutcome = parseFloat((pnl / risk).toFixed(2));
      totalR += rOutcome;
      rCount++;

      if (rOutcome < -2) rBuckets['lt_neg2']++;
      else if (rOutcome < -1) rBuckets['neg2_to_neg1']++;
      else if (rOutcome < -0.5) rBuckets['neg1_to_neg05']++;
      else if (rOutcome < 0) rBuckets['neg05_to_0']++;
      else if (rOutcome < 0.5) rBuckets['0_to_05']++;
      else if (rOutcome < 1) rBuckets['05_to_1']++;
      else if (rOutcome <= 2) rBuckets['1_to_2']++;
      else rBuckets['gt_2']++;
    }

    // Win / Loss / Breakeven
    if (pnl > 0.0001) {
      wins++;
      grossProfit += pnl;
      curWinStreak++;
      curLossStreak = 0;
      if (curWinStreak > maxConsecutiveWins) maxConsecutiveWins = curWinStreak;
      if (pnl > largestWin) largestWin = pnl;
    } else if (pnl < -0.0001) {
      losses++;
      grossLoss += Math.abs(pnl);
      curLossStreak++;
      curWinStreak = 0;
      if (curLossStreak > maxConsecutiveLosses) maxConsecutiveLosses = curLossStreak;
      if (pnl < largestLoss) largestLoss = pnl;
    } else {
      breakeven++;
      curWinStreak = 0;
      curLossStreak = 0;
    }

    // Duration
    const dur = parseInt(t.duration_ms || t.durationMs || 0, 10);
    if (dur > 0) totalDurationMs += dur;

    // Exit reason
    const reason = (t.exit_reason || t.exitReason || '').toUpperCase();
    if (reason.includes('TAKE_PROFIT') || reason.includes('TP')) tpCount++;
    else if (reason.includes('STOP_LOSS') || reason.includes('SL')) slCount++;
    else otherExitCount++;

    // Equity Curve & Drawdown
    currentEquity = parseFloat((currentEquity + pnl).toFixed(4));
    runningCumPnl = parseFloat((runningCumPnl + pnl).toFixed(4));
    const closeTime = t.close_time || t.closeTime || Date.now();

    equityCurve.push({
      timestamp: closeTime,
      equity: currentEquity,
      pnl,
      symbol: t.symbol,
      tradeId: t.id,
    });

    cumulativePnl.push({
      timestamp: closeTime,
      cumPnl: runningCumPnl,
    });

    if (currentEquity > peakEquity) {
      peakEquity = currentEquity;
    }
    const currentDd = peakEquity - currentEquity;
    const currentDdPct = peakEquity > 0 ? (currentDd / peakEquity) * 100 : 0;
    if (currentDd > maxDrawdown) maxDrawdown = currentDd;
    if (currentDdPct > maxDrawdownPct) maxDrawdownPct = currentDdPct;

    // Attribution aggregators
    const stratKey = t.strategy_name || t.strategyName || 'GPS';
    strategyMap[stratKey] = strategyMap[stratKey] || { trades: 0, wins: 0, pnl: 0, totalR: 0, rCount: 0 };
    strategyMap[stratKey].trades++;
    if (pnl > 0) strategyMap[stratKey].wins++;
    strategyMap[stratKey].pnl += pnl;
    if (risk > 0) { strategyMap[stratKey].totalR += rOutcome; strategyMap[stratKey].rCount++; }

    let regKey = 'UNCERTAIN';
    if (t.regime) {
      try {
        const parsed = typeof t.regime === 'string' ? JSON.parse(t.regime) : t.regime;
        regKey = parsed.regime || t.regime;
      } catch (_) { regKey = t.regime; }
    }
    regimeMap[regKey] = regimeMap[regKey] || { trades: 0, wins: 0, pnl: 0, totalR: 0, rCount: 0 };
    regimeMap[regKey].trades++;
    if (pnl > 0) regimeMap[regKey].wins++;
    regimeMap[regKey].pnl += pnl;
    if (risk > 0) { regimeMap[regKey].totalR += rOutcome; regimeMap[regKey].rCount++; }

    const clusKey = t.cluster || getAssetCluster(t.symbol);
    clusterMap[clusKey] = clusterMap[clusKey] || { trades: 0, wins: 0, pnl: 0, totalR: 0, rCount: 0 };
    clusterMap[clusKey].trades++;
    if (pnl > 0) clusterMap[clusKey].wins++;
    clusterMap[clusKey].pnl += pnl;
    if (risk > 0) { clusterMap[clusKey].totalR += rOutcome; clusterMap[clusKey].rCount++; }

    const symKey = t.symbol;
    symbolMap[symKey] = symbolMap[symKey] || { trades: 0, wins: 0, pnl: 0, totalR: 0, rCount: 0 };
    symbolMap[symKey].trades++;
    if (pnl > 0) symbolMap[symKey].wins++;
    symbolMap[symKey].pnl += pnl;
    if (risk > 0) { symbolMap[symKey].totalR += rOutcome; symbolMap[symKey].rCount++; }
  }

  const winRate = parseFloat(((wins / totalTrades) * 100).toFixed(2));
  const avgWin = wins > 0 ? parseFloat((grossProfit / wins).toFixed(2)) : 0;
  const avgLoss = losses > 0 ? parseFloat((grossLoss / losses).toFixed(2)) : 0;
  const winLossRatio = avgLoss > 0 ? parseFloat((avgWin / avgLoss).toFixed(2)) : (avgWin > 0 ? 999 : 0);
  const profitFactor = grossLoss > 0 ? parseFloat((grossProfit / grossLoss).toFixed(2)) : (grossProfit > 0 ? 999 : 0);
  const expectancy = parseFloat(((winRate / 100 * avgWin) - ((1 - winRate / 100) * avgLoss)).toFixed(2));
  const avgR = rCount > 0 ? parseFloat((totalR / rCount).toFixed(2)) : 0;
  const netPnl = parseFloat((grossProfit - grossLoss).toFixed(4));
  const currentDrawdown = parseFloat((peakEquity - currentEquity).toFixed(2));
  const currentDrawdownPct = peakEquity > 0 ? parseFloat(((currentDrawdown / peakEquity) * 100).toFixed(2)) : 0;

  // Format attribution arrays
  const toAttributionArray = (map, keyName) => Object.entries(map).map(([key, d]) => ({
    [keyName]: key,
    trades: d.trades,
    wins: d.wins,
    losses: d.trades - d.wins,
    winRate: parseFloat(((d.wins / d.trades) * 100).toFixed(1)),
    pnl: parseFloat(d.pnl.toFixed(2)),
    avgR: d.rCount > 0 ? parseFloat((d.totalR / d.rCount).toFixed(2)) : 0,
  })).sort((a, b) => b.pnl - a.pnl);

  return {
    totalTrades,
    winningTrades: wins,
    losingTrades: losses,
    breakevenTrades: breakeven,
    winRate,
    grossProfit: parseFloat(grossProfit.toFixed(2)),
    grossLoss: parseFloat(grossLoss.toFixed(2)),
    netPnl,
    profitFactor,
    expectancy,
    avgWin,
    avgLoss,
    winLossRatio,
    avgR,
    largestWin: parseFloat(largestWin.toFixed(2)),
    largestLoss: parseFloat(largestLoss.toFixed(2)),
    maxConsecutiveWins,
    maxConsecutiveLosses,
    avgDurationMs: totalTrades > 0 ? Math.round(totalDurationMs / totalTrades) : 0,
    tpCount,
    slCount,
    otherExitCount,
    tpPct: totalTrades > 0 ? parseFloat(((tpCount / totalTrades) * 100).toFixed(1)) : 0,
    slPct: totalTrades > 0 ? parseFloat(((slCount / totalTrades) * 100).toFixed(1)) : 0,
    peakEquity: parseFloat(peakEquity.toFixed(2)),
    currentEquity: parseFloat(currentEquity.toFixed(2)),
    currentDrawdown,
    currentDrawdownPct,
    maxDrawdown: parseFloat(maxDrawdown.toFixed(2)),
    maxDrawdownPct: parseFloat(maxDrawdownPct.toFixed(2)),
    equityCurve,
    cumulativePnl,
    rDistribution: [
      { bucket: '< -2R', count: rBuckets['lt_neg2'] },
      { bucket: '-2R to -1R', count: rBuckets['neg2_to_neg1'] },
      { bucket: '-1R to -0.5R', count: rBuckets['neg1_to_neg05'] },
      { bucket: '-0.5R to 0R', count: rBuckets['neg05_to_0'] },
      { bucket: '0R to +0.5R', count: rBuckets['0_to_05'] },
      { bucket: '+0.5R to +1R', count: rBuckets['05_to_1'] },
      { bucket: '+1R to +2R', count: rBuckets['1_to_2'] },
      { bucket: '> +2R', count: rBuckets['gt_2'] },
    ],
    byStrategy: toAttributionArray(strategyMap, 'strategy'),
    byRegime: toAttributionArray(regimeMap, 'regime'),
    byCluster: toAttributionArray(clusterMap, 'cluster'),
    bySymbol: toAttributionArray(symbolMap, 'symbol'),
  };
}

/**
 * Determine global risk status and human rationale
 */
function calculateRiskStatus(riskStatus = {}, cfg = {}, openTrades = [], accountBalance = config.accountBalance) {
  const killSwitch = riskStatus.killSwitch === true;
  const tradingEnabled = riskStatus.tradingEnabled !== false;
  const consecutiveLosses = riskStatus.consecutiveLosses || 0;
  const maxConsecutive = cfg.maxConsecutiveLosses || 5;
  const dailyPnL = riskStatus.dailyPnL || 0;
  const maxDailyLossPct = (cfg.maxDailyLoss || 0.05) * 100;
  const currentDailyLossPct = accountBalance > 0 ? (Math.abs(Math.min(0, dailyPnL)) / accountBalance) * 100 : 0;
  const exposurePct = riskStatus.exposurePct || 0;
  const maxExposurePct = (cfg.maxPortfolioExposure || 0.3) * 100;
  const maxClusterExposurePct = (cfg.maxCorrelatedExposure || 0.2) * 100;

  let level = 'NORMAL';
  let badge = '🟢 RISK NORMAL';
  let reason = `Risk normal — ${exposurePct}% portfolio exposure (${openTrades.length}/${cfg.maxOpenPositions || 5} positions).`;

  if (killSwitch || !tradingEnabled) {
    level = 'LOCKED';
    badge = '🔴 RISK LOCKED';
    reason = killSwitch ? 'Trading blocked — Emergency Kill Switch is ACTIVE.' : 'Trading is currently DISABLED.';
  } else if (currentDailyLossPct >= maxDailyLossPct) {
    level = 'LOCKED';
    badge = '🔴 RISK LOCKED';
    reason = `Trading locked — Daily loss limit reached (${currentDailyLossPct.toFixed(1)}% >= ${maxDailyLossPct.toFixed(1)}%).`;
  } else if (consecutiveLosses >= maxConsecutive) {
    level = 'LOCKED';
    badge = '🔴 RISK LOCKED';
    reason = `Trading locked — Maximum consecutive losses reached (${consecutiveLosses}/${maxConsecutive}).`;
  } else if (consecutiveLosses >= maxConsecutive - 1) {
    level = 'ELEVATED';
    badge = '🟡 RISK ELEVATED';
    reason = `Risk elevated — ${consecutiveLosses} consecutive losses recorded (1 below circuit breaker).`;
  } else if (exposurePct >= maxExposurePct * 0.8) {
    level = 'ELEVATED';
    badge = '🟡 RISK ELEVATED';
    reason = `Risk elevated — High portfolio exposure (${exposurePct}% / max ${maxExposurePct}%).`;
  }

  // Correlation clusters
  const clusters = ['LAYER_1', 'MEME', 'DEFI', 'AI_DEPIN', 'INFRA_L2', 'ALT_GENERAL'];
  const clusterBars = clusters.map(c => {
    const rawVal = (riskStatus.clusterExposures && riskStatus.clusterExposures[c]) || 0;
    const pct = accountBalance > 0 ? parseFloat(((rawVal / accountBalance) * 100).toFixed(1)) : 0;
    return {
      cluster: c,
      value: rawVal,
      pct,
      maxPct: maxClusterExposurePct,
      nearLimit: pct >= maxClusterExposurePct * 0.8,
    };
  });

  return {
    level,
    badge,
    reason,
    exposurePct,
    maxExposurePct,
    clusterExposures: clusterBars,
    dailyPnL,
    currentDailyLossPct: parseFloat(currentDailyLossPct.toFixed(2)),
    maxDailyLossPct,
    consecutiveLosses,
    maxConsecutiveLosses: maxConsecutive,
    circuitBreakers: {
      killSwitch,
      tradingEnabled,
      dailyLossExceeded: currentDailyLossPct >= maxDailyLossPct,
      consecutiveLossExceeded: consecutiveLosses >= maxConsecutive,
    },
  };
}

module.exports = {
  calculateTradeMetrics,
  calculatePortfolioMetrics,
  calculatePerformanceStats,
  calculateRiskStatus,
};
