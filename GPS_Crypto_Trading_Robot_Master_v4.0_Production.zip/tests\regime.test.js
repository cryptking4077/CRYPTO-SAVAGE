'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const { detectRegime } = require('../src/market/regime');

describe('Market Regime Detection', () => {
  const createTrendCandles = (count, startPrice = 100, step = 2) => {
    const candles = [];
    let price = startPrice;
    for (let i = 0; i < count; i++) {
      const open = price;
      const close = price + step;
      const high = Math.max(open, close) + 1;
      const low = Math.min(open, close) - 1;
      candles.push({
        time: 1700000000000 + i * 3600000 * 4,
        open, high, low, close,
        volume: 1000,
      });
      price = close;
    }
    return candles;
  };

  test('detects bullish trending regime', () => {
    const bullCandles = createTrendCandles(60, 100, 3);
    const res = detectRegime(bullCandles, bullCandles);
    assert.ok(['TRENDING_UP', 'HIGH_VOLATILITY'].includes(res.regime));
    assert.equal(res.trend, 'BULLISH');
    assert.ok(res.confidence >= 60);
  });

  test('detects bearish trending regime', () => {
    const bearCandles = createTrendCandles(60, 300, -3);
    const res = detectRegime(bearCandles, bearCandles);
    assert.ok(['TRENDING_DOWN', 'HIGH_VOLATILITY'].includes(res.regime));
    assert.equal(res.trend, 'BEARISH');
    assert.ok(res.confidence >= 60);
  });

  test('handles insufficient candles gracefully with UNCERTAIN', () => {
    const res = detectRegime([], []);
    assert.equal(res.regime, 'UNCERTAIN');
    assert.equal(res.confidence, 0);
  });
});
