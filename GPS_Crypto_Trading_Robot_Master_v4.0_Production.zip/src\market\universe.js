'use strict';

/**
 * Market Universe — CRYPTO ONLY
 * Discovers eligible Bybit USDT perpetual crypto markets.
 * Non-crypto instruments (stocks, forex, metals, indices, commodities) are NOT supported.
 */

const bybit = require('../exchanges/bybit');
const config = require('../config');
const logger = require('../utils/logger');

let cachedUniverse = [];
let lastDiscovery = 0;
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 min

/**
 * All Bybit USDT linear perpetuals are crypto by definition.
 * This function is kept for backwards compatibility with any code that calls it.
 * It always returns CRYPTO.
 */
function classifyAssetClass(symbol, _baseCoin) {
  void symbol;
  return 'CRYPTO';
}

/**
 * All Bybit USDT linear perpetuals are legitimate crypto.
 * Kept for backwards compatibility.
 */
function isLegitimateCrypto(_symbol, _baseCoin) {
  return { isCrypto: true };
}

/**
 * Discover eligible Bybit USDT perpetual crypto markets.
 * Filters by: quote=USDT, LinearPerpetual, status=Trading, min volume, not excluded.
 *
 * @param {boolean} force  - bypass cache
 * @returns {Promise<Array>} sorted market objects
 */
async function discoverMarkets(force = false) {
  const now = Date.now();
  if (!force && cachedUniverse.length > 0 && (now - lastDiscovery) < CACHE_TTL_MS) {
    return cachedUniverse;
  }

  logger.info('Discovering Bybit USDT perpetual crypto markets...');

  // Fetch instruments and tickers in parallel
  const [instruments, tickers] = await Promise.all([
    bybit.getInstruments(),
    bybit.getTickers(),
  ]);

  const tickerMap = {};
  for (const t of tickers) {
    tickerMap[t.symbol] = t;
  }

  const excluded = new Set(config.excludedSymbols);
  const markets = [];

  for (const inst of instruments) {
    if (inst.quoteCoin !== 'USDT') continue;
    if (inst.contractType !== 'LinearPerpetual') continue;
    if (inst.status !== 'Trading') continue;

    const sym = inst.symbol;
    if (excluded.has(sym)) continue;

    const ticker = tickerMap[sym];
    if (!ticker) continue;

    const vol24h = parseFloat(ticker.turnover24h || '0');
    if (vol24h < config.minQuoteVolume) continue;

    markets.push({
      symbol: sym,
      baseCoin: inst.baseCoin,
      quoteCoin: inst.quoteCoin,
      assetClass: 'CRYPTO',
      minOrderQty: parseFloat(inst.lotSizeFilter?.minOrderQty || '0'),
      maxOrderQty: parseFloat(inst.lotSizeFilter?.maxOrderQty || '0'),
      qtyStep: parseFloat(inst.lotSizeFilter?.qtyStep || '0'),
      tickSize: parseFloat(inst.priceFilter?.tickSize || '0.01'),
      maxLeverage: parseFloat(inst.leverageFilter?.maxLeverage || '10'),
      priceScale: parseInt(inst.priceScale || '2', 10),
      lastPrice: parseFloat(ticker.lastPrice || '0'),
      vol24hUSDT: vol24h,
      fundingRate: parseFloat(ticker.fundingRate || '0'),
    });
  }

  markets.sort((a, b) => b.vol24hUSDT - a.vol24hUSDT);

  let finalMarkets = markets;
  if (config.scanMaxMarkets && config.scanMaxMarkets > 0) {
    finalMarkets = markets.slice(0, config.scanMaxMarkets);
  }

  logger.info(`Market universe: ${finalMarkets.length} crypto markets discovered`);
  cachedUniverse = finalMarkets;
  lastDiscovery = now;

  return finalMarkets;
}

/** Get reference data for BTC/ETH (excluded from trading but used as market context) */
async function getReferenceMarkets() {
  const tickers = await bybit.getTickers();
  const refs = ['BTCUSDT', 'ETHUSDT'];
  return tickers
    .filter(t => refs.includes(t.symbol))
    .map(t => ({
      symbol: t.symbol,
      lastPrice: parseFloat(t.lastPrice || '0'),
      change24h: parseFloat(t.price24hPcnt || '0'),
      vol24hUSDT: parseFloat(t.turnover24h || '0'),
    }));
}

module.exports = {
  discoverMarkets,
  getReferenceMarkets,
  isLegitimateCrypto,
  classifyAssetClass,
  // KNOWN_NON_CRYPTO_BASE kept as empty set for backwards compatibility
  KNOWN_NON_CRYPTO_BASE: new Set(),
};
