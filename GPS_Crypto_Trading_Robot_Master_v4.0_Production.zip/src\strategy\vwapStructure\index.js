'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 20,
    vwapAlignment: 30,
    marketStructure: 30,
    volumeSupport: 20,
  },
};

/**
 * VWAP & Market Structure Strategy (vwap_structure_v1)
 * Trades trend continuation when price is structurally holding the favorable side of VWAP.
 */
class VWAPStructureStrategy {
  constructor(options = {}) {
    this.id = 'vwap_structure_v1';
    this.name = options.name || 'VWAP & Structure';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime alignment (STRONG_TREND, WEAK_TREND, or PULLBACK)
    const isTrending = ['STRONG_TREND', 'WEAK_TREND', 'PULLBACK', 'TRENDING_UP', 'TRENDING_DOWN'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isTrending ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    const lastIdx = candles1H.length - 1;
    const last1H = candles1H[lastIdx];

    // 2. VWAP calculation & positioning
    const vwapVals = indicators.vwap(candles1H);
    const lastVWAP = vwapVals[lastIdx];

    let direction = null;
    let vwapAligned = false;

    if (last1H.close > lastVWAP && last1H.low >= lastVWAP * 0.995) {
      direction = 'LONG';
      vwapAligned = true;
    } else if (last1H.close < lastVWAP && last1H.high <= lastVWAP * 1.005) {
      direction = 'SHORT';
      vwapAligned = true;
    }

    conditions.vwapAlignment = vwapAligned ? PASS : FAIL;
    details.vwap = `VWAP: ${lastVWAP ? lastVWAP.toFixed(4) : 'N/A'}, Close: ${last1H.close.toFixed(4)}`;

    // 3. Market structure trend (HH/HL or LH/LL)
    const structTrend = indicators.detectTrend(candles1H, 5);
    let structureOk = false;

    if (direction === 'LONG' && (structTrend === 'BULLISH' || structTrend === 'RANGING')) {
      structureOk = true;
    } else if (direction === 'SHORT' && (structTrend === 'BEARISH' || structTrend === 'RANGING')) {
      structureOk = true;
    }

    conditions.marketStructure = structureOk ? PASS : FAIL;
    details.structure = `Structure Trend: ${structTrend}`;

    // 4. Volume support
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[lastIdx];
    const volOk = !isNaN(lastVolMA) && last1H.volume >= lastVolMA * 0.9;
    conditions.volumeSupport = volOk ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Levels
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[lastIdx] || (entry * 0.015);

    if (direction === 'LONG') {
      stopLoss = Math.min(last1H.low, lastVWAP) - atrNow * 0.5;
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      stopLoss = Math.max(last1H.high, lastVWAP) + atrNow * 0.5;
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !vwapAligned ? 'NO_VWAP_ALIGNMENT' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = VWAPStructureStrategy;
