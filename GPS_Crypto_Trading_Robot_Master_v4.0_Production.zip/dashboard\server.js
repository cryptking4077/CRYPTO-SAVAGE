'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../src/config');
const journal = require('../src/journal/store');
const logger = require('../src/utils/logger');
const bybit = require('../src/exchanges/bybit');
const dataFeed = require('../src/market/dataFeed');
const { createDefaultRegistry } = require('../src/strategy/registry');
const { defaultNotifier } = require('../src/notifications/index');
const {
  calculateTradeMetrics,
  calculatePortfolioMetrics,
  calculatePerformanceStats,
  calculateRiskStatus,
} = require('../src/dashboard/analytics');
const { getPersistentScanner } = require('../src/scanner/persistentScanner');
const PaperEngine = require('../src/paper/engine');
const { rankOpportunities } = require('../src/scoring/ranking');
const { generateRecommendations } = require('../src/monitoring/recommendations');
const { eventBus } = require('../src/events/bus');
const { autopsyEngine } = require('../src/learning/autopsy');

const registry = createDefaultRegistry();
const paperEngine = new PaperEngine();
const persistentScanner = getPersistentScanner({ registry });

// Lightweight in-memory ticker cache (5s TTL) to prevent spamming Bybit
let cachedTickers = {};
let lastTickerFetch = 0;

async function getLiveTickers() {
  const now = Date.now();
  if (now - lastTickerFetch < 5000 && Object.keys(cachedTickers).length > 0) {
    return cachedTickers;
  }
  try {
    const list = await bybit.getTickers();
    const map = {};
    for (const t of list) {
      map[t.symbol] = {
        lastPrice: parseFloat(t.lastPrice || 0),
        markPrice: parseFloat(t.markPrice || t.lastPrice || 0),
        turnover24h: parseFloat(t.turnover24h || 0),
        fundingRate: parseFloat(t.fundingRate || 0),
      };
    }
    cachedTickers = map;
    lastTickerFetch = now;
    return cachedTickers;
  } catch (err) {
    logger.warn(`Ticker fetch failed in dashboard: ${err.message}`);
    return cachedTickers;
  }
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  // Static Assets
  if (method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
    const htmlPath = path.join(__dirname, 'public', 'index.html');
    if (fs.existsSync(htmlPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(htmlPath).pipe(res);
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // DEDICATED MODULAR DASHBOARD ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  // 1. Dashboard Summary: Top header & Account Cards
  if (method === 'GET' && pathname === '/api/dashboard/summary') {
    try {
      const running = journal.getState('robot_running') || false;
      const mode = journal.getState('robot_mode') || config.mode;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const lastScan = journal.getState('last_scan') || null;
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recon = journal.getState('reconciliation_status') || { status: 'HEALTHY' };

      const tickers = await getLiveTickers();
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      const enrichedOpen = allOpen.map(t => {
        const mark = tickers[t.symbol]?.markPrice || t.entry;
        return calculateTradeMetrics(t, mark, config.defaultLeverage);
      });

      const closedPaper = journal.getClosedPaperTrades(500);
      const closedLive = journal.getClosedLiveTrades(500);
      const allClosed = [...closedPaper, ...closedLive];

      const portfolio = calculatePortfolioMetrics(
        enrichedOpen,
        config.accountBalance,
        config.defaultLeverage,
        allClosed,
        config.maxPortfolioExposure
      );

      let operationalState = 'PAPER';
      if (emergencyStop) operationalState = 'EMERGENCY_STOP';
      else if (mode === 'LIVE') operationalState = config.liveEnabled ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED';

      return sendJson(res, 200, {
        status: emergencyStop ? 'EMERGENCY_STOP' : (running ? 'RUNNING' : 'STOPPED'),
        operationalState,
        mode,
        isLive: mode === 'LIVE' && config.liveEnabled,
        liveTradingEnabled: config.liveEnabled,
        emergencyStop,
        running,
        lastScan,
        lastMarketUpdate: lastTickerFetch || Date.now(),
        watchdog,
        reconciliation: recon,
        portfolio,
        maxOpenPositions: config.maxOpenPositions,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 2. Open Positions: Live Mark Price, Notional, Margin, Progress Bar
  if (method === 'GET' && pathname === '/api/dashboard/positions') {
    try {
      const tickers = await getLiveTickers();
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      const positions = allOpen.map(t => {
        const mark = tickers[t.symbol]?.markPrice || tickers[t.symbol]?.lastPrice || t.entry;
        const metrics = calculateTradeMetrics(t, mark, config.defaultLeverage);

        // Fetch condition details from recent signals if available
        let conditions = {};
        try {
          const sigs = journal.getRecentSignals(30);
          const matched = sigs.find(s => s.symbol === t.symbol && s.direction === t.direction);
          if (matched && matched.conditions) {
            conditions = typeof matched.conditions === 'string' ? JSON.parse(matched.conditions) : matched.conditions;
          }
        } catch (_) {}

        return {
          id: t.id,
          ...metrics,
          conditions,
        };
      });

      return sendJson(res, 200, {
        positions,
        count: positions.length,
        leverage: config.defaultLeverage,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 3. Scanner Command Center: Counts & Table with "Why Not Trade"
  if (method === 'GET' && pathname === '/api/dashboard/scanner') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '100', 10);
      const totalScanned = journal.getState('market_count') || 262;
      const rawSignals = journal.getRecentSignals(limit);

      let qualifiedCount = 0;
      let watchCount = 0;
      let rejectedCount = 0;
      let dqBlockedCount = 0;

      const signals = rawSignals.map(s => {
        const score = s.score || 0;
        const decision = s.decision || '';
        const reason = s.rejection_reason || s.rejectionReason || '';
        const isDQ = decision === 'DATA_QUALITY_BLOCK' || reason.includes('DATA_QUALITY');

        if (isDQ) dqBlockedCount++;
        else if (s.qualified === 1 || decision === 'TRADE') qualifiedCount++;
        else if (score >= 75 && score < 85) watchCount++;
        else rejectedCount++;

        let regimeStr = 'UNCERTAIN';
        if (s.regime) {
          try {
            const parsed = typeof s.regime === 'string' ? JSON.parse(s.regime) : s.regime;
            regimeStr = parsed.regime || s.regime;
          } catch (_) { regimeStr = s.regime; }
        }

        let conditionObj = {};
        if (s.conditions) {
          try {
            conditionObj = typeof s.conditions === 'string' ? JSON.parse(s.conditions) : s.conditions;
          } catch (_) {}
        }

        const metrics = calculateTradeMetrics(s, s.entry, config.defaultLeverage);

        return {
          id: s.id,
          symbol: s.symbol,
          direction: s.direction,
          score,
          decision,
          qualified: !!s.qualified,
          regime: regimeStr,
          cluster: s.cluster || metrics.cluster,
          entry: s.entry,
          stopLoss: s.stop_loss || s.stopLoss,
          takeProfit: s.take_profit || s.takeProfit,
          riskReward: s.risk_reward || s.riskReward,
          riskAmount: metrics.riskAmount,
          expectedReward: metrics.expectedReward,
          rejectionReason: reason || (score < config.minScore ? `Score ${score} < minimum ${config.minScore}` : 'None'),
          timestamp: s.timestamp,
          conditions: conditionObj,
          mode: s.mode || 'PAPER',
        };
      });

      return sendJson(res, 200, {
        totalScanned,
        qualifiedCount,
        watchCount,
        rejectedCount,
        dqBlockedCount,
        signals,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 4. Performance & Analytics: Equity curves, Expectancy, R-distribution
  if (method === 'GET' && pathname === '/api/dashboard/performance') {
    try {
      const closedPaper = journal.getClosedPaperTrades(1000);
      const closedLive = journal.getClosedLiveTrades(1000);
      const allClosed = [...closedPaper, ...closedLive];

      const stats = calculatePerformanceStats(allClosed, config.accountBalance);
      return sendJson(res, 200, stats);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 5. Risk Command Center: Real exposure, cluster bars, circuit breakers
  if (method === 'GET' && pathname === '/api/dashboard/risk') {
    try {
      const perf = journal.getState('performance') || {};
      const riskStatus = perf.riskStatus || {};
      const rawOpenPaper = journal.getOpenPaperTrades();
      const rawOpenLive = journal.getOpenLiveTrades();
      const allOpen = [...rawOpenPaper, ...rawOpenLive];

      const riskState = calculateRiskStatus(riskStatus, config, allOpen, config.accountBalance);
      return sendJson(res, 200, riskState);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 6. Strategy Configuration & Explanations
  if (method === 'GET' && pathname === '/api/dashboard/strategy') {
    try {
      const strat = registry.get('gps_v1') || {};
      const conditionsMeta = [
        { key: 'trend4H', name: '4H Trend Alignment', weight: 20, description: '4H Higher Highs/Lows structure and EMA trend direction' },
        { key: 'sweep', name: 'Liquidity Sweep', weight: 10, description: 'Key swing high or low swept to capture opposing liquidity' },
        { key: 'reclaim', name: 'Structure Reclaim', weight: 10, description: 'Price closes back inside key level indicating fakeout absorption' },
        { key: 'structure1H', name: '1H Structure', weight: 15, description: '1H trend consistency and swing alignment' },
        { key: 'trigger15M', name: '15M Trigger Bar', weight: 15, description: 'Confirmation candle close in direction of the setup' },
        { key: 'rsi', name: 'RSI Momentum', weight: 10, description: 'RSI(14) not overbought on Longs (<70) or oversold on Shorts (>30)' },
        { key: 'alligator', name: 'Williams Alligator', weight: 8, description: 'Jaw, Teeth, and Lips properly fanned in trend alignment' },
        { key: 'volume', name: 'Volume Ratio Surge', weight: 7, description: 'Current volume >= 1.2x of 20-period moving average' },
        { key: 'funding', name: 'Funding Rate Bias', weight: 3, description: 'Negative/neutral funding for Longs, positive/neutral for Shorts' },
        { key: 'openInterest', name: 'Open Interest Status', weight: 2, description: 'Open interest data verified available from exchange' },
      ];

      return sendJson(res, 200, {
        strategy: {
          id: strat.id || 'gps_v1',
          name: strat.name || 'GPS',
          version: strat.version || '1.0.0',
          enabled: strat.enabled !== false,
          timeframes: '4H / 1H / 15M',
          minScore: config.minScore,
          minRR: config.minRR,
          riskPerTradePct: (config.riskPerTrade * 100) + '%',
          leverage: config.defaultLeverage + 'x',
          conditions: conditionsMeta,
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 7. System Health Matrix
  if (method === 'GET' && pathname === '/api/dashboard/system') {
    try {
      const running = journal.getState('robot_running') || false;
      const lastScan = journal.getState('last_scan') || null;
      const scanCount = journal.getState('scan_count') || 0;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recon = journal.getState('reconciliation_status') || { status: 'HEALTHY' };
      const notifications = defaultNotifier.getRecentDeliveries();

      // Quick Bybit Ping
      let bybitStatus = 'CONNECTED';
      let bybitLatency = 0;
      const pingStart = Date.now();
      try {
        await bybit.getServerTime();
        bybitLatency = Date.now() - pingStart;
      } catch (e) {
        bybitStatus = 'ERROR';
      }

      // Quick Database Latency
      let dbStatus = 'HEALTHY';
      let dbLatency = 0;
      const dbStart = Date.now();
      try {
        journal.getDb().prepare('SELECT 1').get();
        dbLatency = Date.now() - dbStart;
      } catch (e) {
        dbStatus = 'ERROR';
      }

      return sendJson(res, 200, {
        marketData: {
          status: bybitStatus === 'CONNECTED' ? 'CONNECTED' : 'STALE',
          latencyMs: bybitLatency,
        },
        bybitApi: {
          status: bybitStatus,
          latencyMs: bybitLatency,
          environment: config.bybit.testnet ? 'TESTNET' : 'MAINNET',
        },
        database: {
          status: dbStatus,
          engine: 'SQLite WAL (Native)',
          latencyMs: dbLatency,
        },
        scanner: {
          status: running ? 'RUNNING' : 'STOPPED',
          lastScan,
          scanCount,
        },
        paperEngine: {
          status: 'RUNNING',
          openTradesCount: journal.getOpenPaperTrades().length,
        },
        liveEngine: {
          status: config.liveEnabled ? 'ENABLED' : 'LOCKED (SAFETY GATED)',
          mode: config.mode,
          state: emergencyStop ? 'EMERGENCY_STOP' : (config.isLive ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED'),
        },
        watchdog,
        reconciliation: recon,
        notifications: {
          channels: {
            telegram: config.notifications.telegram.enabled,
            email: config.notifications.email.enabled,
            whatsapp: config.notifications.whatsapp.enabled,
          },
          recentDeliveries: notifications.slice(0, 10),
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // 8. Chart Candlestick Endpoint with SL/TP/Entry Overlays
  if (method === 'GET' && pathname.startsWith('/api/dashboard/chart/')) {
    try {
      const symbol = pathname.replace('/api/dashboard/chart/', '').toUpperCase();
      const interval = parsedUrl.searchParams.get('interval') || '15m';
      const validIntervals = ['15m', '1h', '4h'];
      const tf = validIntervals.includes(interval) ? interval : '15m';

      const candles = await dataFeed.getCandles(symbol, tf, 100);

      // Check if there is an active trade or signal with trade levels
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const trade = openTrades.find(t => t.symbol === symbol);

      let levels = null;
      if (trade) {
        levels = {
          entry: trade.entry,
          stopLoss: trade.stop_loss || trade.stopLoss,
          takeProfit: trade.take_profit || trade.takeProfit,
          direction: trade.direction,
        };
      } else {
        const recentSig = journal.getRecentSignals(20).find(s => s.symbol === symbol && s.qualified);
        if (recentSig) {
          levels = {
            entry: recentSig.entry,
            stopLoss: recentSig.stop_loss || recentSig.stopLoss,
            takeProfit: recentSig.take_profit || recentSig.takeProfit,
            direction: recentSig.direction,
          };
        }
      }

      return sendJson(res, 200, {
        symbol,
        interval: tf,
        candles,
        levels,
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BACKWARD COMPATIBILITY ENDPOINTS (Preserved)
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/status') {
    try {
      const running = journal.getState('robot_running') || false;
      const mode = journal.getState('robot_mode') || config.mode;
      const marketCount = journal.getState('market_count') || 0;
      const scanCount = journal.getState('scan_count') || 0;
      const lastScan = journal.getState('last_scan') || null;
      const emergencyStop = journal.getState('emergency_stop') === true;
      const watchdogStatus = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const reconStatus = journal.getState('reconciliation_status') || { status: 'HEALTHY' };
      const perf = journal.getState('performance') || {
        mode,
        totalTrades: 0,
        openTrades: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        netPnl: 0,
        returnPct: 0,
        currentBalance: config.accountBalance,
      };

      const recentSignals = journal.getRecentSignals(15);
      const paperTrades = journal.getPaperTrades(25);
      const liveTrades = journal.getLiveTrades(25);
      const recentAlerts = journal.getRecentAlerts(20);

      let operationalState = 'PAPER';
      if (emergencyStop) operationalState = 'EMERGENCY_STOP';
      else if (mode === 'LIVE') operationalState = config.liveEnabled ? 'LIVE_AUTHORIZED' : 'LIVE_LOCKED';

      return sendJson(res, 200, {
        status: emergencyStop ? 'EMERGENCY_STOP' : (running ? 'RUNNING' : 'STOPPED'),
        operationalState,
        mode,
        liveTradingEnabled: config.liveEnabled,
        tradingEnabled: !emergencyStop,
        marketCount,
        scanCount,
        lastScan,
        performance: perf,
        watchdog: watchdogStatus,
        reconciliation: reconStatus,
        strategies: registry.status(),
        recentSignals,
        paperTrades,
        liveTrades,
        recentAlerts,
        config: {
          minScore: config.minScore,
          minRR: config.minRR,
          riskPerTrade: config.riskPerTrade,
          maxOpenPositions: config.maxOpenPositions,
          maxPortfolioExposure: config.maxPortfolioExposure,
          maxCorrelatedExposure: config.maxCorrelatedExposure,
          maxDailyLoss: config.maxDailyLoss,
          defaultLeverage: config.defaultLeverage,
        },
      });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/signals') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const signals = journal.getRecentSignals(limit);
      return sendJson(res, 200, { signals });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/trades') {
    try {
      const paper = journal.getPaperTrades(50);
      const live = journal.getLiveTrades(50);
      return sendJson(res, 200, { paper, live });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/alerts') {
    try {
      const alerts = journal.getRecentAlerts(50);
      const notifications = defaultNotifier.getRecentDeliveries();
      return sendJson(res, 200, { alerts, notifications });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // Control APIs
  if (method === 'POST' && pathname === '/api/control/start') {
    journal.setState('robot_running', true);
    journal.setState('emergency_stop', false);
    logger.info('Control Panel: Robot START requested');
    return sendJson(res, 200, { ok: true, message: 'Robot started flag set' });
  }

  if (method === 'POST' && pathname === '/api/control/stop') {
    journal.setState('robot_running', false);
    logger.info('Control Panel: Robot STOP requested');
    return sendJson(res, 200, { ok: true, message: 'Robot stopped flag set' });
  }

  if (method === 'POST' && pathname === '/api/control/emergency-stop') {
    journal.setState('emergency_stop', true);
    journal.setState('robot_running', false);
    logger.risk('Control Panel: EMERGENCY STOP triggered');
    await defaultNotifier.notifyEmergencyStop('Triggered from UI Control Panel');
    return sendJson(res, 200, { ok: true, message: 'EMERGENCY STOP activated' });
  }

  if (method === 'POST' && pathname === '/api/control/emergency-reset') {
    journal.setState('emergency_stop', false);
    logger.risk('Control Panel: Emergency stop reset');
    return sendJson(res, 200, { ok: true, message: 'Emergency stop state cleared' });
  }

  // Strategy Management
  if (method === 'POST' && pathname === '/api/strategy/rename') {
    const body = await parseBody(req);
    const { id, newName } = body;
    if (!id || !newName) return sendJson(res, 400, { error: 'id and newName required' });
    try {
      registry.rename(id, newName);
      const strat = registry.get(id);
      if (strat) journal.saveStrategy(strat);
      return sendJson(res, 200, { ok: true, id, newName });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/strategy/toggle') {
    const body = await parseBody(req);
    const { id, enabled } = body;
    if (!id || enabled === undefined) return sendJson(res, 400, { error: 'id and enabled required' });
    try {
      registry.setEnabled(id, !!enabled);
      const strat = registry.get(id);
      if (strat) journal.saveStrategy(strat);
      return sendJson(res, 200, { ok: true, id, enabled: !!enabled });
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PERSISTENT SCANNER ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/scanner/state') {
    return sendJson(res, 200, persistentScanner.getState());
  }

  if (method === 'POST' && pathname === '/api/scanner/start') {
    try {
      const state = await persistentScanner.start();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/pause') {
    try {
      const state = await persistentScanner.pause();
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/resume') {
    try {
      const state = await persistentScanner.resume();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/stop') {
    try {
      const state = await persistentScanner.stop();
      journal.setState('robot_running', false);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/restart') {
    try {
      const state = await persistentScanner.restartFullScan();
      journal.setState('robot_running', true);
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'POST' && pathname === '/api/scanner/rescan-failed') {
    try {
      const state = await persistentScanner.rescanFailed();
      return sendJson(res, 200, { ok: true, state });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // POSITION MANAGEMENT ENDPOINTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'POST' && (pathname.startsWith('/api/positions/close/') || pathname === '/api/positions/close')) {
    const body = await parseBody(req);
    const id = pathname.replace('/api/positions/close/', '') || body.id;
    if (!id || id === '/api/positions/close') {
      return sendJson(res, 400, { error: 'Position ID is required' });
    }
    const closed = paperEngine.closeTrade(id, body.reason || 'MANUAL_DASHBOARD_CLOSE');
    if (!closed) {
      return sendJson(res, 404, { error: `Position ${id} not found in open positions` });
    }
    return sendJson(res, 200, { ok: true, closed });
  }

  if (method === 'POST' && pathname === '/api/positions/close-all') {
    const body = await parseBody(req);
    const closed = paperEngine.closeAllTrades(body.reason || 'MANUAL_DASHBOARD_CLOSE_ALL');
    return sendJson(res, 200, { ok: true, count: closed.length, closed });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // CONFIGURATION UPDATE ENDPOINT ($100 default, $50-$500, leverage, risk)
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'POST' && pathname === '/api/config/update') {
    const body = await parseBody(req);
    if (body.accountBalance !== undefined) {
      const b = parseFloat(body.accountBalance);
      if (b > 0) {
        config.accountBalance = b;
        paperEngine.balance = b;
        paperEngine.riskEngine.cfg.accountBalance = b;
      }
    }
    if (body.riskPerTrade !== undefined) {
      const r = parseFloat(body.riskPerTrade);
      if (r > 0 && r <= 0.05) {
        config.riskPerTrade = r;
        paperEngine.riskEngine.cfg.riskPerTrade = r;
      }
    }
    if (body.defaultLeverage !== undefined) {
      const lev = parseInt(body.defaultLeverage, 10);
      if (lev >= 1 && lev <= 100) {
        config.defaultLeverage = lev;
      }
    }
    if (body.maxOpenPositions !== undefined) {
      const m = parseInt(body.maxOpenPositions, 10);
      if (m >= 1 && m <= 20) {
        config.maxOpenPositions = m;
        paperEngine.riskEngine.cfg.maxOpenPositions = m;
      }
    }
    if (body.maxDailyLoss !== undefined) {
      const mdl = parseFloat(body.maxDailyLoss);
      if (mdl > 0 && mdl <= 0.20) {
        config.maxDailyLoss = mdl;
        paperEngine.riskEngine.cfg.maxDailyLoss = mdl;
      }
    }

    logger.info(`Dashboard config updated: Balance=$${config.accountBalance}, Risk=${(config.riskPerTrade * 100).toFixed(2)}%, Lev=${config.defaultLeverage}x`);

    return sendJson(res, 200, {
      ok: true,
      config: {
        accountBalance: config.accountBalance,
        riskPerTrade: config.riskPerTrade,
        defaultLeverage: config.defaultLeverage,
        maxOpenPositions: config.maxOpenPositions,
        maxDailyLoss: config.maxDailyLoss,
      },
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // GLOBAL OPPORTUNITY BOARD & RECOMMENDATIONS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/dashboard/opportunities') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const rawSignals = journal.getRecentSignals(limit);
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const ranked = rankOpportunities(rawSignals, { openPositions: openTrades });
      return sendJson(res, 200, { count: ranked.length, opportunities: ranked });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/dashboard/recommendations') {
    try {
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const rawSignals = journal.getRecentSignals(30);
      const perf = journal.getState('performance') || {};
      const watchdog = journal.getState('watchdog_status') || { status: 'HEALTHY' };
      const recs = generateRecommendations({
        openPositions: openTrades,
        recentSignals: rawSignals,
        performance: perf,
        config,
        systemHealth: { watchdog },
      });
      return sendJson(res, 200, recs);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // JOURNAL EXPORT (CSV / JSON)
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/journal/export') {
    try {
      const format = (parsedUrl.searchParams.get('format') || 'json').toLowerCase();
      const paperTrades = journal.getPaperTrades(2000);
      const liveTrades = journal.getLiveTrades(2000);
      const allTrades = [...paperTrades, ...liveTrades];

      if (format === 'csv') {
        const headers = [
          'id', 'timestamp', 'date', 'symbol', 'assetClass', 'strategy', 'regime', 'direction',
          'entry', 'exitPrice', 'stopLoss', 'takeProfit', 'positionSize', 'leverage',
          'accountBalance', 'riskPct', 'riskReward', 'fee', 'slippage', 'pnl',
          'outcome', 'exitReason', 'score', 'mode'
        ];

        const rows = allTrades.map(t => {
          const dt = t.close_time ? new Date(t.close_time).toISOString() : (t.open_time ? new Date(t.open_time).toISOString() : '');
          return [
            `"${t.id || ''}"`,
            t.close_time || t.open_time || '',
            `"${dt}"`,
            `"${t.symbol || ''}"`,
            `"${t.asset_class || 'CRYPTO'}"`,
            `"${t.strategy_name || t.strategy_id || 'GPS'}"`,
            `"${typeof t.regime === 'object' ? JSON.stringify(t.regime) : (t.regime || '')}"`,
            `"${t.direction || ''}"`,
            t.entry || '',
            t.exit_price || '',
            t.stop_loss || '',
            t.take_profit || '',
            t.position_size || '',
            config.defaultLeverage,
            config.accountBalance,
            (config.riskPerTrade * 100) + '%',
            t.risk_reward || '',
            t.fee || 0,
            t.slippage || 0,
            t.pnl || 0,
            `"${t.outcome || ''}"`,
            `"${t.exit_reason || ''}"`,
            t.score || '',
            `"${t.mode || 'PAPER'}"`,
          ].join(',');
        });

        const csvString = [headers.join(','), ...rows].join('\n');
        res.writeHead(200, {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': `attachment; filename="journal_export_${Date.now()}.csv"`,
          'Cache-Control': 'no-cache',
        });
        return res.end(csvString);
      }

      // Default JSON export
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="journal_export_${Date.now()}.json"`,
        'Cache-Control': 'no-cache',
      });
      return res.end(JSON.stringify({
        exportedAt: Date.now(),
        accountBalance: config.accountBalance,
        totalTrades: allTrades.length,
        trades: allTrades,
      }, null, 2));
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SYSTEM SNAPSHOTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'POST' && pathname === '/api/snapshot/save') {
    try {
      const openTrades = [...journal.getOpenPaperTrades(), ...journal.getOpenLiveTrades()];
      const scannerState = persistentScanner.getState();
      const rawSignals = journal.getRecentSignals(10);
      const ranked = rankOpportunities(rawSignals, { openPositions: openTrades });

      const snapshot = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        accountState: {
          balance: config.accountBalance,
          defaultLeverage: config.defaultLeverage,
          riskPerTrade: config.riskPerTrade,
          maxDailyLoss: config.maxDailyLoss,
        },
        positions: openTrades,
        scannerState,
        topOpportunities: ranked.slice(0, 5),
        riskSettings: {
          maxOpenPositions: config.maxOpenPositions,
          maxPortfolioExposure: config.maxPortfolioExposure,
          maxCorrelatedExposure: config.maxCorrelatedExposure,
        },
        summary: `Snapshot at ${new Date().toISOString()} | ${openTrades.length} open positions | Scanner: ${scannerState.progressPct}%`,
      };

      journal.saveSnapshot(snapshot);
      logger.info(`System snapshot saved: ${snapshot.id}`);
      return sendJson(res, 200, { ok: true, snapshotId: snapshot.id, snapshot });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/snapshot/list') {
    try {
      const list = journal.getSnapshots(20);
      return sendJson(res, 200, { count: list.length, snapshots: list });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname.startsWith('/api/snapshot/')) {
    try {
      const id = pathname.replace('/api/snapshot/', '');
      const list = journal.getSnapshots(100);
      const found = list.find(s => s.id === id);
      if (!found) return sendJson(res, 404, { error: 'Snapshot not found' });
      return sendJson(res, 200, found);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // LEARNING, AUTOPSIES & SIMILARITY
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/learning/autopsies') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const list = journal.getAutopsies(limit);
      return sendJson(res, 200, { count: list.length, autopsies: list });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  if (method === 'GET' && pathname === '/api/learning/similarity') {
    try {
      const symbol = parsedUrl.searchParams.get('symbol') || '';
      const strategyId = parsedUrl.searchParams.get('strategy') || '';
      const direction = parsedUrl.searchParams.get('direction') || '';
      const regime = parsedUrl.searchParams.get('regime') || '';

      const match = autopsyEngine.findSimilarSetups({
        symbol,
        strategyId,
        direction,
        regime,
      });

      return sendJson(res, 200, match);
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // EVENT BUS STREAM / RECENT EVENTS
  // ══════════════════════════════════════════════════════════════════════════

  if (method === 'GET' && pathname === '/api/events/recent') {
    try {
      const limit = parseInt(parsedUrl.searchParams.get('limit') || '50', 10);
      const filter = parsedUrl.searchParams.get('event') || null;
      const events = eventBus.getRecentEvents(limit, filter);
      return sendJson(res, 200, { count: events.length, events });
    } catch (err) {
      return sendJson(res, 500, { error: err.message });
    }
  }

  // Fallback 404
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Endpoint Not Found' }));
});

if (require.main === module) {
  const port = config.dashboardPort || 3000;
  server.listen(port, () => {
    logger.info(`GPS Command Center Dashboard running on http://localhost:${port}`);
  });
}

module.exports = server;
