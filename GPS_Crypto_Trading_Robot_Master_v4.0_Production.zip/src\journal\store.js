'use strict';

const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');

// Ensure data dir exists
const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'robot.db');

let db;

function getDb() {
  if (!db) {
    db = new DatabaseSync(DB_PATH);
    db.exec('PRAGMA journal_mode = WAL;');
    db.exec('PRAGMA busy_timeout = 5000;');
    db.exec('PRAGMA foreign_keys = ON;');
    initSchema(db);
  }
  return db;
}

function initSchema(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS strategies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      version TEXT NOT NULL,
      enabled INTEGER DEFAULT 1,
      config TEXT,
      created_at INTEGER,
      updated_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS signals (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      score INTEGER,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      risk_reward REAL,
      conditions TEXT,
      regime TEXT,
      cluster TEXT,
      qualified INTEGER,
      decision TEXT,
      rejection_reason TEXT,
      timestamp INTEGER,
      mode TEXT
    );

    CREATE TABLE IF NOT EXISTS paper_trades (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      exit_price REAL,
      position_size REAL,
      pnl REAL,
      fee REAL,
      slippage REAL,
      outcome TEXT,
      exit_reason TEXT,
      score INTEGER,
      risk_reward REAL,
      regime TEXT,
      cluster TEXT,
      open_time INTEGER,
      close_time INTEGER,
      duration_ms INTEGER,
      mode TEXT DEFAULT 'PAPER'
    );

    CREATE TABLE IF NOT EXISTS live_trades (
      id TEXT PRIMARY KEY,
      order_id TEXT,
      strategy_id TEXT,
      strategy_name TEXT,
      strategy_version TEXT,
      symbol TEXT,
      direction TEXT,
      entry REAL,
      stop_loss REAL,
      take_profit REAL,
      exit_price REAL,
      position_size REAL,
      pnl REAL,
      fee REAL,
      slippage REAL,
      outcome TEXT,
      exit_reason TEXT,
      score INTEGER,
      risk_reward REAL,
      regime TEXT,
      cluster TEXT,
      open_time INTEGER,
      close_time INTEGER,
      mode TEXT DEFAULT 'LIVE'
    );

    CREATE TABLE IF NOT EXISTS backtest_runs (
      id TEXT PRIMARY KEY,
      strategy_id TEXT,
      strategy_version TEXT,
      symbol TEXT,
      period TEXT,
      config TEXT,
      result TEXT,
      created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS robot_state (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT,
      message TEXT,
      channel TEXT,
      sent INTEGER DEFAULT 0,
      created_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS reconciliation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      status TEXT,
      discrepancies TEXT,
      timestamp INTEGER
    );

    CREATE TABLE IF NOT EXISTS scan_sessions (
      id TEXT PRIMARY KEY,
      status TEXT NOT NULL,
      started_at INTEGER,
      updated_at INTEGER,
      current_asset_class TEXT,
      current_instrument TEXT,
      total_markets INTEGER DEFAULT 0,
      analyzed_count INTEGER DEFAULT 0,
      remaining_count INTEGER DEFAULT 0,
      qualified_count INTEGER DEFAULT 0,
      rejected_count INTEGER DEFAULT 0,
      error_count INTEGER DEFAULT 0,
      completed_symbols TEXT,
      failed_symbols TEXT,
      qualified_setups TEXT,
      config TEXT
    );

    CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY,
      timestamp INTEGER NOT NULL,
      account_state TEXT,
      positions TEXT,
      scanner_state TEXT,
      top_opportunities TEXT,
      risk_settings TEXT,
      summary TEXT
    );

    CREATE TABLE IF NOT EXISTS trade_autopsies (
      id TEXT PRIMARY KEY,
      trade_id TEXT UNIQUE NOT NULL,
      symbol TEXT NOT NULL,
      strategy_id TEXT,
      direction TEXT,
      regime TEXT,
      outcome TEXT,
      pnl REAL,
      r_multiple REAL,
      mfe REAL,
      mae REAL,
      mfe_r REAL,
      mae_r REAL,
      sl_tightness TEXT,
      tp_ambition TEXT,
      trailing_efficiency TEXT,
      lessons TEXT,
      created_at INTEGER NOT NULL
    );
  `);

  // Safe non-destructive column migrations
  const migrations = [
    'ALTER TABLE signals ADD COLUMN regime TEXT;',
    'ALTER TABLE signals ADD COLUMN cluster TEXT;',
    'ALTER TABLE signals ADD COLUMN asset_class TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN regime TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN cluster TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN asset_class TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN exit_reason TEXT;',
    'ALTER TABLE paper_trades ADD COLUMN slippage REAL;',
    'ALTER TABLE paper_trades ADD COLUMN trailing_stop REAL;',
    'ALTER TABLE live_trades ADD COLUMN asset_class TEXT;',
    'ALTER TABLE live_trades ADD COLUMN trailing_stop REAL;',
  ];

  for (const m of migrations) {
    try {
      database.exec(m);
    } catch (_) {
      // Column already exists
    }
  }
}

// ── Strategy ──────────────────────────────────────────────────────────────

function saveStrategy(strategy) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO strategies (id, name, version, enabled, config, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    strategy.id,
    strategy.name,
    strategy.version,
    strategy.enabled ? 1 : 0,
    JSON.stringify(strategy.cfg || {}),
    Date.now()
  );
}

function getStrategies() {
  const stmt = getDb().prepare('SELECT * FROM strategies');
  return stmt.all();
}

// ── Signal ────────────────────────────────────────────────────────────────

function saveSignal(signal) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR IGNORE INTO signals
    (id, strategy_id, strategy_name, strategy_version, symbol, direction, score,
     entry, stop_loss, take_profit, risk_reward, conditions, regime, cluster, qualified, decision, rejection_reason, timestamp, mode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    crypto.randomUUID(),
    signal.strategyId, signal.strategyName, signal.strategyVersion,
    signal.symbol, signal.direction, signal.score,
    signal.entry, signal.stopLoss, signal.takeProfit, signal.riskReward,
    JSON.stringify(signal.conditions || {}),
    typeof signal.regime === 'object' ? JSON.stringify(signal.regime) : (signal.regime || null),
    signal.cluster || null,
    signal.qualified ? 1 : 0,
    signal.decision || null, signal.rejectionReason || null,
    signal.timestamp || Date.now(),
    signal.mode || 'PAPER'
  );
}

function getRecentSignals(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM signals ORDER BY timestamp DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Paper Trades ──────────────────────────────────────────────────────────

function savePaperTrade(trade) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO paper_trades
    (id, strategy_id, strategy_name, strategy_version, symbol, direction, entry, stop_loss,
     take_profit, exit_price, position_size, pnl, fee, slippage, outcome, exit_reason, score, risk_reward,
     regime, cluster, open_time, close_time, duration_ms, mode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    trade.id || crypto.randomUUID(),
    trade.strategyId, trade.strategyName, trade.strategyVersion,
    trade.symbol, trade.direction, trade.entry, trade.stopLoss,
    trade.takeProfit, trade.exitPrice || null,
    trade.positionSize, trade.pnl || null, trade.fee || null, trade.slippage || null,
    trade.outcome || null, trade.exitReason || null, trade.score, trade.riskReward,
    typeof trade.regime === 'object' ? JSON.stringify(trade.regime) : (trade.regime || null),
    trade.cluster || null,
    trade.openTime, trade.closeTime || null, trade.durationMs || null,
    'PAPER'
  );
}

function getPaperTrades(limit = 100) {
  const stmt = getDb().prepare('SELECT * FROM paper_trades ORDER BY open_time DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Live Trades ───────────────────────────────────────────────────────────

function saveLiveTrade(trade) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO live_trades
    (id, order_id, strategy_id, strategy_name, strategy_version, symbol, direction, entry, stop_loss,
     take_profit, exit_price, position_size, pnl, fee, slippage, outcome, exit_reason, score, risk_reward,
     regime, cluster, open_time, close_time, mode)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    trade.id || crypto.randomUUID(),
    trade.orderId || null,
    trade.strategyId, trade.strategyName, trade.strategyVersion,
    trade.symbol, trade.direction, trade.entry, trade.stopLoss,
    trade.takeProfit, trade.exitPrice || null,
    trade.positionSize, trade.pnl || null, trade.fee || null, trade.slippage || null,
    trade.outcome || null, trade.exitReason || null, trade.score, trade.riskReward,
    typeof trade.regime === 'object' ? JSON.stringify(trade.regime) : (trade.regime || null),
    trade.cluster || null,
    trade.openTime, trade.closeTime || null,
    'LIVE'
  );
}

function getLiveTrades(limit = 100) {
  const stmt = getDb().prepare('SELECT * FROM live_trades ORDER BY open_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getOpenPaperTrades() {
  const stmt = getDb().prepare('SELECT * FROM paper_trades WHERE close_time IS NULL AND outcome IS NULL ORDER BY open_time DESC');
  return stmt.all();
}

function getClosedPaperTrades(limit = 500) {
  const stmt = getDb().prepare('SELECT * FROM paper_trades WHERE close_time IS NOT NULL AND outcome IS NOT NULL ORDER BY close_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getOpenLiveTrades() {
  const stmt = getDb().prepare('SELECT * FROM live_trades WHERE close_time IS NULL AND outcome IS NULL ORDER BY open_time DESC');
  return stmt.all();
}

function getClosedLiveTrades(limit = 500) {
  const stmt = getDb().prepare('SELECT * FROM live_trades WHERE close_time IS NOT NULL AND outcome IS NOT NULL ORDER BY close_time DESC LIMIT ?');
  return stmt.all(limit);
}

function getAllTrades(limit = 500) {
  const paper = getPaperTrades(limit);
  const live = getLiveTrades(limit);
  const all = [...paper, ...live];
  all.sort((a, b) => (b.open_time || 0) - (a.open_time || 0));
  return all.slice(0, limit);
}

// ── Backtest ──────────────────────────────────────────────────────────────

function saveBacktestRun(run) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT INTO backtest_runs (id, strategy_id, strategy_version, symbol, period, config, result, created_at)
    VALUES (?,?,?,?,?,?,?,?)
  `);
  stmt.run(
    crypto.randomUUID(),
    run.strategyId || 'gps_v1', run.strategyVersion || '1.0.0',
    run.symbol, run.period,
    JSON.stringify(run.config || {}),
    JSON.stringify(run.result || {}),
    Date.now()
  );
}

function getBacktestRuns(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM backtest_runs ORDER BY created_at DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Robot State ───────────────────────────────────────────────────────────

function setState(key, value) {
  const stmt = getDb().prepare(`
    INSERT OR REPLACE INTO robot_state (key, value, updated_at) VALUES (?, ?, ?)
  `);
  stmt.run(key, JSON.stringify(value), Date.now());
}

function getState(key) {
  const stmt = getDb().prepare('SELECT value FROM robot_state WHERE key = ?');
  const row = stmt.get(key);
  return row ? JSON.parse(row.value) : null;
}

// ── Alerts & Reconciliation ───────────────────────────────────────────────

function logAlert(type, message, channel = 'system', sent = false) {
  const stmt = getDb().prepare(`
    INSERT INTO alerts (type, message, channel, sent, created_at) VALUES (?,?,?,?,?)
  `);
  stmt.run(type, message, channel, sent ? 1 : 0, Date.now());
}

function getRecentAlerts(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?');
  return stmt.all(limit);
}

function saveReconciliationLog(log) {
  const stmt = getDb().prepare(`
    INSERT INTO reconciliation_logs (status, discrepancies, timestamp) VALUES (?,?,?)
  `);
  stmt.run(log.status, JSON.stringify(log.discrepancies || []), log.timestamp || Date.now());
}

function getReconciliationLogs(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM reconciliation_logs ORDER BY timestamp DESC LIMIT ?');
  return stmt.all(limit);
}

// ── Persistent Scan Sessions ──────────────────────────────────────────────

function saveScanSession(session) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO scan_sessions
    (id, status, started_at, updated_at, current_asset_class, current_instrument,
     total_markets, analyzed_count, remaining_count, qualified_count, rejected_count, error_count,
     completed_symbols, failed_symbols, qualified_setups, config)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    session.id || session.sessionId || crypto.randomUUID(),
    session.status || 'IDLE',
    session.startedAt || Date.now(),
    Date.now(),
    session.currentAssetClass || 'ALL',
    session.currentInstrument || null,
    session.totalMarkets || 0,
    session.analyzedCount || 0,
    session.remainingCount || 0,
    session.qualifiedCount || 0,
    session.rejectedCount || 0,
    session.errorCount || 0,
    JSON.stringify(session.completedSymbols || []),
    JSON.stringify(session.failedSymbols || []),
    JSON.stringify(session.qualifiedSetups || []),
    JSON.stringify(session.config || {})
  );
}

function getLatestScanSession() {
  const stmt = getDb().prepare('SELECT * FROM scan_sessions ORDER BY updated_at DESC LIMIT 1');
  const row = stmt.get();
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    startedAt: row.started_at,
    updatedAt: row.updated_at,
    currentAssetClass: row.current_asset_class,
    currentInstrument: row.current_instrument,
    totalMarkets: row.total_markets,
    analyzedCount: row.analyzed_count,
    remainingCount: row.remaining_count,
    qualifiedCount: row.qualified_count,
    rejectedCount: row.rejected_count,
    errorCount: row.error_count,
    completedSymbols: JSON.parse(row.completed_symbols || '[]'),
    failedSymbols: JSON.parse(row.failed_symbols || '[]'),
    qualifiedSetups: JSON.parse(row.qualified_setups || '[]'),
    config: JSON.parse(row.config || '{}'),
  };
}

function getScanSession(id) {
  const stmt = getDb().prepare('SELECT * FROM scan_sessions WHERE id = ?');
  const row = stmt.get(id);
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    startedAt: row.started_at,
    updatedAt: row.updated_at,
    currentAssetClass: row.current_asset_class,
    currentInstrument: row.current_instrument,
    totalMarkets: row.total_markets,
    analyzedCount: row.analyzed_count,
    remainingCount: row.remaining_count,
    qualifiedCount: row.qualified_count,
    rejectedCount: row.rejected_count,
    errorCount: row.error_count,
    completedSymbols: JSON.parse(row.completed_symbols || '[]'),
    failedSymbols: JSON.parse(row.failed_symbols || '[]'),
    qualifiedSetups: JSON.parse(row.qualified_setups || '[]'),
    config: JSON.parse(row.config || '{}'),
  };
}

// ── Snapshots ─────────────────────────────────────────────────────────────

function saveSnapshot(snapshot) {
  const database = getDb();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO snapshots
    (id, timestamp, account_state, positions, scanner_state, top_opportunities, risk_settings, summary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    snapshot.id || crypto.randomUUID(),
    snapshot.timestamp || Date.now(),
    JSON.stringify(snapshot.accountState || {}),
    JSON.stringify(snapshot.positions || []),
    JSON.stringify(snapshot.scannerState || {}),
    JSON.stringify(snapshot.topOpportunities || []),
    JSON.stringify(snapshot.riskSettings || {}),
    snapshot.summary || ''
  );
}

function getSnapshots(limit = 20) {
  const stmt = getDb().prepare('SELECT * FROM snapshots ORDER BY timestamp DESC LIMIT ?');
  const rows = stmt.all(limit);
  return rows.map(r => ({
    id: r.id,
    timestamp: r.timestamp,
    accountState: JSON.parse(r.account_state || '{}'),
    positions: JSON.parse(r.positions || '[]'),
    scannerState: JSON.parse(r.scanner_state || '{}'),
    topOpportunities: JSON.parse(r.top_opportunities || '[]'),
    riskSettings: JSON.parse(r.risk_settings || '{}'),
    summary: r.summary,
  }));
}

function getSnapshot(id) {
  const stmt = getDb().prepare('SELECT * FROM snapshots WHERE id = ?');
  const r = stmt.get(id);
  if (!r) return null;
  return {
    id: r.id,
    timestamp: r.timestamp,
    accountState: JSON.parse(r.account_state || '{}'),
    positions: JSON.parse(r.positions || '[]'),
    scannerState: JSON.parse(r.scanner_state || '{}'),
    topOpportunities: JSON.parse(r.top_opportunities || '[]'),
    riskSettings: JSON.parse(r.risk_settings || '{}'),
    summary: r.summary,
  };
}

// ── Trade Autopsies ────────────────────────────────────────────────────────

function saveAutopsy(autopsy) {
  const database = getDb();
  const id = autopsy.id || crypto.randomUUID();
  const stmt = database.prepare(`
    INSERT OR REPLACE INTO trade_autopsies (
      id, trade_id, symbol, strategy_id, direction, regime, outcome,
      pnl, r_multiple, mfe, mae, mfe_r, mae_r,
      sl_tightness, tp_ambition, trailing_efficiency, lessons, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(
    id,
    autopsy.tradeId,
    autopsy.symbol,
    autopsy.strategyId || null,
    autopsy.direction || null,
    autopsy.regime || null,
    autopsy.outcome || null,
    autopsy.pnl || 0,
    autopsy.rMultiple || 0,
    autopsy.mfe || 0,
    autopsy.mae || 0,
    autopsy.mfeR || 0,
    autopsy.maeR || 0,
    autopsy.slTightness || 'OPTIMAL',
    autopsy.tpAmbition || 'REALISTIC',
    autopsy.trailingEfficiency || 'NEUTRAL',
    JSON.stringify(autopsy.lessons || []),
    autopsy.createdAt || Date.now()
  );

  return id;
}

function getAutopsies(limit = 50) {
  const stmt = getDb().prepare('SELECT * FROM trade_autopsies ORDER BY created_at DESC LIMIT ?');
  const rows = stmt.all(limit);
  return rows.map(r => ({
    id: r.id,
    tradeId: r.trade_id,
    symbol: r.symbol,
    strategyId: r.strategy_id,
    direction: r.direction,
    regime: r.regime,
    outcome: r.outcome,
    pnl: r.pnl,
    rMultiple: r.r_multiple,
    mfe: r.mfe,
    mae: r.mae,
    mfeR: r.mfe_r,
    maeR: r.mae_r,
    slTightness: r.sl_tightness,
    tpAmbition: r.tp_ambition,
    trailingEfficiency: r.trailing_efficiency,
    lessons: JSON.parse(r.lessons || '[]'),
    createdAt: r.created_at,
  }));
}

function getAutopsyByTradeId(tradeId) {
  const stmt = getDb().prepare('SELECT * FROM trade_autopsies WHERE trade_id = ?');
  const r = stmt.get(tradeId);
  if (!r) return null;
  return {
    id: r.id,
    tradeId: r.trade_id,
    symbol: r.symbol,
    strategyId: r.strategy_id,
    direction: r.direction,
    regime: r.regime,
    outcome: r.outcome,
    pnl: r.pnl,
    rMultiple: r.r_multiple,
    mfe: r.mfe,
    mae: r.mae,
    mfeR: r.mfe_r,
    maeR: r.mae_r,
    slTightness: r.sl_tightness,
    tpAmbition: r.tp_ambition,
    trailingEfficiency: r.trailing_efficiency,
    lessons: JSON.parse(r.lessons || '[]'),
    createdAt: r.created_at,
  };
}

module.exports = {
  getDb,
  saveStrategy,
  getStrategies,
  saveSignal,
  getRecentSignals,
  savePaperTrade,
  getPaperTrades,
  getOpenPaperTrades,
  getClosedPaperTrades,
  saveLiveTrade,
  getLiveTrades,
  getOpenLiveTrades,
  getClosedLiveTrades,
  getAllTrades,
  saveBacktestRun,
  getBacktestRuns,
  setState,
  getState,
  logAlert,
  getRecentAlerts,
  saveReconciliationLog,
  getReconciliationLogs,
  saveScanSession,
  getLatestScanSession,
  getScanSession,
  saveSnapshot,
  getSnapshots,
  getSnapshot,
  saveAutopsy,
  getAutopsies,
  getAutopsyByTradeId,
};
