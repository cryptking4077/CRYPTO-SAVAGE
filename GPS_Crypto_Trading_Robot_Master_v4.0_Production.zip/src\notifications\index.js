'use strict';

const config = require('../config');
const logger = require('../utils/logger');
const telegram = require('./telegram');
const journal = require('../journal/store');

const sentHashes = new Map();
const DEFAULT_COOLDOWN_MS = 5 * 60 * 1000; // 5 min default

function hash(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) {
    h = (Math.imul(31, h) + text.charCodeAt(i)) | 0;
  }
  return h.toString();
}

/**
 * Unified Multi-Channel Notification Service
 * Dispatches trading events to Telegram, Email, and WhatsApp.
 */
class NotificationService {
  constructor(options = {}) {
    this.cfg = options.config || config.notifications || {};
    this.deliveryHistory = [];
  }

  /**
   * Dispatch a notification to all configured providers
   *
   * @param {object} event
   * @param {string} event.type - QUALIFIED_SIGNAL | TRADE_OPENED | TRADE_CLOSED | RISK_BLOCK | EMERGENCY_STOP | RECONCILIATION_FAILURE | WATCHDOG_WARNING | INFO
   * @param {string} event.severity - INFO | WARNING | CRITICAL | EMERGENCY
   * @param {string} event.title - Short title
   * @param {string} event.message - Detailed text
   * @param {object} event.data - Optional payload
   * @param {boolean} event.force - Bypass deduplication
   * @returns {Promise<object>} Delivery report per channel
   */
  async dispatch(event) {
    const {
      type = 'INFO',
      severity = 'INFO',
      title = 'NOTIFICATION',
      message = '',
      data = null,
      force = false,
    } = event;

    const fullText = `[${severity}] ${title}\n${message}`;
    const key = `${type}_${hash(fullText)}`;
    const now = Date.now();

    // Deduplication check
    if (!force && sentHashes.has(key) && (now - sentHashes.get(key)) < DEFAULT_COOLDOWN_MS) {
      logger.alert(`Notification duplicate suppressed: ${title}`);
      return { skipped: true, reason: 'COOLDOWN_ACTIVE' };
    }
    sentHashes.set(key, now);

    const report = {
      type,
      severity,
      title,
      timestamp: now,
      channels: {},
    };

    // 1. Dispatch to Telegram
    try {
      let formattedTg = `<b>${title}</b>\n${message}`;
      if (severity === 'EMERGENCY' || severity === 'CRITICAL') {
        formattedTg = `🚨 <b>${severity} ALERT</b>\n\n${formattedTg}`;
      }
      const tgSuccess = await telegram.send(formattedTg, force);
      report.channels.telegram = { delivered: tgSuccess };
    } catch (err) {
      report.channels.telegram = { delivered: false, error: err.message };
    }

    // 2. Dispatch to Email Provider (Webhook interface)
    if (this.cfg.email?.enabled && this.cfg.email.webhookUrl) {
      try {
        const res = await fetch(this.cfg.email.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            recipient: this.cfg.email.recipient,
            subject: `[GPS Robot] [${severity}] ${title}`,
            text: message,
            data,
            timestamp: now,
          }),
          signal: AbortSignal.timeout(5000),
        });
        report.channels.email = { delivered: res.ok, status: res.status };
      } catch (err) {
        report.channels.email = { delivered: false, error: err.message };
      }
    } else {
      report.channels.email = { configured: false };
    }

    // 3. Dispatch to WhatsApp Provider (Webhook interface)
    if (this.cfg.whatsapp?.enabled && this.cfg.whatsapp.webhookUrl) {
      try {
        const res = await fetch(this.cfg.whatsapp.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: this.cfg.whatsapp.phoneNumber,
            message: `*${title}* (${severity})\n${message}`,
            data,
            timestamp: now,
          }),
          signal: AbortSignal.timeout(5000),
        });
        report.channels.whatsapp = { delivered: res.ok, status: res.status };
      } catch (err) {
        report.channels.whatsapp = { delivered: false, error: err.message };
      }
    } else {
      report.channels.whatsapp = { configured: false };
    }

    // Log alert into persistent SQLite journal
    const anyDelivered = Object.values(report.channels).some(c => c.delivered === true);
    journal.logAlert(type, `${title}: ${message}`, 'multi-channel', anyDelivered);

    this.deliveryHistory.unshift(report);
    if (this.deliveryHistory.length > 50) this.deliveryHistory.pop();

    return report;
  }

  // Typed notification helpers
  async notifySignal(signal, mode = 'PAPER') {
    return this.dispatch({
      type: 'QUALIFIED_SIGNAL',
      severity: 'INFO',
      title: `GPS Signal: ${signal.symbol} ${signal.direction}`,
      message: `Score: ${signal.score}/100 | R:R: ${signal.riskReward}\nEntry: ${signal.entry} | SL: ${signal.stopLoss} | TP: ${signal.takeProfit}\nRegime: ${signal.regime?.regime || 'N/A'}\nMode: ${mode}`,
      data: signal,
    });
  }

  async notifyTradeOpened(trade) {
    return this.dispatch({
      type: 'TRADE_OPENED',
      severity: 'INFO',
      title: `Trade Opened: ${trade.symbol} ${trade.direction}`,
      message: `Entry: ${trade.entry} | Size: ${trade.positionSize}\nSL: ${trade.stopLoss} | TP: ${trade.takeProfit}\nCluster: ${trade.cluster || 'ALT'} | Mode: ${trade.mode}`,
      data: trade,
    });
  }

  async notifyTradeClosed(trade) {
    const icon = trade.outcome === 'WIN' ? 'WIN' : 'LOSS';
    return this.dispatch({
      type: 'TRADE_CLOSED',
      severity: 'INFO',
      title: `Trade Closed (${icon}): ${trade.symbol} ${trade.direction}`,
      message: `Result: ${trade.outcome} | P&L: ${trade.pnl >= 0 ? '+' : ''}${trade.pnl}\nExit: ${trade.exitPrice} | Reason: ${trade.exitReason || 'Target/Stop Hit'}`,
      data: trade,
    });
  }

  async notifyEmergencyStop(reason = 'Manual Trigger') {
    return this.dispatch({
      type: 'EMERGENCY_STOP',
      severity: 'EMERGENCY',
      title: 'EMERGENCY STOP ACTIVATED',
      message: `All new trades are frozen immediately. Reason: ${reason}`,
      force: true,
    });
  }

  async notifyReconciliationFailure(discrepancies) {
    return this.dispatch({
      type: 'RECONCILIATION_FAILURE',
      severity: 'CRITICAL',
      title: 'Exchange Reconciliation Mismatch',
      message: `Detected ${discrepancies.length} discrepancy items. New orders blocked.`,
      data: discrepancies,
      force: true,
    });
  }

  async notifyWatchdogWarning(issues) {
    return this.dispatch({
      type: 'WATCHDOG_WARNING',
      severity: 'WARNING',
      title: 'Watchdog System Warning',
      message: `Unhealthy conditions detected: ${issues.join(', ')}`,
      data: issues,
    });
  }

  getRecentDeliveries() {
    return this.deliveryHistory;
  }
}

// Global default instance
const defaultNotifier = new NotificationService();

module.exports = {
  NotificationService,
  defaultNotifier,
};
