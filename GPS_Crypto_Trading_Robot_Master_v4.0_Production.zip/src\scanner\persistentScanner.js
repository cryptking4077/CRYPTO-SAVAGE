'use strict';

const crypto = require('crypto');
const config = require('../config');
const logger = require('../utils/logger');
const journal = require('../journal/store');
const { discoverMarkets } = require('../market/universe');
const dataFeed = require('../market/dataFeed');
const { createDefaultRegistry, StrategyRouter } = require('../strategy/registry');
const { scoreSignal } = require('../scoring/engine');
const { eventBus } = require('../events/bus');

/**
 * Persistent Checkpointed Market Scanner
 * Maintains state in SQLite scan_sessions table.
 * Survives browser refresh, closure, and process restart.
 */
class PersistentScanner {
  constructor(options = {}) {
    this.concurrency = options.concurrency || config.scanConcurrency || 8;
    this.registry = options.registry || createDefaultRegistry();
    this.router = options.router || new StrategyRouter(this.registry);
    this.markets = [];
    this.session = null;
    this._isProcessing = false;
    this._pauseRequested = false;
    this._stopRequested = false;
    this._loopTimer = null;

    // Load or initialize state
    this._initSession();
  }

  _initSession() {
    const existing = journal.getLatestScanSession();
    if (existing && (existing.status === 'RUNNING' || existing.status === 'PAUSED')) {
      this.session = existing;
      // Mark as PAUSED on startup so user can choose to resume or restart
      if (this.session.status === 'RUNNING') {
        this.session.status = 'PAUSED';
        this._saveCheckpoint();
      }
      logger.info(`PersistentScanner: Reconnected to session ${this.session.id} (${this.session.analyzedCount}/${this.session.totalMarkets} analyzed)`);
    } else {
      this.session = this._createNewSession();
    }
  }

  _createNewSession() {
    return {
      id: crypto.randomUUID(),
      status: 'IDLE',
      startedAt: Date.now(),
      updatedAt: Date.now(),
      currentAssetClass: 'ALL',
      currentInstrument: null,
      totalMarkets: 0,
      analyzedCount: 0,
      remainingCount: 0,
      qualifiedCount: 0,
      rejectedCount: 0,
      errorCount: 0,
      completedSymbols: [],
      failedSymbols: [],
      qualifiedSetups: [],
      config: {
        concurrency: this.concurrency,
        minScore: config.minScore,
        minRR: config.minRR,
        enabledAssetClasses: config.enabledAssetClasses,
      },
    };
  }

  _saveCheckpoint() {
    if (!this.session) return;
    this.session.updatedAt = Date.now();
    journal.saveScanSession(this.session);
    eventBus.emitEvent('scanner.checkpoint', {
      sessionId: this.session.id,
      status: this.session.status,
      analyzed: this.session.analyzedCount,
      total: this.session.totalMarkets,
    });
  }

  getState() {
    if (!this.session) this._initSession();
    const s = this.session;
    const pct = s.totalMarkets > 0 ? Math.min(100, Math.round((s.analyzedCount / s.totalMarkets) * 100)) : 0;
    return {
      sessionId: s.id,
      status: s.status,
      startedAt: s.startedAt,
      updatedAt: s.updatedAt,
      currentInstrument: s.currentInstrument,
      totalMarkets: s.totalMarkets,
      analyzedCount: s.analyzedCount,
      remainingCount: s.remainingCount,
      progressPct: pct,
      qualifiedCount: s.qualifiedCount,
      rejectedCount: s.rejectedCount,
      errorCount: s.errorCount,
      qualifiedSetups: (s.qualifiedSetups || []).slice(0, 50),
      failedCount: (s.failedSymbols || []).length,
      lastCheckpoint: s.updatedAt,
    };
  }

  async start() {
    if (this._isProcessing) {
      logger.warn('PersistentScanner: Already running');
      return this.getState();
    }

    if (this.session.status === 'PAUSED' && this.session.remainingCount > 0) {
      return this.resume();
    }

    return this.restartFullScan();
  }

  async pause() {
    if (!this._isProcessing) {
      if (this.session) {
        this.session.status = 'PAUSED';
        this._saveCheckpoint();
      }
      return this.getState();
    }
    this._pauseRequested = true;
    logger.info('PersistentScanner: Pause requested at next checkpoint');
    return this.getState();
  }

  async resume() {
    if (this._isProcessing) return this.getState();
    this._pauseRequested = false;
    this._stopRequested = false;
    this.session.status = 'RUNNING';
    this._saveCheckpoint();

    this._runScanLoop().catch(err => {
      logger.error(`PersistentScanner loop error: ${err.message}`);
    });

    return this.getState();
  }

  async stop() {
    this._stopRequested = true;
    this._pauseRequested = false;
    if (this.session) {
      this.session.status = 'STOPPED';
      this._saveCheckpoint();
    }
    logger.info('PersistentScanner: Scanner STOPPED');
    return this.getState();
  }

  async restartFullScan() {
    if (this._isProcessing) {
      this._stopRequested = true;
      await new Promise(r => setTimeout(r, 200));
    }

    // Refresh market discovery
    this.markets = await discoverMarkets(true);
    this.session = this._createNewSession();
    this.session.status = 'RUNNING';
    this.session.totalMarkets = this.markets.length;
    this.session.remainingCount = this.markets.length;
    this._saveCheckpoint();

    logger.info(`PersistentScanner: Starting fresh scan of ${this.markets.length} markets`);

    this._pauseRequested = false;
    this._stopRequested = false;

    this._runScanLoop().catch(err => {
      logger.error(`PersistentScanner full scan error: ${err.message}`);
    });

    return this.getState();
  }

  async rescanFailed() {
    if (this._isProcessing) return this.getState();
    const failed = [...(this.session.failedSymbols || [])];
    if (failed.length === 0) {
      logger.info('PersistentScanner: No failed markets to rescan');
      return this.getState();
    }

    // Filter markets for failed
    if (this.markets.length === 0) {
      this.markets = await discoverMarkets(false);
    }
    const targetMarkets = this.markets.filter(m => failed.includes(m.symbol));
    logger.info(`PersistentScanner: Rescanning ${targetMarkets.length} failed markets`);

    // Remove them from completed
    const completedSet = new Set(this.session.completedSymbols || []);
    for (const sym of failed) completedSet.delete(sym);
    this.session.completedSymbols = Array.from(completedSet);
    this.session.failedSymbols = [];
    this.session.status = 'RUNNING';
    this._saveCheckpoint();

    this.resume();
    return this.getState();
  }

  async _runScanLoop() {
    if (this._isProcessing) return;
    this._isProcessing = true;

    try {
      if (this.markets.length === 0) {
        this.markets = await discoverMarkets(false);
      }

      this.session.totalMarkets = this.markets.length;
      const completedSet = new Set(this.session.completedSymbols || []);
      const pendingMarkets = this.markets.filter(m => !completedSet.has(m.symbol));
      this.session.remainingCount = pendingMarkets.length;
      this._saveCheckpoint();

      logger.info(`PersistentScanner: Processing ${pendingMarkets.length} pending markets (concurrency: ${this.concurrency})`);

      for (let i = 0; i < pendingMarkets.length; i += this.concurrency) {
        if (this._pauseRequested) {
          this.session.status = 'PAUSED';
          this._saveCheckpoint();
          logger.info(`PersistentScanner: Checkpoint saved. PAUSED at ${this.session.analyzedCount}/${this.session.totalMarkets}`);
          break;
        }

        if (this._stopRequested) {
          this.session.status = 'STOPPED';
          this._saveCheckpoint();
          logger.info('PersistentScanner: Checkpoint saved. STOPPED');
          break;
        }

        const batch = pendingMarkets.slice(i, i + this.concurrency);
        this.session.currentInstrument = batch[0].symbol;

        await Promise.all(batch.map(m => this._analyzeMarket(m)));

        // Checkpoint after batch
        this.session.remainingCount = Math.max(0, this.session.totalMarkets - this.session.analyzedCount);
        this._saveCheckpoint();
      }

      if (!this._pauseRequested && !this._stopRequested && this.session.remainingCount === 0) {
        this.session.status = 'COMPLETED';
        this.session.currentInstrument = null;
        this._saveCheckpoint();
        logger.info(`PersistentScanner: Scan COMPLETED! Qualified: ${this.session.qualifiedCount}, Rejected: ${this.session.rejectedCount}, Errors: ${this.session.errorCount}`);
      }
    } finally {
      this._isProcessing = false;
      this._pauseRequested = false;
      this._stopRequested = false;
    }
  }

  async _analyzeMarket(market) {
    const symbol = market.symbol;
    try {
      // Check session status: If market session is CLOSED, do not generate live trade setups
      const session = market.session || { allowsTrading: true, status: 'OPEN' };
      if (!session.allowsTrading && session.status === 'CLOSED') {
        this.session.completedSymbols.push(symbol);
        this.session.analyzedCount++;
        this.session.rejectedCount++;
        return;
      }

      const [mtf, meta] = await Promise.all([
        dataFeed.getMultiTimeframe(symbol, ['4h', '1h', '15m'], 100),
        dataFeed.getMarketMeta(symbol),
      ]);

      const marketData = {
        symbol,
        candles4H: mtf['4h'],
        candles1H: mtf['1h'],
        candles15M: mtf['15m'],
        meta: { symbol, ...meta, assetClass: market.assetClass || 'CRYPTO' },
      };

      const signals = this.router
        ? await this.router.routeAndEvaluate(marketData)
        : await this.registry.evaluateAll(marketData);

      for (const sig of signals) {
        const scored = scoreSignal(sig);
        journal.saveSignal({
          ...scored,
          assetClass: market.assetClass || 'CRYPTO',
          mode: config.mode,
        });

        eventBus.emitEvent('opportunity.found', { symbol, scored, signal: sig });

        if (scored.qualified || scored.decision === 'TRADE') {
          this.session.qualifiedCount++;
          this.session.qualifiedSetups.unshift({
            symbol,
            assetClass: market.assetClass || 'CRYPTO',
            strategy: scored.strategyName || 'GPS',
            score: scored.score,
            direction: scored.direction,
            entry: scored.entry,
            stopLoss: scored.stopLoss,
            takeProfit: scored.takeProfit,
            riskReward: scored.riskReward,
            timestamp: Date.now(),
          });
          eventBus.emitEvent('opportunity.qualified', { symbol, opportunity: scored });
        } else {
          this.session.rejectedCount++;
          eventBus.emitEvent('opportunity.rejected', { symbol, reason: scored.criticalFail || scored.rejectionReason });
        }
      }

      this.session.completedSymbols.push(symbol);
      this.session.analyzedCount++;
    } catch (err) {
      this.session.errorCount++;
      if (!this.session.failedSymbols.includes(symbol)) {
        this.session.failedSymbols.push(symbol);
      }
      this.session.completedSymbols.push(symbol);
      this.session.analyzedCount++;
      eventBus.emitEvent('scanner.error', { symbol, error: err.message });
      logger.warn(`Scanner error on ${symbol}: ${err.message}`);
    }
  }
}

// Singleton scanner instance
let scannerInstance = null;
function getPersistentScanner(options) {
  if (!scannerInstance) {
    scannerInstance = new PersistentScanner(options);
  }
  return scannerInstance;
}

module.exports = {
  PersistentScanner,
  getPersistentScanner,
};
