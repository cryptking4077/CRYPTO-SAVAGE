'use strict';

const dataFeed = require('../market/dataFeed');
const { createDefaultRegistry, StrategyRouter } = require('../strategy/registry');
const { scoreSignal } = require('../scoring/engine');
const RiskEngine = require('../risk/engine');
const config = require('../config');
const journal = require('../journal/store');
const { eventBus } = require('../events/bus');
const { autopsyEngine } = require('../learning/autopsy');
const logger = require('../utils/logger');

const FEE_RATE = 0.00055; // Bybit taker fee (0.055%)
const DEFAULT_SLIPPAGE_RATE = 0.0005; // 0.05% slippage simulation

/**
 * Paper Trading Engine
 * Realistic execution simulator with Bybit live data, fees, slippage,
 * correlation tracking, and regime awareness.
 */
class PaperEngine {
  constructor(strategyConfig = {}, riskConfig = {}) {
    this.registry = createDefaultRegistry(strategyConfig);
    this.router = new StrategyRouter(this.registry);
    this.riskEngine = new RiskEngine(riskConfig);
    this.openTrades = new Map();   // key → trade
    this.closedTrades = [];
    this.balance = this.riskEngine.cfg.accountBalance;
    this.startBalance = this.balance;
    this.slippageRate = riskConfig.slippageRate ?? DEFAULT_SLIPPAGE_RATE;
    this.trailingConfig = riskConfig.trailingStop ?? config.trailingStop ?? { enabled: true, activationRR: 1.0, distancePct: 0.015 };
    this._processedSignals = new Set();
  }

  /**
   * Evaluate a market and potentially open a paper trade
   * @param {string} symbol
   */
  async evaluateMarket(symbol) {
    try {
      const [mtf, meta] = await Promise.all([
        dataFeed.getMultiTimeframe(symbol, ['4h', '1h', '15m'], 200),
        dataFeed.getMarketMeta(symbol),
      ]);

      const marketData = {
        symbol,
        candles4H:  mtf['4h'],
        candles1H:  mtf['1h'],
        candles15M: mtf['15m'],
        meta: { symbol, ...meta },
      };

      const signals = this.router
        ? await this.router.routeAndEvaluate(marketData)
        : await this.registry.evaluateAll(marketData);

      for (const signal of signals) {
        const scored = scoreSignal(signal);
        if (scored.decision !== 'TRADE') continue;

        // Duplicate check
        const sigKey = `${symbol}_${signal.strategyId}_${signal.direction}_${Math.floor(signal.timestamp / 60000)}`;
        if (this._processedSignals.has(sigKey)) {
          logger.paper(`Duplicate signal skipped: ${sigKey}`);
          continue;
        }

        // Already in a trade for this symbol+strategy
        const existingKey = `${symbol}_${signal.strategyId}`;
        if (this.openTrades.has(existingKey)) {
          logger.paper(`Already in trade for ${symbol} [${signal.strategyId}] — skipping`);
          continue;
        }

        // Risk and correlation check
        const openList = Array.from(this.openTrades.values());
        const riskCheck = this.riskEngine.check(signal, openList);
        if (!riskCheck.approved) {
          logger.paper(`Risk rejected paper trade ${symbol}: ${riskCheck.reason}`);
          continue;
        }

        // Simulated entry price with slippage
        const slippageMultiplier = signal.direction === 'LONG' ? (1 + this.slippageRate) : (1 - this.slippageRate);
        const actualEntry = parseFloat((signal.entry * slippageMultiplier).toFixed(4));
        const entrySlippage = Math.abs(actualEntry - signal.entry) * riskCheck.positionSize;
        const initialRisk = Math.abs(actualEntry - signal.stopLoss);

        // Open paper trade
        const trade = {
          id: existingKey,
          symbol,
          strategyId: signal.strategyId,
          strategyName: signal.strategyName,
          strategyVersion: signal.strategyVersion,
          direction: signal.direction,
          entry: actualEntry,
          targetEntry: signal.entry,
          stopLoss: signal.stopLoss,
          takeProfit: signal.takeProfit,
          riskReward: signal.riskReward,
          score: signal.score,
          positionSize: riskCheck.positionSize,
          regime: signal.regime || null,
          cluster: riskCheck.cluster || 'ALT_GENERAL',
          slippage: parseFloat(entrySlippage.toFixed(4)),
          openTime: Date.now(),
          mode: 'PAPER',
          initialRisk,
          trailingActive: false,
          trailingStopPrice: null,
        };

        this.openTrades.set(existingKey, trade);
        this._processedSignals.add(sigKey);
        this.riskEngine.onPositionOpened(trade.positionSize * trade.entry, symbol);

        try {
          journal.savePaperTrade(trade);
        } catch (_) {}

        eventBus.emitEvent('position.opened', { trade, signal, mode: 'PAPER' });

        logger.paper(`OPENED [${trade.cluster}]: ${symbol} ${signal.direction} @ ${trade.entry} (target: ${signal.entry}) | SL: ${signal.stopLoss} | TP: ${signal.takeProfit}`);
        return { action: 'OPENED', trade, signal };
      }

      return { action: 'NONE' };
    } catch (err) {
      logger.error(`Paper eval failed for ${symbol}: ${err.message}`);
      return { action: 'ERROR', error: err.message };
    }
  }

  /**
   * Update open paper trades against current price
   * @param {string} symbol
   * @param {number} currentPrice
   */
  updateTrades(symbol, currentPrice) {
    const closed = [];
    for (const [key, trade] of this.openTrades) {
      if (trade.symbol !== symbol) continue;

      // Trailing stop ratchet logic
      if (this.trailingConfig?.enabled && trade.initialRisk > 0) {
        const activationRR = this.trailingConfig.activationRR || 1.0;
        const distancePct = this.trailingConfig.distancePct || 0.015;

        if (trade.direction === 'LONG') {
          const profit = currentPrice - trade.entry;
          if (profit >= trade.initialRisk * activationRR) {
            trade.trailingActive = true;
            const proposedStop = parseFloat((currentPrice * (1 - distancePct)).toFixed(4));
            if (!trade.trailingStopPrice || proposedStop > trade.trailingStopPrice) {
              trade.trailingStopPrice = proposedStop;
            }
            if (trade.trailingStopPrice > trade.stopLoss) {
              trade.stopLoss = trade.trailingStopPrice;
              eventBus.emitEvent('position.trailing_updated', { tradeId: trade.id, symbol: trade.symbol, stopLoss: trade.stopLoss });
            }
          }
        } else if (trade.direction === 'SHORT') {
          const profit = trade.entry - currentPrice;
          if (profit >= trade.initialRisk * activationRR) {
            trade.trailingActive = true;
            const proposedStop = parseFloat((currentPrice * (1 + distancePct)).toFixed(4));
            if (!trade.trailingStopPrice || proposedStop < trade.trailingStopPrice) {
              trade.trailingStopPrice = proposedStop;
            }
            if (trade.trailingStopPrice < trade.stopLoss) {
              trade.stopLoss = trade.trailingStopPrice;
              eventBus.emitEvent('position.trailing_updated', { tradeId: trade.id, symbol: trade.symbol, stopLoss: trade.stopLoss });
            }
          }
        }
      }

      let outcome = null;
      let exitReason = null;
      if (trade.direction === 'LONG') {
        if (currentPrice <= trade.stopLoss) {
          outcome = (trade.trailingActive && currentPrice > trade.entry) ? 'WIN' : 'LOSS';
          exitReason = trade.trailingActive ? 'TRAILING_STOP_HIT' : 'STOP_LOSS_HIT';
        } else if (currentPrice >= trade.takeProfit) {
          outcome = 'WIN';
          exitReason = 'TAKE_PROFIT_HIT';
        }
      } else {
        if (currentPrice >= trade.stopLoss) {
          outcome = (trade.trailingActive && currentPrice < trade.entry) ? 'WIN' : 'LOSS';
          exitReason = trade.trailingActive ? 'TRAILING_STOP_HIT' : 'STOP_LOSS_HIT';
        } else if (currentPrice <= trade.takeProfit) {
          outcome = 'WIN';
          exitReason = 'TAKE_PROFIT_HIT';
        }
      }

      if (outcome) {
        // Apply exit slippage
        const nominalExit = outcome === 'WIN' ? trade.takeProfit : trade.stopLoss;
        const exitSlippageMultiplier = trade.direction === 'LONG'
          ? (outcome === 'WIN' ? (1 - this.slippageRate) : (1 - this.slippageRate))
          : (outcome === 'WIN' ? (1 + this.slippageRate) : (1 + this.slippageRate));

        const actualExit = parseFloat((nominalExit * exitSlippageMultiplier).toFixed(4));
        const exitSlippage = Math.abs(actualExit - nominalExit) * trade.positionSize;
        const totalSlippage = (trade.slippage || 0) + exitSlippage;

        const rawPnl = trade.direction === 'LONG'
          ? (actualExit - trade.entry) * trade.positionSize
          : (trade.entry - actualExit) * trade.positionSize;

        const totalFees = (trade.positionSize * trade.entry * FEE_RATE) + (trade.positionSize * actualExit * FEE_RATE);
        const netPnl = rawPnl - totalFees;

        this.balance += netPnl;
        this.riskEngine.onTradeClosed(netPnl);
        this.riskEngine.onPositionClosed(trade.positionSize * trade.entry, symbol);

        const closedTrade = {
          ...trade,
          exitPrice: actualExit,
          closeTime: Date.now(),
          outcome,
          exitReason,
          pnl: parseFloat(netPnl.toFixed(4)),
          fee: parseFloat(totalFees.toFixed(4)),
          slippage: parseFloat(totalSlippage.toFixed(4)),
          durationMs: Date.now() - trade.openTime,
        };

        this.closedTrades.push(closedTrade);
        this.openTrades.delete(key);
        closed.push(closedTrade);

        try {
          journal.savePaperTrade(closedTrade);
        } catch (_) {}

        eventBus.emitEvent('position.closed', { trade: closedTrade, mode: 'PAPER' });
        try {
          autopsyEngine.diagnoseTrade(closedTrade);
        } catch (_) {}

        logger.paper(`CLOSED [${trade.cluster}]: ${symbol} ${trade.direction} ${outcome} (${exitReason}) | Net P&L: ${netPnl >= 0 ? '+' : ''}${netPnl.toFixed(4)} | Fees: ${totalFees.toFixed(4)}`);
      }
    }
    return closed;
  }

  /**
   * Manually close a trade by ID or symbol
   */
  closeTrade(idOrSymbol, reason = 'MANUAL_CLOSE', exitPrice = null) {
    let keyToClose = null;
    let trade = null;

    if (this.openTrades.has(idOrSymbol)) {
      keyToClose = idOrSymbol;
      trade = this.openTrades.get(idOrSymbol);
    } else {
      for (const [k, t] of this.openTrades) {
        if (t.symbol === idOrSymbol || t.id === idOrSymbol) {
          keyToClose = k;
          trade = t;
          break;
        }
      }
    }

    if (!trade) return null;

    const actualExit = exitPrice || trade.entry;
    const rawPnl = trade.direction === 'LONG'
      ? (actualExit - trade.entry) * trade.positionSize
      : (trade.entry - actualExit) * trade.positionSize;

    const totalFees = (trade.positionSize * trade.entry * FEE_RATE) + (trade.positionSize * actualExit * FEE_RATE);
    const netPnl = rawPnl - totalFees;
    const outcome = netPnl >= 0 ? 'WIN' : 'LOSS';

    this.balance += netPnl;
    this.riskEngine.onTradeClosed(netPnl);
    this.riskEngine.onPositionClosed(trade.positionSize * trade.entry, trade.symbol);

    const closedTrade = {
      ...trade,
      exitPrice: parseFloat(actualExit.toFixed(4)),
      closeTime: Date.now(),
      outcome,
      exitReason: reason,
      pnl: parseFloat(netPnl.toFixed(4)),
      fee: parseFloat(totalFees.toFixed(4)),
      slippage: trade.slippage || 0,
      durationMs: Date.now() - trade.openTime,
    };

    this.closedTrades.push(closedTrade);
    this.openTrades.delete(keyToClose);

    try {
      journal.savePaperTrade(closedTrade);
    } catch (_) {}

    eventBus.emitEvent('position.closed', { trade: closedTrade, mode: 'PAPER', manual: true });
    try {
      autopsyEngine.diagnoseTrade(closedTrade);
    } catch (_) {}

    logger.paper(`MANUAL CLOSE: ${trade.symbol} ${trade.direction} (${reason}) | Net P&L: ${netPnl >= 0 ? '+' : ''}${netPnl.toFixed(4)}`);
    return closedTrade;
  }

  /**
   * Close all open trades
   */
  closeAllTrades(reason = 'MANUAL_CLOSE_ALL') {
    const closed = [];
    const keys = Array.from(this.openTrades.keys());
    for (const k of keys) {
      const res = this.closeTrade(k, reason);
      if (res) closed.push(res);
    }
    return closed;
  }

  /** Performance summary */
  getPerformance() {
    const trades = this.closedTrades;
    const wins = trades.filter(t => t.outcome === 'WIN');
    const losses = trades.filter(t => t.outcome === 'LOSS');
    const netPnl = trades.reduce((s, t) => s + t.pnl, 0);

    return {
      mode: 'PAPER',
      totalTrades: trades.length,
      openTrades: this.openTrades.size,
      wins: wins.length,
      losses: losses.length,
      winRate: trades.length ? parseFloat((wins.length / trades.length * 100).toFixed(2)) : 0,
      netPnl: parseFloat(netPnl.toFixed(4)),
      returnPct: parseFloat((netPnl / this.startBalance * 100).toFixed(2)),
      currentBalance: parseFloat(this.balance.toFixed(4)),
      riskStatus: this.riskEngine.getStatus(),
    };
  }

  getOpenTrades() {
    return Array.from(this.openTrades.values());
  }

  getClosedTrades() {
    return this.closedTrades;
  }
}

module.exports = PaperEngine;
