'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const ReconciliationEngine = require('../src/execution/reconciliation');
const RiskEngine = require('../src/risk/engine');

describe('Exchange ↔ Database Reconciliation Engine', () => {
  test('passes with HEALTHY when local and exchange positions match', async () => {
    const risk = new RiskEngine();
    const recon = new ReconciliationEngine({ riskEngine: risk });

    const localPositions = [{ symbol: 'SOLUSDT', positionSize: 10, entry: 100 }];
    const exchangePositions = [{ symbol: 'SOLUSDT', size: 10, avgPrice: 100 }];

    const result = await recon.reconcile(localPositions, exchangePositions, [], []);
    assert.equal(result.healthy, true);
    assert.equal(result.status, 'HEALTHY');
    assert.equal(result.discrepancies.length, 0);
  });

  test('triggers RECONCILIATION_FAILURE and activates emergency stop on untracked exchange position', async () => {
    const risk = new RiskEngine();
    const recon = new ReconciliationEngine({ riskEngine: risk });

    const localPositions = [];
    const exchangePositions = [{ symbol: 'ETHUSDT', size: 5, avgPrice: 2500 }]; // Not in local DB

    const result = await recon.reconcile(localPositions, exchangePositions, [], []);
    assert.equal(result.healthy, false);
    assert.equal(result.status, 'RECONCILIATION_FAILURE');
    assert.ok(result.discrepancies.some(d => d.type === 'UNTRACKED_EXCHANGE_POSITION'));

    // Emergency stop must have been activated on risk engine
    assert.equal(risk.state.killSwitch, true);
    assert.equal(risk.state.tradingEnabled, false);
  });

  test('detects position size mismatch between local and exchange', async () => {
    const risk = new RiskEngine();
    const recon = new ReconciliationEngine({ riskEngine: risk });

    const localPositions = [{ symbol: 'SOLUSDT', positionSize: 10, entry: 100 }];
    const exchangePositions = [{ symbol: 'SOLUSDT', size: 15, avgPrice: 100 }]; // 5 unit difference

    const result = await recon.reconcile(localPositions, exchangePositions, [], []);
    assert.equal(result.healthy, false);
    assert.ok(result.discrepancies.some(d => d.type === 'POSITION_SIZE_MISMATCH'));
  });
});
