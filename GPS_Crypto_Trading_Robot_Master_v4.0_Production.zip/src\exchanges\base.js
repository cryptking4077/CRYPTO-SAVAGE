'use strict';

/**
 * Base Exchange Adapter Interface
 * Provides the contract for market data feed and trade execution across exchanges.
 */
class BaseExchangeAdapter {
  constructor(name, config = {}) {
    this.name = name;
    this.config = config;
  }

  // Market Data Interface
  async getInstruments() {
    throw new Error(`${this.name}: getInstruments() not implemented`);
  }

  async getTickers(symbol) {
    throw new Error(`${this.name}: getTickers() not implemented`);
  }

  async getKlines(symbol, interval, limit, start, end) {
    throw new Error(`${this.name}: getKlines() not implemented`);
  }

  async getKlineHistory(symbol, interval, maxCandles) {
    throw new Error(`${this.name}: getKlineHistory() not implemented`);
  }

  async getFundingRate(symbol) {
    throw new Error(`${this.name}: getFundingRate() not implemented`);
  }

  async getOpenInterest(symbol, interval) {
    throw new Error(`${this.name}: getOpenInterest() not implemented`);
  }

  // Live Trading Interface (when authorized)
  async getAccountBalance() {
    throw new Error(`${this.name}: getAccountBalance() not implemented`);
  }

  async getPositions() {
    throw new Error(`${this.name}: getPositions() not implemented`);
  }

  async getOpenOrders(symbol) {
    throw new Error(`${this.name}: getOpenOrders() not implemented`);
  }

  async placeOrder(params) {
    throw new Error(`${this.name}: placeOrder() not implemented`);
  }

  async cancelOrder(symbol, orderId) {
    throw new Error(`${this.name}: cancelOrder() not implemented`);
  }
}

module.exports = BaseExchangeAdapter;
