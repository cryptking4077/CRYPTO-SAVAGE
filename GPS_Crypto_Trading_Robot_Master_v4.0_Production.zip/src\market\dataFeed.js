'use strict';

const bybit = require('../exchanges/bybit');
const logger = require('../utils/logger');

// Bybit interval codes
const INTERVAL_MAP = {
  '15m': '15',
  '1h':  '60',
  '4h':  '240',
  '1d':  'D',
};

/**
 * Fetch candles for a symbol and timeframe
 * Returns normalized chronological OHLCV array
 */
async function getCandles(symbol, timeframe, limit = 200) {
  const interval = INTERVAL_MAP[timeframe];
  if (!interval) throw new Error(`Unknown timeframe: ${timeframe}`);
  return bybit.getKlines(symbol, interval, limit);
}

/**
 * Fetch multi-timeframe candles for a symbol
 * Returns { '4h': [], '1h': [], '15m': [] }
 */
async function getMultiTimeframe(symbol, timeframes = ['4h', '1h', '15m'], limit = 200) {
  const results = {};
  for (const tf of timeframes) {
    try {
      results[tf] = await getCandles(symbol, tf, limit);
    } catch (err) {
      logger.warn(`Failed to get ${tf} candles for ${symbol}: ${err.message}`);
      results[tf] = [];
    }
  }
  return results;
}

/**
 * Fetch full candle history for backtesting (paginated)
 */
async function getHistoricalCandles(symbol, timeframe, maxCandles = 1000) {
  const interval = INTERVAL_MAP[timeframe];
  if (!interval) throw new Error(`Unknown timeframe: ${timeframe}`);
  return bybit.getKlineHistory(symbol, interval, maxCandles);
}

/**
 * Fetch funding rate + open interest for a symbol
 */
async function getMarketMeta(symbol) {
  const [funding, oi] = await Promise.allSettled([
    bybit.getFundingRate(symbol),
    bybit.getOpenInterest(symbol, '4h'),
  ]);
  return {
    fundingRate: funding.status === 'fulfilled' ? funding.value?.fundingRate : null,
    openInterest: oi.status === 'fulfilled' ? oi.value?.openInterest : null,
  };
}

module.exports = { getCandles, getMultiTimeframe, getHistoricalCandles, getMarketMeta, INTERVAL_MAP };
