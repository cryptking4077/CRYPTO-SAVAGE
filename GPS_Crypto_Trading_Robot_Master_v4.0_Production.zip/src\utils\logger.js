'use strict';

const config = require('../config');

const LEVELS = { DEBUG: 0, INFO: 1, SCAN: 1, SIGNAL: 1, NO_TRADE: 1, RISK: 1, PAPER: 1, LIVE: 1, ALERT: 1, WARN: 2, ERROR: 3 };
const configLevel = LEVELS[config.logLevel] ?? 1;

function log(level, message, data) {
  if ((LEVELS[level] ?? 1) < configLevel) return;
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const prefix = `[${ts}] [${level.padEnd(8)}]`;
  if (data !== undefined) {
    console.log(`${prefix} ${message}`, typeof data === 'object' ? JSON.stringify(data) : data);
  } else {
    console.log(`${prefix} ${message}`);
  }
}

const logger = {
  debug: (msg, d) => log('DEBUG', msg, d),
  info:  (msg, d) => log('INFO',  msg, d),
  scan:  (msg, d) => log('SCAN',  msg, d),
  signal:(msg, d) => log('SIGNAL',msg, d),
  noTrade:(msg, d)=> log('NO_TRADE', msg, d),
  risk:  (msg, d) => log('RISK',  msg, d),
  paper: (msg, d) => log('PAPER', msg, d),
  live:  (msg, d) => log('LIVE',  msg, d),
  alert: (msg, d) => log('ALERT', msg, d),
  warn:  (msg, d) => log('WARN',  msg, d),
  error: (msg, d) => log('ERROR', msg, d),
};

module.exports = logger;
