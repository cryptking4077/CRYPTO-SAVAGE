'use strict';

const indicators = require('../indicators');

/**
 * Enhanced Market Regime Detection
 *
 * Supported Canonical Regimes:
 * - STRONG_TREND: Structure trend + EMA 20/50 alignment with high momentum
 * - WEAK_TREND: Directional bias present but momentum slowing
 * - PULLBACK: Established trend with controlled retracement into EMA/dynamic support
 * - COMPRESSION: Volatility squeeze (low ATR / contracting bands)
 * - BREAKOUT: Expansion bar breaking key swing level with volume surge
 * - RANGE: Sideways oscillation between structural boundaries
 * - UNCLEAR: Conflicting indicators or insufficient data
 *
 * Backward-compatible regime aliases (TRENDING_UP, TRENDING_DOWN, etc.) are preserved
 * on `res.regime` for existing tests, while `res.canonicalRegime` provides standard routing.
 *
 * @param {Array} candles4H - 4H candles
 * @param {Array} candles1H - 1H candles
 * @param {Array} [candles15M] - Optional 15M candles for pullback & breakout confirmation
 * @returns {object} Detailed regime classification & metadata
 */
function detectRegime(candles4H, candles1H, candles15M) {
  const candles = (candles4H && candles4H.length >= 30) ? candles4H : (candles1H || []);
  if (!candles || candles.length < 30) {
    return {
      regime: 'UNCERTAIN',
      canonicalRegime: 'UNCLEAR',
      confidence: 0,
      volatility: 'NORMAL',
      trend: 'SIDEWAYS',
      summary: 'Insufficient candles for regime classification',
    };
  }

  // 1. Structure trend
  const structureTrend = indicators.detectTrend(candles, 4);

  // 2. EMA trend confirmation (fast=20, slow=50)
  const closes = candles.map(c => c.close);
  const emaFast = indicators.ema(closes, 20);
  const emaSlow = indicators.ema(closes, 50);

  const lastClose = closes[closes.length - 1];
  const lastFast = emaFast[emaFast.length - 1];
  const lastSlow = emaSlow[emaSlow.length - 1];

  let emaBullish = false;
  let emaBearish = false;
  if (!isNaN(lastFast) && !isNaN(lastSlow)) {
    emaBullish = lastClose > lastFast && lastFast > lastSlow;
    emaBearish = lastClose < lastFast && lastFast < lastSlow;
  }

  // 3. Volatility analysis (ATR 14 vs ATR SMA 30)
  const atrValues = indicators.atr(candles, 14);
  const validAtrs = atrValues.filter(v => !isNaN(v));
  let volatility = 'NORMAL';
  let atrRatio = 1.0;

  if (validAtrs.length >= 30) {
    const currentAtr = validAtrs[validAtrs.length - 1];
    const meanAtr = validAtrs.slice(-30).reduce((s, a) => s + a, 0) / 30;
    if (meanAtr > 0) {
      atrRatio = currentAtr / meanAtr;
      if (atrRatio >= 1.45) volatility = 'HIGH';
      else if (atrRatio <= 0.70) volatility = 'LOW';
    }
  }

  // 4. Breakout & Pullback Signals
  const recent20 = candles.slice(-20);
  const prev19High = Math.max(...recent20.slice(0, 19).map(c => c.high));
  const prev19Low = Math.min(...recent20.slice(0, 19).map(c => c.low));
  const lastCandle = recent20[recent20.length - 1];
  const isBreakoutUp = lastCandle.close > prev19High && volatility === 'HIGH';
  const isBreakoutDown = lastCandle.close < prev19Low && volatility === 'HIGH';
  const isBreakout = isBreakoutUp || isBreakoutDown;

  // Check Pullback: trending HTF but price pulled back near EMA fast (within 0.8 ATR)
  let isPullback = false;
  if (validAtrs.length > 0 && !isNaN(lastFast)) {
    const currentAtr = validAtrs[validAtrs.length - 1];
    const distToEma = Math.abs(lastClose - lastFast);
    if (distToEma <= currentAtr * 0.8) {
      if ((structureTrend === 'BULLISH' && lastClose >= lastFast) ||
          (structureTrend === 'BEARISH' && lastClose <= lastFast)) {
        isPullback = true;
      }
    }
  }

  // 5. Synthesize Canonical and Legacy Regimes
  let legacyRegime = 'UNCERTAIN';
  let canonicalRegime = 'UNCLEAR';
  let confidence = 50;
  let trend = 'SIDEWAYS';

  if (isBreakout) {
    canonicalRegime = 'BREAKOUT';
    legacyRegime = 'HIGH_VOLATILITY';
    confidence = 80;
    trend = isBreakoutUp ? 'BULLISH' : 'BEARISH';
  } else if (volatility === 'LOW') {
    canonicalRegime = 'COMPRESSION';
    legacyRegime = 'LOW_VOLATILITY';
    confidence = 75;
    trend = 'SIDEWAYS';
  } else if (structureTrend === 'BULLISH' && emaBullish) {
    confidence = 85;
    trend = 'BULLISH';
    legacyRegime = volatility === 'HIGH' ? 'HIGH_VOLATILITY' : 'TRENDING_UP';
    canonicalRegime = isPullback ? 'PULLBACK' : 'STRONG_TREND';
  } else if (structureTrend === 'BEARISH' && emaBearish) {
    confidence = 85;
    trend = 'BEARISH';
    legacyRegime = volatility === 'HIGH' ? 'HIGH_VOLATILITY' : 'TRENDING_DOWN';
    canonicalRegime = isPullback ? 'PULLBACK' : 'STRONG_TREND';
  } else if (structureTrend === 'BULLISH' || (emaBullish && lastClose > lastSlow)) {
    confidence = 65;
    trend = 'BULLISH';
    legacyRegime = 'TRENDING_UP';
    canonicalRegime = isPullback ? 'PULLBACK' : 'WEAK_TREND';
  } else if (structureTrend === 'BEARISH' || (emaBearish && lastClose < lastSlow)) {
    confidence = 65;
    trend = 'BEARISH';
    legacyRegime = 'TRENDING_DOWN';
    canonicalRegime = isPullback ? 'PULLBACK' : 'WEAK_TREND';
  } else if (structureTrend === 'RANGING') {
    canonicalRegime = 'RANGE';
    legacyRegime = 'RANGE';
    confidence = 75;
    trend = 'SIDEWAYS';
  } else {
    canonicalRegime = 'RANGE';
    legacyRegime = 'RANGE';
    confidence = 60;
    trend = 'SIDEWAYS';
  }

  return {
    regime: legacyRegime,
    canonicalRegime,
    confidence,
    volatility,
    trend,
    atrRatio: parseFloat(atrRatio.toFixed(2)),
    summary: `${canonicalRegime} (trend: ${trend}, vol: ${volatility}, conf: ${confidence}%)`,
  };
}

module.exports = { detectRegime };

