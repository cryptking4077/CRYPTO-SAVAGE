'use strict';

const WalkForwardEngine = require('../backtest/walkForward');

async function main() {
  const args = process.argv.slice(2);
  function getArg(name, def) {
    const a = args.find(a => a.startsWith(`--${name}=`));
    return a ? a.split('=')[1] : def;
  }

  const symbol = getArg('symbol', 'SOLUSDT');
  const windows = parseInt(getArg('windows', '3'), 10);

  console.log('\n═══ GPS ROBOT — WALK-FORWARD VALIDATION ═══\n');
  console.log(`Symbol:       ${symbol}`);
  console.log(`Windows:      ${windows} rolling windows`);
  console.log('Fetching multi-timeframe historical data from Bybit...\n');

  const engine = new WalkForwardEngine();
  const result = await engine.run(symbol, { windows });

  if (result.status !== 'COMPLETE') {
    console.log(`Status: INCOMPLETE — ${result.reason}`);
    process.exit(0);
  }

  console.log(`Analyzed: ${result.totalCandles4H} × 4H candles across ${result.windowsCount} rolling windows\n`);

  for (const w of result.windows) {
    console.log(`── WINDOW ${w.window} ──`);
    console.log(`  Train (IS):  ${w.trainPeriod} | Trades: ${w.inSample.totalTrades} | WinRate: ${w.inSample.winRate}% | Net: ${w.inSample.netProfit}`);
    console.log(`  Test (OOS):  ${w.testPeriod} | Trades: ${w.outOfSample.totalTrades} | WinRate: ${w.outOfSample.winRate}% | Net: ${w.outOfSample.netProfit} | PF: ${w.outOfSample.profitFactor}`);
    console.log();
  }

  console.log('── AGGREGATE OUT-OF-SAMPLE PERFORMANCE ──');
  console.log(`  Total Trades: ${result.aggregateOOS.totalTrades}`);
  console.log(`  Win Rate:     ${result.aggregateOOS.winRate}%`);
  console.log(`  Net P&L:      ${result.aggregateOOS.netProfit}`);
  console.log(`  Sample Note:  ${result.aggregateOOS.sampleNotice}\n`);

  process.exit(0);
}

main().catch(err => {
  console.error('Walk-forward run failed:', err.message);
  process.exit(1);
});
