'use strict';

const logger = require('../utils/logger');
const { detectRegime } = require('../market/regime');

/**
 * Intelligent Regime-Aware Strategy Router
 *
 * Directs markets to optimal strategies based on the prevailing regime:
 * - STRONG_TREND / TRENDING_UP / TRENDING_DOWN -> GPS v1 or Pullback Continuation
 * - RANGE / LOW_VOLATILITY -> Mean Reversion
 * - BREAKOUT / COMPRESSION / HIGH_VOLATILITY -> Breakout Strategy
 * - UNCLEAR / UNCERTAIN -> Explicit NO_TRADE
 */
class StrategyRouter {
  constructor(registry) {
    this.registry = registry;
  }

  /**
   * Determine optimal strategies for a detected regime
   * @param {object} regimeObj - Result from detectRegime
   * @returns {Array<string>} - Array of strategy IDs to run
   */
  getStrategiesForRegime(regimeObj) {
    const regime = regimeObj?.canonicalRegime || regimeObj?.regime || 'UNCLEAR';

    switch (regime) {
      case 'STRONG_TREND':
      case 'TRENDING_UP':
      case 'TRENDING_DOWN':
        return ['gps_v1', 'pullback_v1', 'vwap_structure_v1', 'momentum_sr_v1'];

      case 'PULLBACK':
        return ['pullback_v1', 'gps_v1', 'momentum_sr_v1'];

      case 'RANGE':
      case 'LOW_VOLATILITY':
        return ['mean_reversion_v1', 'range_fading_v1'];

      case 'BREAKOUT':
      case 'COMPRESSION':
      case 'HIGH_VOLATILITY':
        return ['breakout_v1', 'volatility_expansion_v1', 'orb_v1'];

      case 'WEAK_TREND':
        return ['gps_v1', 'vwap_structure_v1'];

      case 'UNCLEAR':
      case 'UNCERTAIN':
      default:
        return []; // No trade when regime is unclear
    }
  }

  /**
   * Route market data to the appropriate strategy
   * @param {object} marketData - { symbol, candles4H, candles1H, candles15M, meta }
   * @returns {Promise<Array>} - Strategy evaluation results
   */
  async routeAndEvaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    // 1. Detect Regime
    const regime = detectRegime(candles4H, candles1H, candles15M);

    // 2. Select Strategies
    const targetStrategyIds = this.getStrategiesForRegime(regime);

    if (targetStrategyIds.length === 0) {
      logger.noTrade(`${symbol}: Regime is ${regime.summary} -> NO_TRADE (Unclear regime)`);
      return [{
        strategyId: 'router',
        strategyName: 'Regime Router',
        strategyVersion: '1.0.0',
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'UNCLEAR_REGIME',
        rejectionReason: `Market regime is ${regime.canonicalRegime || regime.regime} (insufficient structure for strategy activation)`,
        regime,
        timestamp: Date.now(),
      }];
    }

    // 3. Evaluate selected strategies
    const results = [];
    for (const id of targetStrategyIds) {
      const strategy = this.registry.get(id);
      if (strategy && strategy.enabled) {
        try {
          const res = strategy.evaluate(marketData);
          results.push(res);
        } catch (err) {
          logger.error(`Strategy ${id} error on ${symbol}: ${err.message}`);
        }
      }
    }

    if (results.length === 0) {
      return [{
        strategyId: 'router',
        strategyName: 'Regime Router',
        strategyVersion: '1.0.0',
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'NO_STRATEGY_AVAILABLE',
        rejectionReason: `Matching strategies [${targetStrategyIds.join(', ')}] are disabled or missing`,
        regime,
        timestamp: Date.now(),
      }];
    }

    // 4. Resolve conflicts if multiple strategies ran
    const qualified = results.filter(r => r.qualified);
    if (qualified.length >= 2) {
      const dirs = new Set(qualified.map(r => r.direction));
      if (dirs.has('LONG') && dirs.has('SHORT')) {
        logger.noTrade(`${symbol}: Strategy direction conflict -> NO_TRADE`);
        return results.map(r => ({
          ...r,
          qualified: false,
          criticalFail: 'STRATEGY_CONFLICT',
          rejectionReason: 'Conflicting directional signals between strategies',
        }));
      }
      // Sort by score descending
      results.sort((a, b) => (b.score || 0) - (a.score || 0));
    }

    return results;
  }
}

module.exports = StrategyRouter;
