'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  consolidationPeriod: 20,
  minVolumeMultiplier: 1.3,
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 25,
    structuralBreak: 25,
    volumeExpansion: 25,
    momentumContinuation: 15,
    candleGeometry: 10,
  },
};

class BreakoutStrategy {
  constructor(options = {}) {
    this.id = 'breakout_v1';
    this.name = options.name || 'Breakout & Expansion';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [], meta = {} } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime Alignment (BREAKOUT, COMPRESSION, or HIGH_VOLATILITY)
    const isBreakoutRegime = ['BREAKOUT', 'COMPRESSION', 'HIGH_VOLATILITY'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isBreakoutRegime ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    // 2. Structural Breakout of 20-period range
    const period = this.cfg.consolidationPeriod;
    const windowCandles = candles1H.slice(-period);
    const priorCandles = windowCandles.slice(0, period - 1);
    const last1H = windowCandles[windowCandles.length - 1];

    const rangeHigh = Math.max(...priorCandles.map(c => c.high));
    const rangeLow = Math.min(...priorCandles.map(c => c.low));

    let direction = null;
    let structuralBreak = false;

    if (last1H.close > rangeHigh) {
      direction = 'LONG';
      structuralBreak = true;
    } else if (last1H.close < rangeLow) {
      direction = 'SHORT';
      structuralBreak = true;
    }
    conditions.structuralBreak = structuralBreak ? PASS : FAIL;
    details.range = `Range [${rangeLow.toFixed(4)} - ${rangeHigh.toFixed(4)}], Close: ${last1H.close.toFixed(4)}`;

    // 3. Volume Expansion
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[volMA.length - 1];
    let volExpansion = false;
    if (!isNaN(lastVolMA) && lastVolMA > 0) {
      volExpansion = last1H.volume >= lastVolMA * this.cfg.minVolumeMultiplier;
    }
    conditions.volumeExpansion = volExpansion ? PASS : FAIL;
    details.volume = `Vol: ${last1H.volume}, MA: ${lastVolMA ? lastVolMA.toFixed(0) : 'N/A'}, Mult: ${(last1H.volume / (lastVolMA || 1)).toFixed(2)}x`;

    // 4. Momentum Continuation (RSI check)
    const rsiVals = indicators.rsi(candles1H, 14);
    const lastRsi = rsiVals[rsiVals.length - 1];
    let momentumOk = false;
    if (direction === 'LONG' && lastRsi > 55 && lastRsi < 85) momentumOk = true;
    if (direction === 'SHORT' && lastRsi < 45 && lastRsi > 15) momentumOk = true;
    conditions.momentumContinuation = isNaN(lastRsi) ? NA : (momentumOk ? PASS : FAIL);

    // 5. Candle Geometry (Strong close near high/low)
    const candleRange = last1H.high - last1H.low;
    let solidBody = false;
    if (candleRange > 0) {
      const bodyRatio = Math.abs(last1H.close - last1H.open) / candleRange;
      solidBody = bodyRatio >= 0.55; // Body makes up >= 55% of candle range
    }
    conditions.candleGeometry = solidBody ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Trade Levels
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[atrVals.length - 1] || (entry * 0.015);

    if (direction === 'LONG') {
      // SL below breakout candle low or retest level
      stopLoss = Math.min(last1H.low, rangeHigh - atrNow * 0.5);
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      // SL above breakout candle high or retest level
      stopLoss = Math.max(last1H.high, rangeLow + atrNow * 0.5);
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !structuralBreak ? 'NO_BREAKOUT' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = BreakoutStrategy;
