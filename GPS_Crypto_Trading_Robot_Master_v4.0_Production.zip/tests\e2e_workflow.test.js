'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert');
const config = require('../src/config');
const journal = require('../src/journal/store');
const { getPersistentScanner } = require('../src/scanner/persistentScanner');
const { createDefaultRegistry, StrategyRouter } = require('../src/strategy/registry');
const { rankOpportunities } = require('../src/scoring/ranking');
const { generateRecommendations } = require('../src/monitoring/recommendations');
const PaperEngine = require('../src/paper/engine');
const RiskEngine = require('../src/risk/engine');
const { classifyAssetClass } = require('../src/market/universe');
const { detectRegime } = require('../src/market/regime');

describe('Full End-to-End User Workflow & Command Center Integration', () => {

  before(() => {
    journal.setState('emergency_stop', false);
  });

  after(() => {
    journal.setState('emergency_stop', false);
  });

  it('1. Market Classification — all Bybit USDT perps are CRYPTO', () => {
    assert.strictEqual(classifyAssetClass('BTCUSDT', 'BTC'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('SOLUSDT', 'SOL'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('ETHUSDT', 'ETH'), 'CRYPTO');
    assert.strictEqual(classifyAssetClass('PEPEUSDT', 'PEPE'), 'CRYPTO');
  });

  it('2. Persistent Scanner Checkpointed Lifecycle (Start, Pause, Resume, Stop, Restart)', async () => {
    const scanner = getPersistentScanner();
    assert.ok(scanner, 'Scanner instance should exist');

    // Get initial state
    const initialState = scanner.getState();
    assert.ok(initialState.sessionId, 'Session ID should be defined');
    assert.ok(typeof initialState.progressPct === 'number', 'Progress pct should be numeric');

    // Pause
    const pausedState = await scanner.pause();
    assert.strictEqual(pausedState.status, 'PAUSED');

    // Stop
    const stoppedState = await scanner.stop();
    assert.strictEqual(stoppedState.status, 'STOPPED');

    // Reconnection: Check SQLite checkpoint
    const latestDbSession = journal.getLatestScanSession();
    assert.ok(latestDbSession, 'Database must have saved scan session checkpoint');
  });

  it('3. Regime Detection & Multi-Strategy Routing', () => {
    const registry = createDefaultRegistry();
    const router = new StrategyRouter(registry);

    // Trending regime routing
    const trendRegime = { canonicalRegime: 'STRONG_TREND', regime: 'TRENDING_UP' };
    const trendStrategies = router.getStrategiesForRegime(trendRegime);
    assert.ok(trendStrategies.includes('gps_v1'));
    assert.ok(trendStrategies.includes('pullback_v1'));

    // Range regime routing
    const rangeRegime = { canonicalRegime: 'RANGE', regime: 'RANGING' };
    const rangeStrategies = router.getStrategiesForRegime(rangeRegime);
    assert.ok(rangeStrategies.includes('mean_reversion_v1'));

    // Breakout regime routing
    const breakoutRegime = { canonicalRegime: 'BREAKOUT', regime: 'HIGH_VOLATILITY' };
    const breakoutStrategies = router.getStrategiesForRegime(breakoutRegime);
    assert.ok(breakoutStrategies.includes('breakout_v1'));

    // Unclear regime
    const unclearStrategies = router.getStrategiesForRegime({ canonicalRegime: 'UNCLEAR' });
    assert.strictEqual(unclearStrategies.length, 0);
  });

  it('4. Global Opportunity Ranking & Rationale Generation', () => {
    const mockSignals = [
      {
        symbol: 'SOLUSDT',
        score: 92,
        direction: 'LONG',
        regime: { confidence: 85, canonicalRegime: 'STRONG_TREND', atrRatio: 1.1 },
        cluster: 'LAYER_1',
        riskReward: 3.2,
        entry: 140,
        stopLoss: 135,
        takeProfit: 156,
        riskAmount: 0.50,
        qualified: true,
      },
      {
        symbol: 'DOGEUSDT',
        score: 76,
        direction: 'LONG',
        regime: { confidence: 60, canonicalRegime: 'RANGE', atrRatio: 0.8 },
        cluster: 'MEME',
        riskReward: 2.1,
        entry: 0.12,
        stopLoss: 0.115,
        takeProfit: 0.1305,
        riskAmount: 0.50,
        qualified: false,
      },
    ];

    const ranked = rankOpportunities(mockSignals);
    assert.strictEqual(ranked.length, 2);
    assert.ok(ranked[0].rankScore >= ranked[1].rankScore, 'Sorted descending by rank score');
    assert.strictEqual(ranked[0].symbol, 'SOLUSDT');
    assert.ok(Array.isArray(ranked[0].whySelected), 'Contains Why Selected list');
    assert.ok(ranked[0].whySelected.length > 0);
  });

  it('5. Risk Sizing & Paper Execution Lifecycle ($100 Account, 0.5% Risk, 10x Leverage)', () => {
    const risk = new RiskEngine({
      accountBalance: 100,
      riskPerTrade: 0.005, // $0.50
      maxDailyLoss: 0.03,  // $3.00
      defaultLeverage: 10,
    });

    const signal = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95, // $5 stop distance
      takeProfit: 115,
      riskReward: 3.0,
      score: 90,
    };

    const riskCheck = risk.check(signal, []);
    assert.strictEqual(riskCheck.approved, true);
    // $0.50 risk / $5 stop distance = 0.10 units
    assert.strictEqual(riskCheck.positionSize, 0.1);

    const paper = new PaperEngine({}, risk.cfg);
    // Manually register trade in paper engine
    const tradeId = 'SOLUSDT_gps_v1';
    paper.openTrades.set(tradeId, {
      id: tradeId,
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95,
      takeProfit: 115,
      positionSize: 0.1,
      initialRisk: 5,
      trailingActive: false,
      trailingStopPrice: null,
      mode: 'PAPER',
      openTime: Date.now(),
    });

    assert.strictEqual(paper.openTrades.size, 1);

    // Trailing stop activation at 1R profit ($105+)
    paper.updateTrades('SOLUSDT', 106);
    const activeTrade = paper.openTrades.get(tradeId);
    assert.ok(activeTrade.trailingActive, 'Trailing stop activates at 1R profit');
    assert.ok(activeTrade.trailingStopPrice > 95, 'Stop loss ratcheted upward');

    // Manual close individual position
    paper.closeTrade(tradeId, 'MANUAL_TEST', 107);
    assert.strictEqual(paper.openTrades.size, 0, 'Trade closed and removed');
  });

  it('6. Recommendations Engine Generation', () => {
    const res = generateRecommendations({
      openPositions: [],
      recentSignals: [
        { symbol: 'BTCUSDT', score: 90, direction: 'LONG', qualified: true },
      ],
      config: { accountBalance: 100 },
    });

    assert.ok(Array.isArray(res.recommendations), 'Recommendations should return an array');
    assert.ok(res.recommendations.length > 0, 'Should generate at least one recommendation');
    assert.ok(res.recommendations[0].title && res.recommendations[0].message, 'Recommendation contains title and message');
  });

  it('7. Snapshot & Export Persistence', () => {
    const snapId = `e2e_snap_${Date.now()}`;
    journal.saveSnapshot({
      id: snapId,
      timestamp: Date.now(),
      accountState: { balance: 100, equity: 100 },
      positions: [],
      scannerState: { status: 'COMPLETED' },
      topOpportunities: [],
      riskSettings: { riskPerTrade: 0.005 },
      summary: 'E2E workflow snapshot',
    });

    const retrieved = journal.getSnapshot(snapId);
    assert.ok(retrieved);
    assert.strictEqual(retrieved.id, snapId);
    assert.strictEqual(retrieved.summary, 'E2E workflow snapshot');
  });

  it('8. Emergency Stop Trigger & Reset Safety', () => {
    const risk = new RiskEngine();
    risk.emergencyStop();
    assert.strictEqual(risk.state.killSwitch, true);

    const testSignal = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95,
      takeProfit: 110,
      riskReward: 2.0,
      score: 90,
    };

    const blockedCheck = risk.check(testSignal, []);
    assert.strictEqual(blockedCheck.approved, false);
    assert.strictEqual(blockedCheck.reason, 'KILL_SWITCH_ACTIVE');

    // Reset emergency stop
    risk.resetKillSwitch();
    risk.enableTrading();
    assert.strictEqual(risk.state.killSwitch, false);
    const approvedCheck = risk.check(testSignal, []);
    assert.strictEqual(approvedCheck.approved, true);
  });
});
