'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  compressionLookback: 20,
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 20,
    volatilitySqueeze: 30,
    expansionTrigger: 30,
    volumeConfirmation: 20,
  },
};

/**
 * Volatility Expansion Strategy (volatility_expansion_v1)
 * Detects prolonged volatility contraction (Bollinger squeeze) followed by a high-momentum expansion impulse.
 */
class VolatilityExpansionStrategy {
  constructor(options = {}) {
    this.id = 'volatility_expansion_v1';
    this.name = options.name || 'Volatility Expansion';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime alignment (COMPRESSION, BREAKOUT, or HIGH_VOLATILITY)
    const isSuitable = ['COMPRESSION', 'BREAKOUT', 'HIGH_VOLATILITY', 'STRONG_TREND'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isSuitable ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    const bb = indicators.bollingerBands(candles1H, 20, 2);
    const lastIdx = candles1H.length - 1;
    const last1H = candles1H[lastIdx];

    // 2. Volatility squeeze detection (low bandwidth over preceding 10 bars)
    const bandwidths = bb.bandwidth.slice(lastIdx - 15, lastIdx);
    const validBandwidths = bandwidths.filter(b => !isNaN(b));
    const minBandwidth = validBandwidths.length > 0 ? Math.min(...validBandwidths) : 0.05;
    const isSqueezed = minBandwidth < 0.08 || bb.bandwidth[lastIdx - 1] < 0.07;
    conditions.volatilitySqueeze = isSqueezed ? PASS : FAIL;
    details.bandwidth = `Prior min BW: ${(minBandwidth * 100).toFixed(2)}%, Current BW: ${(bb.bandwidth[lastIdx] * 100).toFixed(2)}%`;

    // 3. Expansion trigger (current candle breaks upper or lower band with expanding bandwidth)
    let direction = null;
    let expansionTrigger = false;

    if (last1H.close > bb.upper[lastIdx]) {
      direction = 'LONG';
      expansionTrigger = true;
    } else if (last1H.close < bb.lower[lastIdx]) {
      direction = 'SHORT';
      expansionTrigger = true;
    }

    conditions.expansionTrigger = expansionTrigger ? PASS : FAIL;

    // 4. Volume surge
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[lastIdx];
    const volSurge = !isNaN(lastVolMA) && last1H.volume >= lastVolMA * 1.3;
    conditions.volumeConfirmation = volSurge ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Levels
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const mid = bb.middle[lastIdx];
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[lastIdx] || (entry * 0.015);

    if (direction === 'LONG') {
      stopLoss = Math.min(last1H.low, mid);
      const risk = entry - stopLoss;
      takeProfit = entry + risk * this.cfg.minRR;
    } else if (direction === 'SHORT') {
      stopLoss = Math.max(last1H.high, mid);
      const risk = stopLoss - entry;
      takeProfit = entry - risk * this.cfg.minRR;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !expansionTrigger ? 'NO_EXPANSION_TRIGGER' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = VolatilityExpansionStrategy;
