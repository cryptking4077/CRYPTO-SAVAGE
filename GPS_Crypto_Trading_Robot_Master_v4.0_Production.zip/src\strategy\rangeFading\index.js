'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  lookback: 20,
  minScore: 80,
  minRR: 2.0,
  weights: {
    regimeAlignment: 25,
    bandExtremeTouch: 30,
    reversalConfirmation: 25,
    volumeExhaustion: 20,
  },
};

/**
 * Range Fading Strategy (range_fading_v1)
 * Fades overextended price thrusts near the outer edges of identified consolidation ranges.
 */
class RangeFadingStrategy {
  constructor(options = {}) {
    this.id = 'range_fading_v1';
    this.name = options.name || 'Range Fading';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [] } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime alignment (RANGE or LOW_VOLATILITY)
    const isRange = ['RANGE', 'LOW_VOLATILITY'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isRange ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    const bb = indicators.bollingerBands(candles1H, 20, 2);
    const lastIdx = candles1H.length - 1;
    const last1H = candles1H[lastIdx];
    const prev1H = candles1H[lastIdx - 1];

    const upper = bb.upper[lastIdx];
    const lower = bb.lower[lastIdx];
    const mid = bb.middle[lastIdx];

    // 2. Band extreme touch / rejection
    let direction = null;
    let extremeTouch = false;

    // Fading high (SHORT)
    if (prev1H.high >= upper * 0.998 && last1H.close < prev1H.close) {
      direction = 'SHORT';
      extremeTouch = true;
    }
    // Fading low (LONG)
    else if (prev1H.low <= lower * 1.002 && last1H.close > prev1H.close) {
      direction = 'LONG';
      extremeTouch = true;
    }

    conditions.bandExtremeTouch = extremeTouch ? PASS : FAIL;
    details.bands = `Lower: ${lower.toFixed(4)}, Mid: ${mid.toFixed(4)}, Upper: ${upper.toFixed(4)}`;

    // 3. Reversal confirmation (RSI divergence or exhaustion)
    const rsiVals = indicators.rsi(candles1H, 14);
    const lastRsi = rsiVals[lastIdx];
    let reversalOk = false;

    if (direction === 'SHORT' && lastRsi >= 60) reversalOk = true;
    if (direction === 'LONG' && lastRsi <= 40) reversalOk = true;

    conditions.reversalConfirmation = isNaN(lastRsi) ? NA : (reversalOk ? PASS : FAIL);
    details.rsi = `RSI: ${!isNaN(lastRsi) ? lastRsi.toFixed(1) : 'N/A'}`;

    // 4. Volume exhaustion (fade works best when breakout volume fails)
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[lastIdx];
    const volExhausted = !isNaN(lastVolMA) && last1H.volume < lastVolMA * 1.5;
    conditions.volumeExhaustion = volExhausted ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Trade Levels
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[lastIdx] || (entry * 0.01);

    if (direction === 'SHORT') {
      stopLoss = Math.max(prev1H.high, upper) + atrNow * 0.5;
      takeProfit = mid; // Target middle band / opposite side
    } else if (direction === 'LONG') {
      stopLoss = Math.min(prev1H.low, lower) - atrNow * 0.5;
      takeProfit = mid;
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !extremeTouch ? 'NO_RANGE_EXTREME' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = RangeFadingStrategy;
