'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const GPSStrategy = require('../src/strategy/gps');
const { StrategyRegistry } = require('../src/strategy/registry');
const { scoreSignal, formatRejection } = require('../src/scoring/engine');

describe('GPS Strategy and Scoring Engine', () => {
  const createMockCandles = (count, startPrice = 100, trend = 1) => {
    const candles = [];
    let price = startPrice;
    for (let i = 0; i < count; i++) {
      const open = price;
      const close = price + trend * 0.5;
      const high = Math.max(open, close) + 0.5;
      const low = Math.min(open, close) - 0.5;
      const volume = 1000;
      candles.push({
        time: 1700000000000 + i * 900000,
        open, high, low, close, volume
      });
      price = close;
    }
    return candles;
  };

  test('Strategy returns correct condition formats (PASS, FAIL, NOT_AVAILABLE)', () => {
    const strategy = new GPSStrategy();
    const candles4H = createMockCandles(40, 100, 1);
    const candles1H = createMockCandles(40, 100, 1);
    const candles15M = createMockCandles(40, 100, 1);

    const result = strategy.evaluate({
      candles4H,
      candles1H,
      candles15M,
      meta: { symbol: 'SOLUSDT', fundingRate: 0.0001, openInterest: 50000 }
    });

    assert.ok(typeof result.score === 'number');
    assert.ok(result.conditions);
    const validStates = ['PASS', 'FAIL', 'NOT_AVAILABLE'];
    Object.values(result.conditions).forEach(val => {
      assert.ok(validStates.includes(val), `Expected ${val} to be valid state`);
    });
  });

  test('Rename strategy preserves internal stable id', () => {
    const strategy = new GPSStrategy();
    assert.equal(strategy.id, 'gps_v1');
    assert.equal(strategy.name, 'GPS');

    strategy.rename('Quantum Trend');
    assert.equal(strategy.id, 'gps_v1');
    assert.equal(strategy.name, 'Quantum Trend');
  });

  test('Pluggable strategy registry handles enable, disable, and evaluation', async () => {
    const registry = new StrategyRegistry();
    const strat = new GPSStrategy();
    registry.register(strat);

    assert.equal(registry.getAll().length, 1);
    assert.equal(registry.getEnabled().length, 1);

    registry.setEnabled('gps_v1', false);
    assert.equal(registry.getEnabled().length, 0);

    const resDisabled = await registry.evaluateAll({ symbol: 'SOLUSDT' });
    assert.equal(resDisabled.length, 0);

    registry.setEnabled('gps_v1', true);
    assert.equal(registry.getEnabled().length, 1);
  });

  test('Scoring engine rejects weak setups and sets NO_TRADE', () => {
    const weakSignal = {
      strategyId: 'gps_v1',
      strategyName: 'GPS',
      strategyVersion: '1.0.0',
      symbol: 'SOLUSDT',
      direction: 'LONG',
      score: 60, // Below default 85
      entry: 100,
      stopLoss: 95,
      takeProfit: 115,
      riskReward: 3.0,
      conditions: { trend4H: 'PASS' }
    };

    const scored = scoreSignal(weakSignal, { minScore: 85, minRR: 2.0 });
    assert.equal(scored.decision, 'NO_TRADE');
    assert.ok(scored.rejectionReason.includes('Score 60 < minimum 85'));

    const formatted = formatRejection(scored);
    assert.ok(formatted.includes('NO TRADE'));
    assert.ok(formatted.includes('SOLUSDT'));
  });

  test('Scoring engine approves setups meeting score and RR', () => {
    const strongSignal = {
      strategyId: 'gps_v1',
      strategyName: 'GPS',
      strategyVersion: '1.0.0',
      symbol: 'SOLUSDT',
      direction: 'LONG',
      score: 90,
      entry: 100,
      stopLoss: 95,
      takeProfit: 115,
      riskReward: 3.0,
      conditions: { trend4H: 'PASS' }
    };

    const scored = scoreSignal(strongSignal, { minScore: 85, minRR: 2.0 });
    assert.equal(scored.decision, 'TRADE');
    assert.equal(scored.rejectionReason, null);
  });
});
