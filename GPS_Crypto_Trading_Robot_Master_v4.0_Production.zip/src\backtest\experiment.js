'use strict';

const Backtester = require('./engine');
const dataFeed = require('../market/dataFeed');
const logger = require('../utils/logger');

const MIN_SAMPLE_WARN = 20; // warn if fewer trades

/**
 * Experiment Engine
 * Tests multiple strategy configurations and compares results
 */
class ExperimentEngine {
  /**
   * Run experiments across configurations
   * @param {string} symbol
   * @param {Array} configurations — array of strategyConfig objects
   * @param {object} options
   */
  async run(symbol, configurations, options = {}) {
    logger.info(`EXPERIMENT: ${symbol} — testing ${configurations.length} configurations`);

    const maxCandles = options.maxCandles || 2000;
    logger.info(`EXPERIMENT: Pre-fetching historical candles for ${symbol}...`);
    const [candles4H, candles1H, candles15M] = await Promise.all([
      dataFeed.getHistoricalCandles(symbol, '4h', Math.min(maxCandles, 2000)),
      dataFeed.getHistoricalCandles(symbol, '1h', Math.min(maxCandles * 4, 5000)),
      dataFeed.getHistoricalCandles(symbol, '15m', Math.min(maxCandles * 16, 10000)),
    ]);

    const runOptions = {
      ...options,
      candles: { candles4H, candles1H, candles15M }
    };

    const results = [];

    for (let i = 0; i < configurations.length; i++) {
      const cfg = configurations[i];
      const label = cfg.label || `Config-${i + 1}`;
      logger.info(`  Testing: ${label}`);

      try {
        const backtester = new Backtester(cfg, options.riskConfig || {});
        const result = await backtester.run(symbol, runOptions);

        results.push({
          label,
          config: cfg,
          status: result.status,
          period: result.period,
          inSample: result.status === 'COMPLETE' ? result.inSample : null,
          outOfSample: result.status === 'COMPLETE' ? result.outOfSample : null,
          warning: this._getWarning(result),
        });
      } catch (err) {
        logger.error(`Experiment config "${label}" failed: ${err.message}`);
        results.push({ label, config: cfg, status: 'ERROR', error: err.message });
      }
    }

    return {
      symbol,
      experiments: results,
      comparison: this._compare(results),
      summary: this._summarize(results),
    };
  }

  /** Compare metrics across configs */
  _compare(results) {
    const valid = results.filter(r => r.status === 'COMPLETE' && r.outOfSample?.totalTrades > 0);
    if (valid.length === 0) return null;

    // Sort by multiple criteria — NOT just win rate
    const scored = valid.map(r => {
      const m = r.outOfSample;
      return {
        label: r.label,
        config: r.config,
        totalTrades:  m.totalTrades,
        winRate:      m.winRate,
        profitFactor: m.profitFactor,
        expectancy:   m.expectancy,
        avgR:         m.avgR,
        maxDrawdown:  m.maxDrawdownPct,
        returnPct:    m.returnPct,
        smallSample:  m.totalTrades < MIN_SAMPLE_WARN,
      };
    });

    // Rank by profit factor (better than win rate alone)
    scored.sort((a, b) => b.profitFactor - a.profitFactor);

    return {
      ranked: scored,
      best: scored[0] || null,
      note: 'Ranked by out-of-sample Profit Factor. Win rate alone is NOT the primary criterion.',
    };
  }

  _getWarning(result) {
    if (result.status !== 'COMPLETE') return null;
    const oos = result.outOfSample;
    if (!oos) return null;
    if (oos.totalTrades < MIN_SAMPLE_WARN) {
      return `⚠ Small sample: only ${oos.totalTrades} out-of-sample trades. Results may not be statistically reliable.`;
    }
    return null;
  }

  _summarize(results) {
    const complete = results.filter(r => r.status === 'COMPLETE');
    const errors   = results.filter(r => r.status === 'ERROR');
    return {
      total: results.length,
      complete: complete.length,
      errors: errors.length,
      note: 'All results show out-of-sample performance. Never optimize and validate on the same data.',
    };
  }

  /**
   * Factory: score threshold experiments
   */
  static scoreThresholds(baseConfig = {}) {
    return [75, 80, 85, 90].map(score => ({
      ...baseConfig,
      minScore: score,
      label: `MinScore=${score}`,
    }));
  }

  /**
   * Factory: R:R threshold experiments
   */
  static rrThresholds(baseConfig = {}) {
    return [1.5, 2.0, 2.5, 3.0].map(rr => ({
      ...baseConfig,
      minRR: rr,
      label: `MinRR=${rr}`,
    }));
  }

  /**
   * Factory: volume multiplier experiments
   */
  static volumeThresholds(baseConfig = {}) {
    return [1.0, 1.2, 1.5, 2.0].map(vol => ({
      ...baseConfig,
      minVolumeMultiplier: vol,
      label: `VolMultiplier=${vol}`,
    }));
  }
}

module.exports = ExperimentEngine;
