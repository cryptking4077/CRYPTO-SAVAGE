'use strict';

const EventEmitter = require('events');
const logger = require('../utils/logger');

/**
 * Lightweight Central Event Bus for the Trading System.
 *
 * Supported Event Channels:
 * - opportunity.found
 * - opportunity.qualified
 * - opportunity.rejected
 * - position.opened
 * - position.updated
 * - position.closed
 * - position.trailing_updated
 * - risk.breach
 * - scanner.status
 * - scanner.checkpoint
 * - scanner.error
 * - emergency.triggered
 * - command.received
 * - trade.autopsy.completed
 */
class EventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
    this._history = [];
    this._maxHistory = 500;
  }

  /**
   * Publish an event with timestamp and auto-logging
   * @param {string} eventName
   * @param {object} payload
   */
  emitEvent(eventName, payload = {}) {
    const event = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      event: eventName,
      timestamp: Date.now(),
      payload,
    };

    this._history.push(event);
    if (this._history.length > this._maxHistory) {
      this._history.shift();
    }

    logger.debug(`[EVENT] ${eventName}: ${JSON.stringify(payload).slice(0, 150)}`);
    this.emit(eventName, payload, event);
    this.emit('*', eventName, payload, event);
    return event;
  }

  /**
   * Get recent event history
   * @param {number} limit
   * @param {string} [filterEvent]
   */
  getRecentEvents(limit = 50, filterEvent = null) {
    let list = this._history;
    if (filterEvent) {
      list = list.filter(e => e.event === filterEvent);
    }
    return list.slice(-limit).reverse();
  }

  /**
   * Clear event history (testing utility)
   */
  clearHistory() {
    this._history = [];
  }
}

// Singleton event bus instance
const globalBus = new EventBus();

module.exports = {
  EventBus,
  eventBus: globalBus,
};
