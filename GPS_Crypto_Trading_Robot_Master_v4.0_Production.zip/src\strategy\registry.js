const GPSStrategy = require('./gps');
const MeanReversionStrategy = require('./meanReversion');
const BreakoutStrategy = require('./breakout');
const PullbackStrategy = require('./pullback');
const RangeFadingStrategy = require('./rangeFading');
const MomentumSRStrategy = require('./momentumSR');
const OpeningRangeBreakoutStrategy = require('./orb');
const VolatilityExpansionStrategy = require('./volatilityExpansion');
const VWAPStructureStrategy = require('./vwapStructure');
const StrategyRouter = require('./router');
const logger = require('../utils/logger');

/**
 * Strategy Registry — pluggable multi-strategy system
 *
 * To add a new strategy:
 * 1. Create src/strategy/myStrategy/index.js implementing evaluate()
 * 2. Register it here with registerStrategy()
 */
class StrategyRegistry {
  constructor() {
    this._strategies = new Map();
  }

  /** Register a strategy instance */
  register(strategy) {
    if (!strategy.id || !strategy.evaluate) {
      throw new Error(`Strategy must have id and evaluate(): ${strategy}`);
    }
    this._strategies.set(strategy.id, strategy);
    logger.info(`Strategy registered: ${strategy.id} (${strategy.name} v${strategy.version})`);
  }

  /** Get all registered strategies */
  getAll() {
    return Array.from(this._strategies.values());
  }

  /** Get enabled strategies */
  getEnabled() {
    return this.getAll().filter(s => s.enabled);
  }

  /** Get strategy by ID */
  get(id) {
    return this._strategies.get(id) || null;
  }

  /** Enable/disable a strategy */
  setEnabled(id, enabled) {
    const s = this._strategies.get(id);
    if (!s) throw new Error(`Strategy not found: ${id}`);
    s.enabled = enabled;
    logger.info(`Strategy ${id} ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }

  /** Rename a strategy display name (ID unchanged) */
  rename(id, newName) {
    const s = this._strategies.get(id);
    if (!s) throw new Error(`Strategy not found: ${id}`);
    const old = s.name;
    s.name = newName;
    logger.info(`Strategy ${id} renamed: "${old}" → "${newName}"`);
  }

  /**
   * Run all enabled strategies on a market's data
   * Handles conflicts (LONG vs SHORT) → NO_TRADE
   *
   * @param {object} marketData — { symbol, candles4H, candles1H, candles15M, meta }
   * @returns {Array} — array of signal objects
   */
  async evaluateAll(marketData) {
    const enabled = this.getEnabled();
    if (enabled.length === 0) return [];

    const results = [];

    for (const strategy of enabled) {
      try {
        const signal = strategy.evaluate(marketData);
        results.push(signal);
      } catch (err) {
        logger.error(`Strategy ${strategy.id} error on ${marketData.symbol}: ${err.message}`);
      }
    }

    // Conflict detection: same symbol, opposing directions
    const qualifiedResults = results.filter(r => r.qualified);
    if (qualifiedResults.length >= 2) {
      const dirs = new Set(qualifiedResults.map(r => r.direction));
      if (dirs.has('LONG') && dirs.has('SHORT')) {
        logger.noTrade(`${marketData.symbol}: Strategy conflict — LONG vs SHORT → NO_TRADE`);
        return results.map(r => ({ ...r, qualified: false, rejectionReason: 'STRATEGY_CONFLICT' }));
      }
    }

    return results;
  }

  /** List strategy status */
  status() {
    return this.getAll().map(s => ({
      id: s.id,
      name: s.name,
      version: s.version,
      enabled: s.enabled,
    }));
  }
}

/** Factory — creates default registry with all 9 production strategies */
function createDefaultRegistry(strategyConfig = {}) {
  const registry = new StrategyRegistry();
  
  registry.register(new GPSStrategy(strategyConfig));
  registry.register(new MeanReversionStrategy(strategyConfig.meanReversion || {}));
  registry.register(new BreakoutStrategy(strategyConfig.breakout || {}));
  registry.register(new PullbackStrategy(strategyConfig.pullback || {}));
  registry.register(new RangeFadingStrategy(strategyConfig.rangeFading || {}));
  registry.register(new MomentumSRStrategy(strategyConfig.momentumSR || {}));
  registry.register(new OpeningRangeBreakoutStrategy(strategyConfig.orb || {}));
  registry.register(new VolatilityExpansionStrategy(strategyConfig.volatilityExpansion || {}));
  registry.register(new VWAPStructureStrategy(strategyConfig.vwapStructure || {}));

  return registry;
}

module.exports = { StrategyRegistry, StrategyRouter, createDefaultRegistry };

