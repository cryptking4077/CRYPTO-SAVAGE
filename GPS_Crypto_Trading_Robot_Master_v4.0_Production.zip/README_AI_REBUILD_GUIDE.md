# AI REBUILD & ARCHITECTURE GUIDE
## GPS Crypto Trading Robot & Command Center (Production Edition)

> **Document Purpose**: This guide provides full mathematical specifications, architectural blueprints, dependency constraints, database schemas, and step-by-step rebuild instructions so another AI agent or software engineer can replicate, maintain, or extend this exact trading system from scratch without ambiguity.

---

## 1. System Overview & Core Directives

- **Domain**: Automated quantitative trading robot and interactive command center for **Bybit USDT Linear Perpetual Contracts (Crypto Only)**.
- **Runtime Environment**: **Node.js 24 Native** (Zero external npm packages; zero third-party dependencies).
- **Native Subsystems Utilized**:
  - `node:sqlite` (`DatabaseSync` with WAL journal mode)
  - `node:test` + `node:assert/strict` for the test runner
  - Native `fetch` + `AbortSignal` for Bybit REST API & Telegram Long Polling
  - `node:http` for the Command Center Dashboard HTTP server
  - `node:crypto` for UUIDs and hashes
  - `node:events` for the Central Event Bus
- **Default Execution Mode**: `PAPER` (`config.mode = 'PAPER'`).
- **Autopilot State**: `AUTOPILOT = ON`.
- **Alpha Engine**: `alphaEnabled: false` (Strictly disabled).
- **Live Trading**: Quadruple-gated safety isolation (`LIVE_TRADING_ENABLED = false`).

---

## 2. Configurable Paper Capital & Risk Formulas

Capital is not hardcoded. Starting capital is configurable via environment variables (`ACCOUNT_BALANCE` / `PAPER_CAPITAL`).

### Sizing & Risk Mathematical Equations

1. **Risk per Trade**:
   $$\text{Risk Amount (\USD)} = \text{Account Balance} \times \text{Risk Per Trade Pct}$$
   *(Default: $\$100 \times 0.5\% = \$0.50$)*

2. **Position Sizing**:
   $$\text{Risk Per Unit} = |\text{Entry Price} - \text{Stop Loss Price}|$$
   $$\text{Position Size (Units)} = \frac{\text{Risk Amount}}{\text{Risk Per Unit}}$$

3. **Max Daily Loss Limit**:
   $$\text{Max Daily Loss (\USD)} = \text{Account Balance} \times \text{Max Daily Loss Pct}$$
   *(Default: $\$100 \times 3.0\% = \$3.00$)*

4. **Capital Isolation Guarantees**:
   - Changing capital scales monetary risk linearly while keeping risk percentage constant.
   - Leverage settings (`1x` to `100x`) determine margin requirements only ($\text{Margin} = \frac{\text{Notional}}{\text{Leverage}}$) and **never increase monetary risk**.

---

## 3. Directory Layout & Module Blueprint

```text
CRYPTO/
├── config/
├── dashboard/
│   ├── server.js                      # REST API & WebSocket/HTTP Dashboard server
│   └── public/
│       └── index.html                 # Single-page Command Center frontend
├── data/
│   └── robot.db                       # SQLite database (WAL mode)
├── src/
│   ├── config.js                      # Zero-dep .env loader & configuration
│   ├── robot.js                       # Autonomous trading engine daemon
│   ├── events/
│   │   └── bus.js                     # Central EventBus (typed events, wildcard, history)
│   ├── exchanges/
│   │   ├── base.js                    # Base exchange interface
│   │   └── bybit.js                   # Public Bybit v5 REST client with auto-retries
│   ├── execution/
│   │   ├── live.js                    # 8-gate live execution engine
│   │   └── reconciliation.js          # Position & balance reconciliation
│   ├── indicators/
│   │   └── index.js                   # SMA, EMA, RSI, ATR, Alligator, BB, VWAP, Swings
│   ├── journal/
│   │   └── store.js                   # SQLite persistence, migrations, and schema
│   ├── learning/
│   │   └── autopsy.js                 # Trade autopsy diagnostics, MFE/MAE, setup similarity
│   ├── market/
│   │   ├── dataFeed.js                # Multi-timeframe OHLCV, funding rates, open interest
│   │   ├── dataQuality.js             # Candle gap detection & data integrity validation
│   │   ├── regime.js                  # 7 canonical market regimes classification
│   │   ├── session.js                 # 24/7 crypto session manager
│   │   └── universe.js                # Dynamic Bybit USDT perp discovery & filtering
│   ├── monitoring/
│   │   ├── recommendations.js         # Automated portfolio advisory engine
│   │   └── watchdog.js                # Heartbeat monitor, DB health, latency watchdog
│   ├── notifications/
│   │   ├── index.js                   # Notification dispatcher
│   │   ├── telegram.js                # Outbound HTML alert formatters
│   │   └── telegramBot.js             # Interactive polling command bot (@MultiStratos1_bot)
│   ├── paper/
│   │   └── engine.js                  # Paper execution simulator, trailing stop ratchet
│   ├── risk/
│   │   └── engine.js                  # 12-gate risk engine, correlation cluster exposure
│   ├── scanner/
│   │   └── persistentScanner.js       # Checkpointed background scanner daemon
│   ├── scoring/
│   │   ├── engine.js                  # Deterministic 0-100 score & NO_TRADE filtering
│   │   └── ranking.js                 # Multi-factor opportunity ranking (0-100)
│   ├── strategy/
│   │   ├── registry.js                # Pluggable 9-strategy registry
│   │   ├── router.js                  # Intelligent regime-to-strategy router
│   │   ├── gps/index.js               # 1. Trend Following (GPS v1)
│   │   ├── meanReversion/index.js     # 2. Mean Reversion
│   │   ├── breakout/index.js          # 3. Breakout & Expansion
│   │   ├── pullback/index.js          # 4. Trend Pullback Continuation
│   │   ├── rangeFading/index.js       # 5. Range Fading
│   │   ├── momentumSR/index.js        # 6. Momentum & Key Level S/R
│   │   ├── orb/index.js               # 7. Opening Range Breakout (ORB)
│   │   ├── volatilityExpansion/index.js# 8. Volatility Expansion (BB Squeeze)
│   │   └── vwapStructure/index.js     # 9. VWAP & Market Structure
│   ├── backtest/
│   │   ├── engine.js                  # Chronological historical backtester
│   │   ├── experiment.js              # Strategy parameter grid experimenter
│   │   └── walkForward.js             # Rolling out-of-sample walk-forward validator
│   └── utils/
│       └── logger.js                  # Structured level-based logger
├── tests/
│   ├── all_strategies.test.js         # Full 9-strategy execution test
│   ├── configurable_capital.test.js   # Capital presets & isolation tests
│   ├── event_bus.test.js              # Pub/sub, wildcard, history tests
│   ├── trade_autopsy.test.js          # Autopsy diagnostics & similarity tests
│   ├── crypto_universe.test.js        # Crypto-only universe tests
│   ├── session.test.js                # 24/7 session tests
│   ├── e2e_workflow.test.js           # Full system E2E workflow tests
│   ├── dashboard_api.test.js          # REST API endpoint tests
│   ├── dashboard_analytics.test.js    # Financial math & metrics tests
│   ├── opportunity_ranking.test.js    # Multi-factor ranking tests
│   ├── strategy_routing.test.js       # Router regime mapping tests
│   ├── trailing_stop.test.js          # Trailing ratchet logic tests
│   ├── risk_safety.test.js            # 12-gate risk checks tests
│   ├── correlation_risk.test.js       # Cluster concentration tests
│   ├── indicators.test.js             # Mathematical indicator tests
│   └── ... (36 test suites total)
├── .env.example
├── package.json
└── README.md
```

---

## 4. Complete 9-Strategy Suite & Regime Mapping

The [`StrategyRouter`](file:///src/strategy/router.js) maps real-time detected regimes to matching strategies:

| Strategy ID | Name | Target Regime | Key Triggers / Conditions |
|---|---|---|---|
| `gps_v1` | **GPS Trend Following** | `STRONG_TREND`, `WEAK_TREND` | 4H swing structure, 1H Alligator alignment, 15M trigger, liquidity sweep reclaim, volume surge. |
| `mean_reversion_v1` | **Mean Reversion** | `RANGE`, `LOW_VOLATILITY` | Bollinger band boundary overshoot + RSI exhaustion, reversion to 20 SMA. |
| `breakout_v1` | **Breakout Expansion** | `BREAKOUT`, `COMPRESSION` | 20-period high/low penetration with volume expansion > 1.3x and solid candle body. |
| `pullback_v1` | **Trend Pullback** | `PULLBACK`, `STRONG_TREND` | Trend retracement to 21 EMA or Alligator teeth with rejection confirmation. |
| `range_fading_v1` | **Range Fading** | `RANGE`, `LOW_VOLATILITY` | Rejection of outer range extremes with volume exhaustion. |
| `momentum_sr_v1` | **Momentum & S/R** | `STRONG_TREND`, `BREAKOUT` | Horizontal S/R flip retest with EMA 9/21 momentum continuation. |
| `orb_v1` | **Opening Range Breakout** | `BREAKOUT`, `COMPRESSION` | Multi-bar opening range breakout with directional follow-through. |
| `volatility_expansion_v1` | **Volatility Expansion** | `COMPRESSION`, `BREAKOUT` | Bollinger bandwidth squeeze (< 8%) followed by band break + volume surge. |
| `vwap_structure_v1` | **VWAP & Structure** | `STRONG_TREND`, `WEAK_TREND` | Institutional VWAP hold with HH/HL (Bullish) or LH/LL (Bearish) swing structure. |

*Note: In `UNCLEAR` / `UNCERTAIN` regimes, the router deterministically outputs `NO_TRADE`.*

---

## 5. Memory & Learning / Trade Autopsy Engine

Located at [`src/learning/autopsy.js`](file:///src/learning/autopsy.js). When any trade closes (Paper or Live), the engine automatically records:

1. **Maximum Favorable Excursion (MFE)**: Peak profit excursion reached during trade lifespan (measured in price and R multiple).
2. **Maximum Adverse Excursion (MAE)**: Worst drawdown excursion during trade lifespan.
3. **Stop Loss Tightness Diagnostic**:
   - `TOO_TIGHT`: Reached > 1.2R in favor before reversing to hit initial SL.
   - `PRECISE_HIT`: Immediate adverse move into SL with minimal favorable excursion.
   - `OPTIMAL`: Normal stop behavior.
4. **Take Profit Ambition Diagnostic**:
   - `OVER_AMBITIOUS`: Reached >= 2.0R but did not reach full target.
   - `CONSERVATIVE`: Exited at TP while price continued > 1.5R further.
   - `REALISTIC`: Target aligned with structural liquidity.
5. **Trailing Stop Efficiency**:
   - `PROTECTIVE`: Secured profits after trend extension.
   - `PREMATURE_CUT`: Stopped out on minor noise before full target.
6. **Setup Similarity Engine**:
   - Matches candidate setups with historical autopsy database to output sample size, historical win rate, expected R, and confidence recommendation (`HIGH_HISTORICAL_EDGE`, `STANDARD_EXECUTION`, `CAUTION_LOW_HISTORICAL_WINRATE`).

---

## 6. Interactive Telegram Bot Specifications

- **Bot Username**: `@MultiStratos1_bot`
- **Architecture**: Polling-based (`getUpdates` with `timeout=25s`) via native `fetch`.
- **Security**: Token loaded strictly from `TELEGRAM_BOT_TOKEN` environment variable. Never logged, never printed, never returned via API.
- **Admin Guard**: Admin commands check `TELEGRAM_ADMIN_CHAT_ID`.
- **Emergency Safeguard**: `/emergency` arms a 30-second pending state requiring explicit `/confirm` before halting execution.

---

## 7. Central Event Bus Specifications

- **Module**: [`src/events/bus.js`](file:///src/events/bus.js)
- **Standard Events**:
  - `opportunity.found` — Scanner detected setup
  - `opportunity.qualified` — Setup met score (>=85) and R:R (>=2.0)
  - `opportunity.rejected` — Setup rejected with reason
  - `position.opened` — Trade opened (Paper/Live)
  - `position.updated` — Mark price / unrealized PnL update
  - `position.closed` — Trade closed (TP, SL, Trailing, Manual)
  - `position.trailing_updated` — Trailing stop ratcheted
  - `risk.breach` — Risk engine rejected trade or triggered limit
  - `scanner.status` — Scanner state change (RUNNING, PAUSED, STOPPED)
  - `scanner.checkpoint` — Checkpoint saved to SQLite
  - `scanner.error` — Market fetch/evaluation error
  - `emergency.triggered` — Emergency stop activated
  - `trade.autopsy.completed` — Post-trade diagnostic autopsy finished

---

## 8. Database Schema (SQLite via `node:sqlite`)

All tables created automatically on startup:

```sql
CREATE TABLE IF NOT EXISTS strategies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  enabled INTEGER DEFAULT 1,
  config TEXT,
  created_at INTEGER,
  updated_at INTEGER
);

CREATE TABLE IF NOT EXISTS signals (
  id TEXT PRIMARY KEY,
  strategy_id TEXT,
  strategy_name TEXT,
  strategy_version TEXT,
  symbol TEXT,
  direction TEXT,
  score INTEGER,
  entry REAL,
  stop_loss REAL,
  take_profit REAL,
  risk_reward REAL,
  conditions TEXT,
  regime TEXT,
  cluster TEXT,
  qualified INTEGER,
  decision TEXT,
  rejection_reason TEXT,
  timestamp INTEGER,
  mode TEXT
);

CREATE TABLE IF NOT EXISTS paper_trades (
  id TEXT PRIMARY KEY,
  strategy_id TEXT,
  strategy_name TEXT,
  strategy_version TEXT,
  symbol TEXT,
  direction TEXT,
  entry REAL,
  stop_loss REAL,
  take_profit REAL,
  exit_price REAL,
  position_size REAL,
  pnl REAL,
  fee REAL,
  slippage REAL,
  outcome TEXT,
  exit_reason TEXT,
  score INTEGER,
  risk_reward REAL,
  regime TEXT,
  cluster TEXT,
  open_time INTEGER,
  close_time INTEGER,
  duration_ms INTEGER,
  mode TEXT DEFAULT 'PAPER'
);

CREATE TABLE IF NOT EXISTS scan_sessions (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  started_at INTEGER,
  updated_at INTEGER,
  current_asset_class TEXT,
  current_instrument TEXT,
  total_markets INTEGER DEFAULT 0,
  analyzed_count INTEGER DEFAULT 0,
  remaining_count INTEGER DEFAULT 0,
  qualified_count INTEGER DEFAULT 0,
  rejected_count INTEGER DEFAULT 0,
  error_count INTEGER DEFAULT 0,
  completed_symbols TEXT,
  failed_symbols TEXT,
  qualified_setups TEXT,
  config TEXT
);

CREATE TABLE IF NOT EXISTS trade_autopsies (
  id TEXT PRIMARY KEY,
  trade_id TEXT UNIQUE NOT NULL,
  symbol TEXT NOT NULL,
  strategy_id TEXT,
  direction TEXT,
  regime TEXT,
  outcome TEXT,
  pnl REAL,
  r_multiple REAL,
  mfe REAL,
  mae REAL,
  mfe_r REAL,
  mae_r REAL,
  sl_tightness TEXT,
  tp_ambition TEXT,
  trailing_efficiency TEXT,
  lessons TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS snapshots (
  id TEXT PRIMARY KEY,
  timestamp INTEGER NOT NULL,
  account_state TEXT,
  positions TEXT,
  scanner_state TEXT,
  top_opportunities TEXT,
  risk_settings TEXT,
  summary TEXT
);
```

---

## 9. How to Rebuild, Run, and Validate

### 1. Verification & Test Suite Run
```bash
# Run all 36 test suites natively
node --test tests/**/*.test.js
```

### 2. Launching Subsystems
```bash
# Start the Paper Trading Robot Daemon
npm run paper

# Start the Command Center Dashboard Server (Port 3000)
npm run dashboard

# Run One-Shot Market Universe Scanner
npm run scan

# Run Walk-Forward Validation Engine
npm run walkforward

# Run Strategy Parameter Grid Experiment
npm run experiment
```

---
*Generated for autonomous AI agents and quantitative systems engineers.*
