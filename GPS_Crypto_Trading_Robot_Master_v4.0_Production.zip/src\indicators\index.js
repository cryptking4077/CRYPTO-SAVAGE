'use strict';

/**
 * Technical Indicators
 * All functions take arrays of candle objects: { time, open, high, low, close, volume }
 * Return values are arrays aligned to input candles (NaN for insufficient data)
 */

/** Simple Moving Average */
function sma(values, period) {
  return values.map((_, i) => {
    if (i < period - 1) return NaN;
    const slice = values.slice(i - period + 1, i + 1);
    return slice.reduce((s, v) => s + v, 0) / period;
  });
}

/** Exponential Moving Average */
function ema(values, period) {
  const result = new Array(values.length).fill(NaN);
  const k = 2 / (period + 1);
  let initialized = false;
  let prev = NaN;

  for (let i = 0; i < values.length; i++) {
    if (isNaN(values[i])) continue;
    if (!initialized) {
      // Seed with SMA of first `period` values
      if (i < period - 1) continue;
      const seed = values.slice(i - period + 1, i + 1);
      prev = seed.reduce((s, v) => s + v, 0) / period;
      result[i] = prev;
      initialized = true;
    } else {
      prev = values[i] * k + prev * (1 - k);
      result[i] = prev;
    }
  }
  return result;
}

/** RSI */
function rsi(candles, period = 14) {
  const closes = candles.map(c => c.close);
  const result = new Array(candles.length).fill(NaN);
  if (closes.length < period + 1) return result;

  let avgGain = 0;
  let avgLoss = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) avgGain += diff;
    else avgLoss += Math.abs(diff);
  }
  avgGain /= period;
  avgLoss /= period;

  for (let i = period; i < closes.length; i++) {
    if (i === period) {
      const rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
      result[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + rs);
      continue;
    }
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? Math.abs(diff) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    const rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
    result[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + rs);
  }
  return result;
}

/** ATR (Average True Range) */
function atr(candles, period = 14) {
  const result = new Array(candles.length).fill(NaN);
  if (candles.length < period + 1) return result;

  // True ranges
  const trs = candles.map((c, i) => {
    if (i === 0) return c.high - c.low;
    const prevClose = candles[i - 1].close;
    return Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose));
  });

  // Seed with SMA
  let atrVal = trs.slice(1, period + 1).reduce((s, v) => s + v, 0) / period;
  result[period] = atrVal;

  for (let i = period + 1; i < candles.length; i++) {
    atrVal = (atrVal * (period - 1) + trs[i]) / period;
    result[i] = atrVal;
  }
  return result;
}

/** Williams Alligator (jaw=13/8, teeth=8/5, lips=5/3) */
function alligator(candles) {
  const mids = candles.map(c => (c.high + c.low) / 2);

  function smma(values, period, shift) {
    const raw = sma(values, period);
    const result = new Array(values.length).fill(NaN);
    // Apply Wilder's SMMA then shift forward
    let prev = NaN;
    for (let i = period - 1; i < values.length; i++) {
      if (isNaN(prev)) {
        prev = raw[i];
      } else {
        prev = (prev * (period - 1) + values[i]) / period;
      }
      const shifted = i + shift;
      if (shifted < result.length) result[shifted] = prev;
    }
    return result;
  }

  return {
    jaw:   smma(mids, 13, 8),   // Blue — slowest
    teeth: smma(mids, 8, 5),    // Red — medium
    lips:  smma(mids, 5, 3),    // Green — fastest
  };
}

/** Volume MA */
function volumeMA(candles, period = 20) {
  const vols = candles.map(c => c.volume);
  return sma(vols, period);
}

/** Volume ratio: current volume vs MA */
function volumeRatio(candles, period = 20) {
  const vols = candles.map(c => c.volume);
  const ma = sma(vols, period);
  return candles.map((c, i) => {
    if (isNaN(ma[i]) || ma[i] === 0) return NaN;
    return c.volume / ma[i];
  });
}

/** Swing highs — local maxima over `lookback` bars */
function swingHighs(candles, lookback = 5) {
  return candles.map((c, i) => {
    if (i < lookback || i > candles.length - lookback - 1) return false;
    const left = candles.slice(i - lookback, i);
    const right = candles.slice(i + 1, i + lookback + 1);
    return left.every(x => x.high <= c.high) && right.every(x => x.high <= c.high);
  });
}

/** Swing lows — local minima over `lookback` bars */
function swingLows(candles, lookback = 5) {
  return candles.map((c, i) => {
    if (i < lookback || i > candles.length - lookback - 1) return false;
    const left = candles.slice(i - lookback, i);
    const right = candles.slice(i + 1, i + lookback + 1);
    return left.every(x => x.low >= c.low) && right.every(x => x.low >= c.low);
  });
}

/**
 * Market structure — returns sequence of HH/HL/LH/LL
 * Returns array of { index, type: 'HH'|'HL'|'LH'|'LL', price }
 */
function marketStructure(candles, lookback = 5) {
  const highs = swingHighs(candles, lookback);
  const lows  = swingLows(candles, lookback);

  const points = [];
  for (let i = 0; i < candles.length; i++) {
    if (highs[i]) points.push({ index: i, kind: 'high', price: candles[i].high });
    if (lows[i])  points.push({ index: i, kind: 'low',  price: candles[i].low });
  }

  // Label HH/HL/LH/LL
  const result = [];
  let lastHigh = null;
  let lastLow  = null;

  for (const p of points) {
    if (p.kind === 'high') {
      if (lastHigh === null) { result.push({ ...p, type: 'H' }); }
      else if (p.price > lastHigh.price) { result.push({ ...p, type: 'HH' }); }
      else { result.push({ ...p, type: 'LH' }); }
      lastHigh = p;
    } else {
      if (lastLow === null) { result.push({ ...p, type: 'L' }); }
      else if (p.price > lastLow.price) { result.push({ ...p, type: 'HL' }); }
      else { result.push({ ...p, type: 'LL' }); }
      lastLow = p;
    }
  }
  return result;
}

/**
 * Trend detection from market structure
 * Returns 'BULLISH' | 'BEARISH' | 'RANGING' | 'INSUFFICIENT'
 */
function detectTrend(candles, lookback = 5) {
  const structure = marketStructure(candles, lookback);
  const highs = structure.filter(p => p.kind === 'high').slice(-3);
  const lows  = structure.filter(p => p.kind === 'low').slice(-3);

  if (highs.length < 2 || lows.length < 2) return 'INSUFFICIENT';

  const hhCount = highs.filter(p => p.type === 'HH').length;
  const hlCount = lows.filter(p => p.type === 'HL').length;
  const lhCount = highs.filter(p => p.type === 'LH').length;
  const llCount = lows.filter(p => p.type === 'LL').length;

  if (hhCount >= 1 && hlCount >= 1) return 'BULLISH';
  if (lhCount >= 1 && llCount >= 1) return 'BEARISH';
  return 'RANGING';
}

/**
 * Detect recent liquidity sweep + reclaim
 * A sweep is when price briefly breaks a swing high/low then reverses
 * Returns { swept: bool, direction: 'HIGH'|'LOW', level: number }
 */
function detectLiquiditySweep(candles, lookback = 5, recentBars = 10) {
  const len = candles.length;
  if (len < lookback + recentBars + 5) return { swept: false };

  const recent = candles.slice(len - recentBars);
  const prior = candles.slice(0, len - recentBars);

  // Find prior swing highs and lows
  const priorHighs = swingHighs(prior, lookback);
  const priorLows  = swingLows(prior, lookback);

  const keyHighs = prior.filter((_, i) => priorHighs[i]).map(c => c.high).slice(-3);
  const keyLows  = prior.filter((_, i) => priorLows[i]).map(c => c.low).slice(-3);

  if (keyHighs.length === 0 && keyLows.length === 0) return { swept: false };

  const lastClose = recent[recent.length - 1].close;

  // Check sweep of highs (price briefly went above, then returned below)
  for (const lvl of keyHighs) {
    const spikeAbove = recent.some(c => c.high > lvl);
    const reclaimBelow = recent[recent.length - 1].close < lvl;
    if (spikeAbove && reclaimBelow) {
      return { swept: true, direction: 'HIGH', level: lvl, reclaimed: true };
    }
  }

  // Check sweep of lows (price briefly went below, then returned above)
  for (const lvl of keyLows) {
    const spikeBelow = recent.some(c => c.low < lvl);
    const reclaimAbove = recent[recent.length - 1].close > lvl;
    if (spikeBelow && reclaimAbove) {
      return { swept: true, direction: 'LOW', level: lvl, reclaimed: true };
    }
  }

  return { swept: false };
}

/**
 * Bollinger Bands (period = 20, multiplier = 2)
 * Returns { upper, middle, lower, bandwidth } arrays
 */
function bollingerBands(candles, period = 20, multiplier = 2) {
  const closes = candles.map(c => c.close);
  const mid = sma(closes, period);
  const upper = new Array(candles.length).fill(NaN);
  const lower = new Array(candles.length).fill(NaN);
  const bandwidth = new Array(candles.length).fill(NaN);

  for (let i = period - 1; i < candles.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1);
    const mean = mid[i];
    const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
    const stdDev = Math.sqrt(variance);
    upper[i] = mean + multiplier * stdDev;
    lower[i] = mean - multiplier * stdDev;
    bandwidth[i] = mean > 0 ? (upper[i] - lower[i]) / mean : 0;
  }

  return { upper, middle: mid, lower, bandwidth };
}

/**
 * Volume Weighted Average Price (VWAP)
 * Returns array of VWAP values aligned with input candles
 */
function vwap(candles) {
  const result = new Array(candles.length).fill(NaN);
  let cumVol = 0;
  let cumVolPrice = 0;

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const typicalPrice = (c.high + c.low + c.close) / 3;
    const vol = c.volume || 0;
    cumVolPrice += typicalPrice * vol;
    cumVol += vol;
    result[i] = cumVol > 0 ? cumVolPrice / cumVol : typicalPrice;
  }
  return result;
}

module.exports = {
  sma, ema, rsi, atr, alligator, bollingerBands, vwap,
  volumeMA, volumeRatio,
  swingHighs, swingLows,
  marketStructure, detectTrend, detectLiquiditySweep,
};


