'use strict';

const config = require('../config');
const logger = require('../utils/logger');

const BASE_URL = config.bybit.baseUrl;
const DEFAULT_TIMEOUT = 15000;
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function request(method, path, params = {}, retries = MAX_RETRIES) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      let url = `${BASE_URL}${path}`;
      const options = {
        method,
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(DEFAULT_TIMEOUT),
      };

      if (method === 'GET') {
        const query = new URLSearchParams();
        for (const [k, v] of Object.entries(params)) {
          if (v !== undefined && v !== null) {
            query.append(k, String(v));
          }
        }
        const qs = query.toString();
        if (qs) url += `?${qs}`;
      } else {
        options.body = JSON.stringify(params);
      }

      const response = await fetch(url, options);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      const { retCode, retMsg, result } = data;
      if (retCode !== 0) {
        throw new Error(`Bybit API error ${retCode}: ${retMsg}`);
      }
      return result;
    } catch (err) {
      const isLast = attempt === retries;
      if (isLast) {
        logger.error(`Bybit request failed: ${method} ${path}`, err.message);
        throw err;
      }
      const delay = RETRY_DELAY_MS * Math.pow(2, attempt - 1);
      logger.warn(`Bybit request retry ${attempt}/${retries} after ${delay}ms: ${err.message}`);
      await sleep(delay);
    }
  }
}

// Public API methods

/** Get all linear USDT perpetual instruments */
async function getInstruments() {
  const result = await request('GET', '/v5/market/instruments-info', {
    category: 'linear',
    status: 'Trading',
    limit: 1000,
  });
  return result.list || [];
}

/** Get tickers for linear category */
async function getTickers(symbol) {
  const params = { category: 'linear' };
  if (symbol) params.symbol = symbol;
  const result = await request('GET', '/v5/market/tickers', params);
  return result.list || [];
}

/**
 * Get OHLCV candles
 * @param {string} symbol
 * @param {string} interval  '15','60','240','D'
 * @param {number} limit     max 200
 * @param {number} start     epoch ms start (optional)
 * @param {number} end       epoch ms end (optional)
 */
async function getKlines(symbol, interval, limit = 200, start, end) {
  const params = { category: 'linear', symbol, interval, limit };
  if (start) params.start = start;
  if (end) params.end = end;
  const result = await request('GET', '/v5/market/kline', params);
  // Bybit returns newest first — reverse to chronological
  const raw = result.list || [];
  return raw.reverse().map(c => ({
    time:   parseInt(c[0], 10),
    open:   parseFloat(c[1]),
    high:   parseFloat(c[2]),
    low:    parseFloat(c[3]),
    close:  parseFloat(c[4]),
    volume: parseFloat(c[5]),
    turnover: parseFloat(c[6]),
  }));
}

/**
 * Fetch full history by paginating backwards
 * Returns chronological candles
 */
async function getKlineHistory(symbol, interval, maxCandles = 1000) {
  const limit = 200;
  let allCandles = [];
  let end = undefined;

  while (allCandles.length < maxCandles) {
    const params = { category: 'linear', symbol, interval, limit };
    if (end) params.end = end;

    let result;
    try {
      result = await request('GET', '/v5/market/kline', params);
    } catch (e) {
      break;
    }

    const raw = (result.list || []);
    if (raw.length === 0) break;

    const candles = raw.reverse().map(c => ({
      time:   parseInt(c[0], 10),
      open:   parseFloat(c[1]),
      high:   parseFloat(c[2]),
      low:    parseFloat(c[3]),
      close:  parseFloat(c[4]),
      volume: parseFloat(c[5]),
      turnover: parseFloat(c[6]),
    }));

    // Prepend — oldest first
    allCandles = [...candles, ...allCandles];

    if (raw.length < limit) break; // no more data

    // Move end window back
    end = candles[0].time - 1;
    await sleep(200); // rate limit courtesy pause
  }

  // Deduplicate by time, keep chronological order
  const seen = new Set();
  const deduped = allCandles.filter(c => {
    if (seen.has(c.time)) return false;
    seen.add(c.time);
    return true;
  });
  deduped.sort((a, b) => a.time - b.time);

  return deduped.slice(-maxCandles);
}

/** Get funding rate history */
async function getFundingRate(symbol, limit = 1) {
  const result = await request('GET', '/v5/market/funding/history', {
    category: 'linear',
    symbol,
    limit,
  });
  const list = result.list || [];
  if (list.length === 0) return null;
  return {
    symbol,
    fundingRate: parseFloat(list[0].fundingRate),
    fundingTime: parseInt(list[0].fundingRateTimestamp, 10),
  };
}

/** Get open interest */
async function getOpenInterest(symbol, intervalTime = '4h', limit = 1) {
  const result = await request('GET', '/v5/market/open-interest', {
    category: 'linear',
    symbol,
    intervalTime,
    limit,
  });
  const list = result.list || [];
  if (list.length === 0) return null;
  return {
    symbol,
    openInterest: parseFloat(list[0].openInterest),
    time: parseInt(list[0].timestamp, 10),
  };
}

module.exports = {
  getInstruments,
  getTickers,
  getKlines,
  getKlineHistory,
  getFundingRate,
  getOpenInterest,
};
