'use strict';

const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert');
const PaperEngine = require('../src/paper/engine');

describe('Trailing Stop Logic', () => {
  let engine;

  beforeEach(() => {
    engine = new PaperEngine({}, {
      accountBalance: 100,
      riskPerTrade: 0.005,
      trailingStop: { enabled: true, activationRR: 1.0, distancePct: 0.015 },
    });
  });

  function makeTrade(overrides = {}) {
    return {
      id: 'BTCUSDT_gps_v1',
      symbol: 'BTCUSDT',
      direction: 'LONG',
      entry: 50000,
      stopLoss: 49500,
      takeProfit: 51000,
      positionSize: 0.001,
      initialRisk: 500,  // 50000 - 49500
      trailingActive: false,
      trailingStopPrice: null,
      mode: 'PAPER',
      openTime: Date.now(),
      ...overrides,
    };
  }

  it('trailing stop activates when profit >= 1R (activationRR=1.0)', () => {
    const trade = makeTrade();
    engine.openTrades.set(trade.id, trade);

    // Price moves 1R above entry (50000 + 500 = 50500) — should activate trailing
    engine.updateTrades('BTCUSDT', 50500);
    const updated = engine.openTrades.get(trade.id);
    if (updated) {
      assert.ok(updated.trailingActive, 'Trailing stop should be active at 1R profit');
      assert.ok(updated.trailingStopPrice !== null, 'trailingStopPrice should be set');
    }
    // If trade was closed it's also valid (TP hit case)
  });

  it('trailing stop only ratchets UP for LONG (never loosens)', () => {
    const trade = makeTrade({ trailingActive: true, trailingStopPrice: 50200, stopLoss: 50200 });
    engine.openTrades.set(trade.id, trade);

    // Price drops slightly — trailing stop should NOT move down
    engine.updateTrades('BTCUSDT', 50100);
    const updated = engine.openTrades.get(trade.id);
    if (updated) {
      assert.ok((updated.trailingStopPrice || 0) >= 50200 || updated.trailingStopPrice === null,
        'Trailing stop should not decrease for LONG');
    }
  });

  it('trailing stop works for SHORT direction', () => {
    const trade = makeTrade({
      direction: 'SHORT',
      entry: 50000,
      stopLoss: 50500,
      takeProfit: 49000,
      initialRisk: 500, // 50500 - 50000
    });
    engine.openTrades.set(trade.id, trade);

    // Price moves 1R below entry (50000 - 500 = 49500) for SHORT
    engine.updateTrades('BTCUSDT', 49500);
    const updated = engine.openTrades.get(trade.id);
    if (updated) {
      // If trailing activated, stop should have moved DOWN (toward profit)
      assert.ok(updated.trailingActive, 'SHORT trailing should activate at 1R profit');
    }
  });

  it('updateTrades closes trade at stopLoss hit', () => {
    const trade = makeTrade({ entry: 50000, stopLoss: 49500, takeProfit: 51000 });
    engine.openTrades.set(trade.id, trade);

    const closed = engine.updateTrades('BTCUSDT', 49000); // Below stop loss
    // Trade should be removed from openTrades
    assert.ok(!engine.openTrades.has(trade.id), 'Trade should be removed on SL hit');
    // Should return closed trade info
    assert.ok(Array.isArray(closed) && closed.length > 0 || !engine.openTrades.has(trade.id),
      'Should report closed trade');
  });

  it('updateTrades closes trade at takeProfit hit', () => {
    const trade = makeTrade({ entry: 50000, stopLoss: 49500, takeProfit: 51000 });
    engine.openTrades.set(trade.id, trade);

    engine.updateTrades('BTCUSDT', 51500); // Above take profit
    assert.ok(!engine.openTrades.has(trade.id), 'Trade should be removed on TP hit');
  });

  it('closeTrade method removes trade from openTrades', () => {
    const trade = makeTrade();
    engine.openTrades.set(trade.id, trade);
    assert.ok(engine.openTrades.has(trade.id));

    if (typeof engine.closeTrade === 'function') {
      engine.closeTrade(trade.id, 'MANUAL', 50000);
      assert.ok(!engine.openTrades.has(trade.id), 'closeTrade should remove from openTrades');
    }
  });

  it('closeAllTrades removes all trades', () => {
    engine.openTrades.set('BTCUSDT_gps_v1', makeTrade({ id: 'BTCUSDT_gps_v1', symbol: 'BTCUSDT' }));
    engine.openTrades.set('ETHUSDT_gps_v1', makeTrade({ id: 'ETHUSDT_gps_v1', symbol: 'ETHUSDT' }));
    assert.strictEqual(engine.openTrades.size, 2);

    if (typeof engine.closeAllTrades === 'function') {
      engine.closeAllTrades('MANUAL');
      assert.strictEqual(engine.openTrades.size, 0, 'closeAllTrades should empty openTrades');
    }
  });
});
