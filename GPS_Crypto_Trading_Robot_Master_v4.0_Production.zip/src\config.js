'use strict';

const fs = require('fs');
const path = require('path');

// Minimal zero-dependency .env loader
function loadEnv() {
  const envPath = path.join(process.cwd(), '.env');
  if (fs.existsSync(envPath)) {
    const content = fs.readFileSync(envPath, 'utf8');
    content.split(/\r?\n/).forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        let val = trimmed.slice(eqIdx + 1).trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  }
}

loadEnv();

const config = {
  // Trading mode
  mode: (process.env.TRADING_MODE || 'PAPER').toUpperCase(),
  liveEnabled: process.env.LIVE_TRADING_ENABLED === 'true',

  // Bybit
  bybit: {
    apiKey: process.env.BYBIT_API_KEY || '',
    apiSecret: process.env.BYBIT_API_SECRET || '',
    testnet: process.env.BYBIT_TESTNET === 'true',
    baseUrl: process.env.BYBIT_TESTNET === 'true'
      ? 'https://api-testnet.bybit.com'
      : 'https://api.bybit.com',
  },

  // Market — CRYPTO ONLY (Bybit USDT perpetuals)
  scanIntervalSeconds: parseInt(process.env.SCAN_INTERVAL_SECONDS || '60', 10),
  scanConcurrency: Math.max(1, parseInt(process.env.SCAN_CONCURRENCY || '8', 10)),
  scanMaxMarkets: parseInt(process.env.SCAN_MAX_MARKETS || '0', 10), // 0 = unlimited
  minQuoteVolume: parseFloat(process.env.MIN_QUOTE_VOLUME || '1000000'),
  excludedSymbols: (process.env.EXCLUDED_SYMBOLS || 'BTCUSDT,ETHUSDT')
    .split(',').map(s => s.trim().toUpperCase()).filter(Boolean),

  // Alpha (must remain off)
  alphaEnabled: false,

  // Strategy defaults
  gpsStrategyName: process.env.GPS_STRATEGY_NAME || 'GPS',
  minScore: parseFloat(process.env.MIN_SCORE || '85'),
  minRR: parseFloat(process.env.MIN_RR || '2.0'),
  minVolumeMultiplier: parseFloat(process.env.MIN_VOLUME_MULTIPLIER || '1.2'),
  regimeFilterEnabled: process.env.REGIME_FILTER_ENABLED !== 'false', // default true

  // Risk engine — $100 small account default
  accountBalance: parseFloat(process.env.ACCOUNT_BALANCE || '100'),
  riskPerTrade: parseFloat(process.env.RISK_PER_TRADE || '0.005'), // 0.5% default ($0.50)
  maxDailyLoss: parseFloat(process.env.MAX_DAILY_LOSS || '0.03'),   // 3% default ($3.00)
  defaultLeverage: parseInt(process.env.DEFAULT_LEVERAGE || '10', 10),
  maxOpenPositions: parseInt(process.env.MAX_OPEN_POSITIONS || '5', 10),
  maxPortfolioExposure: parseFloat(process.env.MAX_PORTFOLIO_EXPOSURE || '0.3'),
  maxCorrelatedExposure: parseFloat(process.env.MAX_CORRELATED_EXPOSURE || '0.20'),
  maxConsecutiveLosses: parseInt(process.env.MAX_CONSECUTIVE_LOSSES || '5', 10),

  // Trailing stop management
  trailingStop: {
    enabled: process.env.TRAILING_STOP_ENABLED !== 'false',
    activationRR: parseFloat(process.env.TRAILING_ACTIVATION_RR || '1.0'), // activate when trade reaches 1R
    distancePct: parseFloat(process.env.TRAILING_DISTANCE_PCT || '0.015'),  // 1.5% trailing distance
  },

  // Execution & Reconciliation
  reconciliationIntervalSeconds: parseInt(process.env.RECONCILIATION_INTERVAL_SECONDS || '300', 10),
  watchdogHeartbeatSeconds: parseInt(process.env.WATCHDOG_HEARTBEAT_SECONDS || '30', 10),
  dataQualityEnforce: process.env.DATA_QUALITY_ENFORCE !== 'false', // default true

  // Notifications (Telegram, Email, WhatsApp)
  notifications: {
    telegram: {
      enabled: process.env.TELEGRAM_ENABLED === 'true',
      botToken: process.env.TELEGRAM_BOT_TOKEN || '',
      chatId: process.env.TELEGRAM_CHAT_ID || '',
    },
    email: {
      enabled: process.env.EMAIL_ENABLED === 'true',
      webhookUrl: process.env.EMAIL_WEBHOOK_URL || '',
      recipient: process.env.EMAIL_RECIPIENT || '',
    },
    whatsapp: {
      enabled: process.env.WHATSAPP_ENABLED === 'true',
      webhookUrl: process.env.WHATSAPP_WEBHOOK_URL || '',
      phoneNumber: process.env.WHATSAPP_PHONE_NUMBER || '',
    },
  },
  telegram: {
    enabled: process.env.TELEGRAM_ENABLED === 'true',
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    chatId: process.env.TELEGRAM_CHAT_ID || '',
  },

  // Dashboard
  dashboardPort: parseInt(process.env.DASHBOARD_PORT || '3000', 10),

  // Logging
  logLevel: (process.env.LOG_LEVEL || 'INFO').toUpperCase(),
};

// Validate live mode requirements
config.isLive = config.mode === 'LIVE' && config.liveEnabled;
config.isPaper = !config.isLive;

module.exports = config;
