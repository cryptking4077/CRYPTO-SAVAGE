'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const { NotificationService } = require('../src/notifications/index');

describe('Unified Multi-Channel Notification Service', () => {
  test('dispatches notification and suppresses rapid duplicates', async () => {
    const notifier = new NotificationService({ config: {} });

    const ev = {
      type: 'INFO',
      severity: 'INFO',
      title: 'TEST_EVENT',
      message: 'Initial test alert message',
    };

    const res1 = await notifier.dispatch(ev);
    assert.equal(res1.type, 'INFO');
    assert.ok(res1.channels);

    // Immediate duplicate without force should be suppressed
    const res2 = await notifier.dispatch(ev);
    assert.equal(res2.skipped, true);
    assert.equal(res2.reason, 'COOLDOWN_ACTIVE');

    // Forced duplicate should pass
    const res3 = await notifier.dispatch({ ...ev, force: true });
    assert.equal(res3.type, 'INFO');
    assert.equal(res3.skipped, undefined);
  });

  test('emergency stop alert dispatches with high severity and force', async () => {
    const notifier = new NotificationService({ config: {} });
    const res = await notifier.notifyEmergencyStop('Operator Killswitch');

    assert.equal(res.type, 'EMERGENCY_STOP');
    assert.equal(res.severity, 'EMERGENCY');
    assert.ok(notifier.getRecentDeliveries().length > 0);
  });
});
