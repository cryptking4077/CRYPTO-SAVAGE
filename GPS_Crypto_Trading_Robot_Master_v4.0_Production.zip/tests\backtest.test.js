'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const Backtester = require('../src/backtest/engine');
const ExperimentEngine = require('../src/backtest/experiment');

describe('Backtester and Experiment Engine', () => {
  const createMockCandles = (count, startPrice = 100) => {
    const candles = [];
    let price = startPrice;
    for (let i = 0; i < count; i++) {
      const open = price;
      const change = (i % 3 === 0 ? 1.0 : (i % 3 === 1 ? -0.4 : 0.8));
      const close = price + change;
      const high = Math.max(open, close) + 0.5;
      const low = Math.min(open, close) - 0.5;
      const volume = 1500;
      candles.push({
        time: 1700000000000 + i * 4 * 3600 * 1000,
        open, high, low, close, volume
      });
      price = close;
    }
    return candles;
  };

  test('Backtester handles empty or insufficient data gracefully', async () => {
    const backtester = new Backtester();
    const res = await backtester.run('TESTUSDT', { maxCandles: 20 });
    assert.equal(res.status, 'INCOMPLETE');
    assert.ok(res.reason.includes('INSUFFICIENT HISTORICAL DATA'));
  });

  test('Backtester metrics calculate mathematically consistent properties', () => {
    const backtester = new Backtester();
    const mockTrades = [
      { pnl: 200, result: 'WIN', entry: 100, stopLoss: 95, positionSize: 40, direction: 'LONG' },
      { pnl: -100, result: 'LOSS', entry: 100, stopLoss: 95, positionSize: 20, direction: 'LONG' },
      { pnl: 300, result: 'WIN', entry: 100, stopLoss: 95, positionSize: 40, direction: 'LONG' }
    ];
    const candles = createMockCandles(10);
    const metrics = backtester._calcMetrics(mockTrades, 10000, 'TEST', candles);

    assert.equal(metrics.totalTrades, 3);
    assert.equal(metrics.wins, 2);
    assert.equal(metrics.losses, 1);
    assert.equal(metrics.winRate, 66.67);
    assert.equal(metrics.netProfit, 400);
    assert.equal(metrics.profitFactor, 5);
  });

  test('Experiment engine factory methods generate required variations', () => {
    const scoreConfigs = ExperimentEngine.scoreThresholds();
    assert.equal(scoreConfigs.length, 4);
    assert.deepEqual(scoreConfigs.map(c => c.minScore), [75, 80, 85, 90]);

    const rrConfigs = ExperimentEngine.rrThresholds();
    assert.equal(rrConfigs.length, 4);
    assert.deepEqual(rrConfigs.map(c => c.minRR), [1.5, 2.0, 2.5, 3.0]);
  });
});
