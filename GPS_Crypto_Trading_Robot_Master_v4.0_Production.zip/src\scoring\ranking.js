'use strict';

const config = require('../config');

/**
 * Global Opportunity Ranking Engine
 *
 * Normalizes multi-factor signals into an objective 0–100 composite ranking score:
 * - Strategy Quality (40%)
 * - Regime Confidence (15%)
 * - R:R Quality (15%)
 * - Liquidity & Volume (10%)
 * - Volatility Suitability (10%)
 * - Session & Freshness (5%)
 * - Cost / Slippage Friction (5%)
 *
 * Generates transparent "Why Selected" vs "Why Not Trade" rationale.
 */

function calculateRankScore(signal, context = {}) {
  const {
    openPositions = [],
    dailyLossPct = 0,
    turnover24h = 5000000,
    sessionStatus = 'OPEN',
  } = context;

  const strategyScore = Math.min(100, Math.max(0, signal.score || 0));
  const regimeConf = Math.min(100, Math.max(0, signal.regime?.confidence || 60));

  // R:R Quality (2.0 = 70, 3.0 = 90, >= 4.0 = 100)
  const rr = signal.riskReward || 0;
  let rrScore = 0;
  if (rr >= 4.0) rrScore = 100;
  else if (rr >= 3.0) rrScore = 90;
  else if (rr >= 2.5) rrScore = 80;
  else if (rr >= 2.0) rrScore = 70;
  else if (rr >= 1.5) rrScore = 50;
  else rrScore = Math.max(0, rr * 25);

  // Liquidity Score based on 24h Turnover
  let liquidityScore = 50;
  if (turnover24h >= 20000000) liquidityScore = 100;
  else if (turnover24h >= 10000000) liquidityScore = 90;
  else if (turnover24h >= 5000000) liquidityScore = 80;
  else if (turnover24h >= 1000000) liquidityScore = 65;
  else if (turnover24h >= 200000) liquidityScore = 50;
  else liquidityScore = 30;

  // Volatility Suitability (ATR ratio near 1.0 - 1.5 is ideal)
  const atrRatio = signal.regime?.atrRatio || 1.0;
  let volScore = 70;
  if (atrRatio >= 0.9 && atrRatio <= 1.5) volScore = 95;
  else if (atrRatio > 1.5 && atrRatio <= 2.2) volScore = 80;
  else if (atrRatio < 0.9 && atrRatio >= 0.7) volScore = 75;
  else volScore = 50;

  // Session & Freshness
  let sessionScore = 70;
  if (sessionStatus === 'OPEN') sessionScore = 100;
  else if (sessionStatus === 'PRE_MARKET' || sessionStatus === 'POST_MARKET') sessionScore = 60;
  else if (sessionStatus === 'CLOSED') sessionScore = 20;

  // Cost / Slippage Friction
  const costScore = 85;

  // Composite Weighted Calculation
  const composite = (
    strategyScore * 0.40 +
    regimeConf * 0.15 +
    rrScore * 0.15 +
    liquidityScore * 0.10 +
    volScore * 0.10 +
    sessionScore * 0.05 +
    costScore * 0.05
  );

  const rankScore = parseFloat(composite.toFixed(1));

  // Build "Why Selected" Explanations
  const whySelected = [];
  if (strategyScore >= 85) whySelected.push(`High strategy score (${strategyScore}/100)`);
  if (regimeConf >= 75) whySelected.push(`High regime confidence (${regimeConf}%)`);
  if (rr >= 2.5) whySelected.push(`Excellent R:R ratio (${rr.toFixed(1)})`);
  if (signal.regime?.canonicalRegime) whySelected.push(`Optimal market regime: ${signal.regime.canonicalRegime}`);
  if (turnover24h >= 5000000) whySelected.push(`Deep liquidity ($${(turnover24h / 1e6).toFixed(1)}M 24h volume)`);
  if (sessionStatus === 'OPEN') whySelected.push(`Active market session`);

  // Build "Why Not Trade" Explanations
  const whyNotTrade = [];
  if (signal.criticalFail) whyNotTrade.push(`Critical failure: ${signal.criticalFail}`);
  if (signal.score < config.minScore) whyNotTrade.push(`Score ${signal.score} below required ${config.minScore}`);
  if (rr < config.minRR) whyNotTrade.push(`R:R ${rr} below required threshold ${config.minRR}`);
  if (dailyLossPct >= config.maxDailyLoss) whyNotTrade.push(`Daily loss limit reached (${(dailyLossPct * 100).toFixed(1)}%)`);
  if (turnover24h < 500000) whyNotTrade.push(`Thin liquidity ($${(turnover24h / 1e3).toFixed(0)}k volume)`);
  if (sessionStatus === 'CLOSED') whyNotTrade.push(`Market session is closed`);

  const existingSymbolTrade = openPositions.some(p => p.symbol === signal.symbol);
  if (existingSymbolTrade) whyNotTrade.push(`Already holding open position in ${signal.symbol}`);

  return {
    rankScore,
    rankTier: rankScore >= 88 ? 'A+' : rankScore >= 80 ? 'A' : rankScore >= 70 ? 'B' : 'C',
    factors: {
      strategyScore,
      regimeConf,
      rrScore,
      liquidityScore,
      volScore,
      sessionScore,
      costScore,
    },
    whySelected,
    whyNotTrade,
  };
}

/**
 * Rank a list of opportunity signals
 * @param {Array} signals - Array of signals from scanner or strategies
 * @param {object} context - Portfolio and market context
 * @returns {Array} - Sorted opportunities with ranking metadata
 */
function rankOpportunities(signals, context = {}) {
  if (!Array.isArray(signals) || signals.length === 0) return [];

  const evaluated = signals.map(sig => {
    const rankMeta = calculateRankScore(sig, context);
    return {
      ...sig,
      rankScore: rankMeta.rankScore,
      rankTier: rankMeta.rankTier,
      whySelected: rankMeta.whySelected,
      whyNotTrade: rankMeta.whyNotTrade,
      rankingFactors: rankMeta.factors,
    };
  });

  // Sort: Qualified first, then by rankScore descending
  evaluated.sort((a, b) => {
    if (a.qualified && !b.qualified) return -1;
    if (!a.qualified && b.qualified) return 1;
    return (b.rankScore || 0) - (a.rankScore || 0);
  });

  return evaluated;
}

module.exports = { calculateRankScore, rankOpportunities };
