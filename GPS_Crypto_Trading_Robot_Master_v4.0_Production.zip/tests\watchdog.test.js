'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const Watchdog = require('../src/monitoring/watchdog');
const journal = require('../src/journal/store');

describe('Robot Watchdog / Self-Monitoring Service', () => {
  test('health check validates database read/write and API latency', async () => {
    const watchdog = new Watchdog();
    const report = await watchdog.checkHealth();

    assert.ok(report);
    assert.equal(report.checks.database, true);
    assert.ok(['HEALTHY', 'DEGRADED'].includes(report.status));
    assert.ok(typeof report.uptimeSeconds === 'number');
  });

  test('detects stalled scanner when last scan timestamp is too old', async () => {
    const watchdog = new Watchdog({ maxScanIntervalMs: 1000 }); // 1 sec limit
    // Set last scan in distant past
    journal.setState('last_scan', Date.now() - 5000);

    const report = await watchdog.checkHealth();
    assert.equal(report.checks.scannerActive, false);
    assert.ok(report.issues.includes('SCANNER_STALLED'));
  });
});
