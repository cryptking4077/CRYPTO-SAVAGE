'use strict';

/**
 * GPS Trading Robot — Telegram Command Bot
 *
 * Interactive polling-based bot (@MultiStratos1_bot).
 *
 * Token is NEVER hardcoded. Loaded exclusively from env via config.telegram.botToken.
 * The token is NOT logged, printed, or included in any report.
 *
 * Public Commands:
 *   /start /help /status /opportunities /opps /positions /pos
 *   /risk /health /summary /journal
 *
 * Admin Commands (requires TELEGRAM_ADMIN_CHAT_ID to match sender):
 *   /scan /pause /resume /stop /emergency /close <id> /closeall /confirm
 *
 * Depends on:
 *   - config.telegram.botToken  (env: TELEGRAM_BOT_TOKEN)
 *   - config.telegram.chatId    (env: TELEGRAM_CHAT_ID)  — main notification channel
 *   - process.env.TELEGRAM_ADMIN_CHAT_ID — admin chat(s), comma-separated
 *
 * Uses native Node.js fetch (no npm dependencies).
 */

const config = require('../config');
const logger = require('../utils/logger');

// ─── Constants ───────────────────────────────────────────────────────────────

const BASE_URL = () => `https://api.telegram.org/bot${config.telegram.botToken}`;
const POLL_TIMEOUT = 25;        // long-poll timeout (seconds)
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 5000;

// ─── State ────────────────────────────────────────────────────────────────────

let _offset = 0;
let _running = false;
let _abortController = null;
let _robotHandlers = null; // injected robot interface

// Pending /emergency confirmations per chat_id
const _pendingConfirm = new Map();

// ─── Admin Access Control ─────────────────────────────────────────────────────

function getAdminIds() {
  const raw = process.env.TELEGRAM_ADMIN_CHAT_ID || '';
  return new Set(
    raw.split(',').map(s => s.trim()).filter(Boolean)
  );
}

function isAdmin(chatId) {
  const adminIds = getAdminIds();
  if (adminIds.size === 0) return false; // no admins configured = no admin access
  return adminIds.has(String(chatId));
}

// ─── Telegram API helpers ─────────────────────────────────────────────────────

async function apiCall(method, body = {}, retries = MAX_RETRIES) {
  const token = config.telegram.botToken;
  if (!token) return null;

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const url = `${BASE_URL()}/${method}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(30000),
      });
      const data = await res.json();
      if (data.ok) return data.result;
      logger.warn(`Telegram API ${method} error: ${data.description}`);
      return null;
    } catch (err) {
      if (attempt < retries) {
        await new Promise(r => setTimeout(r, RETRY_DELAY_MS));
      } else {
        logger.error(`Telegram API ${method} failed after ${retries} attempts: ${err.message}`);
      }
    }
  }
  return null;
}

async function sendMessage(chatId, text, extra = {}) {
  return apiCall('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    ...extra,
  });
}

async function getUpdates(offset, timeout) {
  const token = config.telegram.botToken;
  if (!token) return [];
  try {
    const url = `${BASE_URL()}/getUpdates`;
    const ctrl = new AbortController();
    _abortController = ctrl;

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        offset,
        timeout,
        allowed_updates: ['message'],
      }),
      signal: ctrl.signal,
    });
    const data = await res.json();
    if (data.ok) return data.result || [];
  } catch (err) {
    if (err.name !== 'AbortError') {
      logger.warn(`Telegram poll error: ${err.message}`);
    }
  }
  return [];
}

// ─── Command Handlers ─────────────────────────────────────────────────────────

async function handleStart(msg) {
  const text = [
    '👋 <b>GPS Multi-Strategy Trading Robot</b>',
    '',
    'CRYPTO ONLY | Bybit USDT Perpetuals',
    '',
    '<b>Public Commands:</b>',
    '/status — Robot status overview',
    '/health — System health check',
    '/positions — Open positions',
    '/opportunities — Top opportunities',
    '/risk — Risk engine status',
    '/summary — Daily summary',
    '/journal — Recent trade journal',
    '/help — Show all commands',
  ].join('\n');
  await sendMessage(msg.chat.id, text);
}

async function handleHelp(msg) {
  const adminIds = getAdminIds();
  const hasAdminConfig = adminIds.size > 0;
  const userIsAdmin = isAdmin(msg.chat.id);

  const lines = [
    '📖 <b>GPS Robot — Commands</b>',
    '',
    '<b>📊 Public:</b>',
    '/start — Welcome message',
    '/help — This help message',
    '/status — Robot status',
    '/health — System health',
    '/positions or /pos — Open positions',
    '/opportunities or /opps — Top opportunities',
    '/risk — Risk status',
    '/summary — Daily P&amp;L summary',
    '/journal — Recent closed trades',
  ];

  if (userIsAdmin) {
    lines.push(
      '',
      '<b>🔐 Admin:</b>',
      '/scan — Trigger immediate scan',
      '/pause — Pause scanner',
      '/resume — Resume scanner',
      '/stop — Stop scanner',
      '/emergency — Emergency stop (requires /confirm)',
      '/confirm — Confirm pending emergency stop',
      '/close &lt;id&gt; — Close specific position',
      '/closeall — Close all open positions',
    );
  } else if (hasAdminConfig) {
    lines.push('', '<i>Admin commands available to authorized users only.</i>');
  }

  await sendMessage(msg.chat.id, lines.join('\n'));
}

async function handleStatus(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.getStatus) {
      return sendMessage(msg.chat.id, '⚠️ Robot status unavailable — backend not connected.');
    }
    const status = await handlers.getStatus();
    const mode = status.mode || 'PAPER';
    const capital = status.capital || config.accountBalance;
    const riskPct = ((config.riskPerTrade || 0.005) * 100).toFixed(1);
    const riskAmt = (capital * (config.riskPerTrade || 0.005)).toFixed(2);
    const dailyLimitPct = ((config.maxDailyLoss || 0.03) * 100).toFixed(0);
    const dailyLimitAmt = (capital * (config.maxDailyLoss || 0.03)).toFixed(2);

    const text = [
      `🤖 <b>Robot Status</b> — <code>${mode}</code>`,
      '',
      `📊 Capital: <b>$${capital}</b>`,
      `⚡ Risk/Trade: <b>${riskPct}% ($${riskAmt})</b>`,
      `🛡️ Daily Limit: <b>${dailyLimitPct}% ($${dailyLimitAmt})</b>`,
      '',
      `🔍 Scanner: <b>${status.scannerStatus || 'UNKNOWN'}</b>`,
      `📈 Open Positions: <b>${status.openPositions || 0}</b>`,
      `🎯 Opportunities: <b>${status.opportunities || 0}</b>`,
      `💰 Daily P&amp;L: <b>${status.dailyPnL !== undefined ? (status.dailyPnL >= 0 ? '+' : '') + status.dailyPnL.toFixed(4) : 'N/A'}</b>`,
      '',
      `⏱️ <i>${new Date().toUTCString()}</i>`,
    ].join('\n');
    await sendMessage(msg.chat.id, text);
  } catch (err) {
    logger.error(`Telegram /status handler error: ${err.message}`);
    await sendMessage(msg.chat.id, '⚠️ Error fetching status.');
  }
}

async function handleHealth(msg) {
  try {
    const handlers = _robotHandlers;
    const health = handlers && handlers.getHealth
      ? await handlers.getHealth()
      : { telegram: true, scanner: '?', bybit: '?', database: '?', execution: '?' };

    const icon = (ok) => ok === true ? '✅' : ok === false ? '❌' : '❓';
    const text = [
      '🩺 <b>System Health</b>',
      '',
      `${icon(health.telegram)} Telegram`,
      `${icon(health.scanner)} Scanner`,
      `${icon(health.bybit)} Bybit API`,
      `${icon(health.database)} Database`,
      `${icon(health.execution)} Execution Engine`,
      health.dataFreshness !== undefined
        ? `${icon(health.dataFreshness)} Data Freshness`
        : '',
      '',
      `<i>${new Date().toUTCString()}</i>`,
    ].filter(l => l !== '').join('\n');
    await sendMessage(msg.chat.id, text);
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Health check error.');
  }
}

async function handlePositions(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.getPositions) {
      return sendMessage(msg.chat.id, '📭 Position data unavailable.');
    }
    const positions = await handlers.getPositions();
    if (!positions || positions.length === 0) {
      return sendMessage(msg.chat.id, '📭 No open positions.');
    }
    const lines = ['📈 <b>Open Positions</b>', ''];
    for (const p of positions.slice(0, 10)) {
      const pnlStr = p.unrealizedPnl !== undefined
        ? ` | PnL: <code>${p.unrealizedPnl >= 0 ? '+' : ''}${(p.unrealizedPnl).toFixed(4)}</code>`
        : '';
      lines.push(`• <b>${p.symbol}</b> ${p.direction} @ <code>${p.entry}</code>${pnlStr}`);
    }
    if (positions.length > 10) lines.push(`<i>... and ${positions.length - 10} more</i>`);
    await sendMessage(msg.chat.id, lines.join('\n'));
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Error fetching positions.');
  }
}

async function handleOpportunities(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.getOpportunities) {
      return sendMessage(msg.chat.id, '📭 Opportunity data unavailable.');
    }
    const opps = await handlers.getOpportunities();
    if (!opps || opps.length === 0) {
      return sendMessage(msg.chat.id, '🔍 No qualified opportunities found yet.');
    }
    const lines = ['🎯 <b>Top Opportunities</b>', ''];
    for (const o of opps.slice(0, 8)) {
      lines.push(`• <b>${o.symbol}</b> ${o.direction || ''} | Score: <b>${o.score}</b> | R:R: <code>${o.riskReward}</code>`);
    }
    if (opps.length > 8) lines.push(`<i>... and ${opps.length - 8} more</i>`);
    await sendMessage(msg.chat.id, lines.join('\n'));
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Error fetching opportunities.');
  }
}

async function handleRisk(msg) {
  try {
    const handlers = _robotHandlers;
    const riskData = handlers && handlers.getRiskStatus
      ? await handlers.getRiskStatus()
      : null;

    if (!riskData) {
      return sendMessage(msg.chat.id, '⚠️ Risk data unavailable.');
    }

    const text = [
      '🛡️ <b>Risk Engine Status</b>',
      '',
      `Level: <b>${riskData.level || '?'}</b>`,
      `Daily P&amp;L: <code>${riskData.dailyPnL !== undefined ? riskData.dailyPnL.toFixed(4) : '?'}</code>`,
      `Daily Loss Used: <b>${riskData.currentDailyLossPct !== undefined ? riskData.currentDailyLossPct.toFixed(1) + '%' : '?'}</b>`,
      `Kill Switch: <b>${riskData.circuitBreakers?.killSwitch ? '🔴 ACTIVE' : '🟢 OFF'}</b>`,
      `Consecutive Losses: <b>${riskData.consecutiveLosses || 0}/${riskData.maxConsecutiveLosses || 5}</b>`,
    ].join('\n');
    await sendMessage(msg.chat.id, text);
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Error fetching risk status.');
  }
}

async function handleSummary(msg) {
  try {
    const capital = config.accountBalance;
    const riskPct = ((config.riskPerTrade || 0.005) * 100).toFixed(1);
    const riskAmt = (capital * (config.riskPerTrade || 0.005)).toFixed(2);
    const dailyLimitPct = ((config.maxDailyLoss || 0.03) * 100).toFixed(0);
    const dailyLimitAmt = (capital * (config.maxDailyLoss || 0.03)).toFixed(2);

    const handlers = _robotHandlers;
    const status = handlers && handlers.getStatus ? await handlers.getStatus() : {};

    const text = [
      '📋 <b>Daily Summary</b>',
      '',
      `Mode: <b>PAPER</b> | Capital: <b>$${capital}</b>`,
      `Risk/Trade: <b>${riskPct}% ($${riskAmt})</b>`,
      `Daily Limit: <b>${dailyLimitPct}% ($${dailyLimitAmt})</b>`,
      '',
      `Open Positions: <b>${status.openPositions || 0}</b>`,
      `Closed Today: <b>${status.closedToday || 0}</b>`,
      `Daily P&amp;L: <b>${status.dailyPnL !== undefined ? (status.dailyPnL >= 0 ? '+' : '') + status.dailyPnL.toFixed(4) : 'N/A'}</b>`,
      '',
      `<i>${new Date().toUTCString()}</i>`,
    ].join('\n');
    await sendMessage(msg.chat.id, text);
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Error generating summary.');
  }
}

async function handleJournal(msg) {
  try {
    const handlers = _robotHandlers;
    const trades = handlers && handlers.getRecentTrades
      ? await handlers.getRecentTrades(5)
      : [];

    if (!trades || trades.length === 0) {
      return sendMessage(msg.chat.id, '📓 No recent closed trades.');
    }

    const lines = ['📓 <b>Recent Trades</b>', ''];
    for (const t of trades) {
      const icon = t.outcome === 'WIN' ? '✅' : '❌';
      const pnl = t.pnl !== undefined ? (t.pnl >= 0 ? '+' : '') + t.pnl.toFixed(4) : '?';
      lines.push(`${icon} <b>${t.symbol}</b> ${t.direction} | <code>${pnl}</code>`);
    }
    await sendMessage(msg.chat.id, lines.join('\n'));
  } catch (err) {
    await sendMessage(msg.chat.id, '⚠️ Error fetching journal.');
  }
}

// ─── Admin Command Handlers ───────────────────────────────────────────────────

async function handleAdminScan(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.triggerScan) {
      return sendMessage(msg.chat.id, '⚠️ Scanner not connected.');
    }
    await handlers.triggerScan();
    await sendMessage(msg.chat.id, '🔍 Scan triggered successfully.');
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Scan error: ${err.message}`);
  }
}

async function handleAdminPause(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.pauseScanner) {
      return sendMessage(msg.chat.id, '⚠️ Scanner not connected.');
    }
    await handlers.pauseScanner();
    await sendMessage(msg.chat.id, '⏸️ Scanner paused.');
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Pause error: ${err.message}`);
  }
}

async function handleAdminResume(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.resumeScanner) {
      return sendMessage(msg.chat.id, '⚠️ Scanner not connected.');
    }
    await handlers.resumeScanner();
    await sendMessage(msg.chat.id, '▶️ Scanner resumed.');
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Resume error: ${err.message}`);
  }
}

async function handleAdminStop(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.stopScanner) {
      return sendMessage(msg.chat.id, '⚠️ Scanner not connected.');
    }
    await handlers.stopScanner();
    await sendMessage(msg.chat.id, '🛑 Scanner stopped.');
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Stop error: ${err.message}`);
  }
}

async function handleAdminEmergency(msg) {
  _pendingConfirm.set(String(msg.chat.id), Date.now());
  await sendMessage(msg.chat.id,
    '🆘 <b>Emergency Stop requested.</b>\n\n' +
    'This will:\n' +
    '• Halt all new trade execution\n' +
    '• Activate kill switch\n' +
    '• Close no existing positions automatically\n\n' +
    'Type /confirm within 30 seconds to proceed.');
}

async function handleAdminConfirm(msg) {
  const chatId = String(msg.chat.id);
  const pending = _pendingConfirm.get(chatId);
  if (!pending || Date.now() - pending > 30000) {
    _pendingConfirm.delete(chatId);
    return sendMessage(msg.chat.id, '⚠️ No pending action to confirm, or confirmation timed out.');
  }
  _pendingConfirm.delete(chatId);

  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.emergencyStop) {
      return sendMessage(msg.chat.id, '⚠️ Emergency stop handler not connected.');
    }
    await handlers.emergencyStop();
    await sendMessage(msg.chat.id, '🆘 <b>EMERGENCY STOP ACTIVATED.</b>\nNo new trades will be opened.');
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Emergency stop error: ${err.message}`);
  }
}

async function handleAdminClose(msg, args) {
  const tradeId = args[0];
  if (!tradeId) {
    return sendMessage(msg.chat.id, '⚠️ Usage: /close &lt;trade-id&gt;');
  }
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.closeTrade) {
      return sendMessage(msg.chat.id, '⚠️ Close handler not connected.');
    }
    const result = await handlers.closeTrade(tradeId);
    await sendMessage(msg.chat.id, result
      ? `✅ Position <code>${tradeId}</code> closed.`
      : `⚠️ Could not close position <code>${tradeId}</code>.`);
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Close error: ${err.message}`);
  }
}

async function handleAdminCloseAll(msg) {
  try {
    const handlers = _robotHandlers;
    if (!handlers || !handlers.closeAllTrades) {
      return sendMessage(msg.chat.id, '⚠️ Close-all handler not connected.');
    }
    const count = await handlers.closeAllTrades();
    await sendMessage(msg.chat.id, `✅ Closed <b>${count}</b> position(s).`);
  } catch (err) {
    await sendMessage(msg.chat.id, `⚠️ Close-all error: ${err.message}`);
  }
}

// ─── Command Dispatcher ───────────────────────────────────────────────────────

async function dispatchCommand(msg) {
  const text = (msg.text || '').trim();
  if (!text.startsWith('/')) return;

  // Strip bot username suffix (e.g. /start@MultiStratos1_bot)
  const [rawCmd, ...args] = text.split(/\s+/);
  const cmd = rawCmd.split('@')[0].toLowerCase();
  const chatId = msg.chat.id;

  logger.info(`Telegram command: ${cmd} from chat ${chatId}`);

  // Public commands
  switch (cmd) {
    case '/start':      return handleStart(msg);
    case '/help':       return handleHelp(msg);
    case '/status':     return handleStatus(msg);
    case '/health':     return handleHealth(msg);
    case '/positions':
    case '/pos':        return handlePositions(msg);
    case '/opportunities':
    case '/opps':       return handleOpportunities(msg);
    case '/risk':       return handleRisk(msg);
    case '/summary':    return handleSummary(msg);
    case '/journal':    return handleJournal(msg);
  }

  // Admin commands
  if (!isAdmin(chatId)) {
    return sendMessage(chatId, '🔒 Unknown command. Use /help for available commands.');
  }

  switch (cmd) {
    case '/scan':       return handleAdminScan(msg);
    case '/pause':      return handleAdminPause(msg);
    case '/resume':     return handleAdminResume(msg);
    case '/stop':       return handleAdminStop(msg);
    case '/emergency':  return handleAdminEmergency(msg);
    case '/confirm':    return handleAdminConfirm(msg);
    case '/close':      return handleAdminClose(msg, args);
    case '/closeall':   return handleAdminCloseAll(msg);
    default:
      return sendMessage(chatId, '⚠️ Unknown admin command. Use /help.');
  }
}

// ─── Polling Loop ─────────────────────────────────────────────────────────────

async function poll() {
  let errorCount = 0;
  const MAX_CONSECUTIVE_ERRORS = 10;

  while (_running) {
    try {
      const updates = await getUpdates(_offset, POLL_TIMEOUT);

      for (const update of updates) {
        _offset = update.update_id + 1;
        if (update.message) {
          dispatchCommand(update.message).catch(err => {
            logger.error(`Telegram dispatch error: ${err.message}`);
          });
        }
      }

      errorCount = 0;
    } catch (err) {
      if (!_running) break;
      errorCount++;
      logger.warn(`Telegram poll error (${errorCount}/${MAX_CONSECUTIVE_ERRORS}): ${err.message}`);
      if (errorCount >= MAX_CONSECUTIVE_ERRORS) {
        logger.error('Telegram bot: too many consecutive errors, pausing for 60s');
        await new Promise(r => setTimeout(r, 60000));
        errorCount = 0;
      } else {
        await new Promise(r => setTimeout(r, RETRY_DELAY_MS));
      }
    }
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Start the Telegram command bot.
 *
 * @param {object} handlers - Robot interface object with methods:
 *   getStatus(), getHealth(), getPositions(), getOpportunities(),
 *   getRiskStatus(), getRecentTrades(n), getStatus(),
 *   triggerScan(), pauseScanner(), resumeScanner(), stopScanner(),
 *   emergencyStop(), closeTrade(id), closeAllTrades()
 */
function start(handlers = {}) {
  if (_running) {
    logger.warn('Telegram bot already running');
    return;
  }

  if (!config.telegram.enabled) {
    logger.info('Telegram bot disabled (TELEGRAM_ENABLED != true)');
    return;
  }

  if (!config.telegram.botToken) {
    logger.warn('Telegram bot: TELEGRAM_BOT_TOKEN not set — bot will not start');
    return;
  }

  _robotHandlers = handlers;
  _running = true;

  logger.info('Telegram command bot starting (polling mode)...');

  // Start polling in background (do not await)
  poll().catch(err => {
    logger.error(`Telegram bot fatal error: ${err.message}`);
    _running = false;
  });
}

/**
 * Stop the Telegram command bot gracefully.
 */
function stop() {
  _running = false;
  if (_abortController) {
    _abortController.abort();
    _abortController = null;
  }
  logger.info('Telegram command bot stopped.');
}

/**
 * Send an outbound alert message to the configured main chat.
 * Re-exports from the existing telegram.js alert system.
 * The token is NEVER exposed in logs.
 */
async function broadcast(text) {
  const chatId = config.telegram.chatId;
  if (!chatId || !config.telegram.botToken) return false;
  const result = await sendMessage(chatId, text);
  return !!result;
}

/**
 * Check if the bot is currently running.
 */
function isRunning() {
  return _running;
}

module.exports = {
  start,
  stop,
  broadcast,
  isRunning,
};
