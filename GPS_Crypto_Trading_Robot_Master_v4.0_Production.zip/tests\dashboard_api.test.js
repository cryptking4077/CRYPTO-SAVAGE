'use strict';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const server = require('../dashboard/server');

describe('Dashboard Server & API Endpoints', () => {
  let baseUrl;

  before(() => {
    return new Promise((resolve) => {
      server.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://127.0.0.1:${port}`;
        resolve();
      });
    });
  });

  after(() => {
    return new Promise((resolve) => {
      server.close(resolve);
    });
  });

  it('serves dashboard index.html on GET /', async () => {
    const res = await fetch(`${baseUrl}/`);
    assert.equal(res.status, 200);
    const text = await res.text();
    assert.ok(text.includes('COMMAND CENTER'));
    assert.ok(text.includes('Candlestick Chart'));
  });

  it('GET /api/dashboard/summary returns portfolio & status metrics', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/summary`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.status);
    assert.ok(data.operationalState);
    assert.ok(data.portfolio);
    assert.equal(typeof data.portfolio.startingBalance, 'number');
    assert.equal(typeof data.portfolio.currentEquity, 'number');
    assert.equal(typeof data.portfolio.portfolioExposurePct, 'number');
  });

  it('GET /api/dashboard/positions returns open positions with enriched fields', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/positions`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(Array.isArray(data.positions));
    assert.equal(typeof data.count, 'number');
    assert.equal(typeof data.leverage, 'number');
  });

  it('GET /api/dashboard/scanner returns signal lists with counters', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/scanner`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(typeof data.totalScanned, 'number');
    assert.equal(typeof data.qualifiedCount, 'number');
    assert.ok(Array.isArray(data.signals));
  });

  it('GET /api/dashboard/performance returns comprehensive analytics', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/performance`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(typeof data.totalTrades, 'number');
    assert.equal(typeof data.winRate, 'number');
    assert.ok(Array.isArray(data.equityCurve));
    assert.ok(Array.isArray(data.rDistribution));
  });

  it('GET /api/dashboard/risk returns real risk status and cluster exposures', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/risk`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.level);
    assert.ok(data.badge);
    assert.ok(data.reason);
    assert.ok(Array.isArray(data.clusterExposures));
  });

  it('GET /api/dashboard/strategy returns GPS config and condition weights', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/strategy`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.strategy);
    assert.equal(data.strategy.id, 'gps_v1');
    assert.ok(Array.isArray(data.strategy.conditions));
    assert.equal(data.strategy.conditions.length, 10);
  });

  it('GET /api/dashboard/system returns complete subsystem health matrix', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/system`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.database);
    assert.ok(data.scanner);
    assert.ok(data.paperEngine);
    assert.ok(data.liveEngine);
  });

  it('retains backward compatibility on GET /api/status', async () => {
    const res = await fetch(`${baseUrl}/api/status`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.status);
    assert.ok(data.performance);
  });

  it('handles emergency stop and reset control endpoints', async () => {
    const stopRes = await fetch(`${baseUrl}/api/control/emergency-stop`, { method: 'POST' });
    assert.equal(stopRes.status, 200);
    const stopData = await stopRes.json();
    assert.equal(stopData.ok, true);

    const resetRes = await fetch(`${baseUrl}/api/control/emergency-reset`, { method: 'POST' });
    assert.equal(resetRes.status, 200);
    const resetData = await resetRes.json();
    assert.equal(resetData.ok, true);
  });

  it('GET /api/learning/autopsies returns trade diagnostic autopsies', async () => {
    const res = await fetch(`${baseUrl}/api/learning/autopsies`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(Array.isArray(data.autopsies));
    assert.equal(typeof data.count, 'number');
  });

  it('GET /api/learning/similarity returns setup similarity context', async () => {
    const res = await fetch(`${baseUrl}/api/learning/similarity?symbol=SOLUSDT&strategy=gps_v1&direction=LONG`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(data.recommendation);
    assert.equal(typeof data.sampleSize, 'number');
  });

  it('GET /api/events/recent returns recent event bus stream', async () => {
    const res = await fetch(`${baseUrl}/api/events/recent`);
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.ok(Array.isArray(data.events));
    assert.equal(typeof data.count, 'number');
  });
});

