'use strict';

const config = require('./config');
const logger = require('./utils/logger');
const { discoverMarkets, getReferenceMarkets } = require('./market/universe');
const dataFeed = require('./market/dataFeed');
const { createDefaultRegistry } = require('./strategy/registry');
const { scoreSignal } = require('./scoring/engine');
const RiskEngine = require('./risk/engine');
const PaperEngine = require('./paper/engine');
const LiveExecution = require('./execution/live');
const ReconciliationEngine = require('./execution/reconciliation');
const Watchdog = require('./monitoring/watchdog');
const { defaultNotifier } = require('./notifications/index');
const journal = require('./journal/store');

/**
 * GPS Trading Robot — Production Main Process
 *
 * Runs autonomously as a headless daemon.
 * PAPER mode by default. LIVE mode triple-gated and locked.
 */
class TradingRobot {
  constructor() {
    this.running = false;
    this.scanCount = 0;
    this.lastSignals = [];
    this.markets = [];

    this.strategyRegistry = createDefaultRegistry();
    this.riskEngine = new RiskEngine();
    this.paperEngine = new PaperEngine({}, this.riskEngine.cfg);

    this.reconciliation = new ReconciliationEngine({ riskEngine: this.riskEngine });
    this.watchdog = new Watchdog({ riskEngine: this.riskEngine });
    this.liveExecution = new LiveExecution({
      riskEngine: this.riskEngine,
      reconciliationEngine: this.reconciliation,
    });
    this.notifier = defaultNotifier;

    // Concurrency
    this.concurrency = config.scanConcurrency || 8;

    // Timers
    this._scanTimer = null;
    this._startTime = null;
  }

  async start() {
    if (this.running) {
      logger.warn('Robot already running');
      return;
    }

    this._startTime = Date.now();
    this.running = true;

    logger.info('════════════════════════════════════════════════════');
    logger.info('  GPS TRADING ROBOT — PRODUCTION DAEMON STARTING   ');
    logger.info(`  OPERATIONAL MODE: ${config.mode}`);
    logger.info(`  LIVE TRADING ENABLED: ${config.liveEnabled ? 'YES' : 'NO (LOCKED)'}`);
    logger.info(`  SCAN CONCURRENCY: ${this.concurrency}`);
    logger.info(`  STRATEGIES: ${this.strategyRegistry.getEnabled().map(s => `${s.name} v${s.version}`).join(', ')}`);
    logger.info('════════════════════════════════════════════════════');

    // Restore or initialize persistent state
    journal.setState('robot_running', true);
    journal.setState('robot_mode', config.mode);
    journal.setState('robot_start', this._startTime);

    // Initial Watchdog Health Check
    await this.watchdog.checkHealth();

    // Initial Market Discovery
    await this._refreshMarkets();

    // Schedule scan loop
    this._scheduleScan();

    // Process termination signals
    process.on('SIGINT',  () => this.stop('SIGINT'));
    process.on('SIGTERM', () => this.stop('SIGTERM'));
  }

  async stop(reason = 'MANUAL') {
    if (!this.running) return;
    this.running = false;

    if (this._scanTimer) clearTimeout(this._scanTimer);

    logger.info(`Robot stopping: ${reason}`);
    journal.setState('robot_running', false);

    await this.notifier.dispatch({
      type: 'INFO',
      severity: 'WARNING',
      title: 'ROBOT STOPPED',
      message: `Daemon stopped. Reason: ${reason}`,
    }).catch(() => {});
  }

  async emergencyStop(reason = 'Manual Trigger') {
    this.riskEngine.emergencyStop();
    journal.setState('emergency_stop', true);
    logger.risk(`⛔ EMERGENCY STOP ACTIVATED: ${reason}`);
    await this.notifier.notifyEmergencyStop(reason).catch(() => {});
  }

  _scheduleScan() {
    if (!this.running) return;
    const interval = config.scanIntervalSeconds * 1000;
    this._scanTimer = setTimeout(async () => {
      await this._runScan();
      this._scheduleScan();
    }, interval);
  }

  async _runScan() {
    if (!this.running) return;
    this.scanCount++;

    logger.scan(`Scan #${this.scanCount} starting — ${this.markets.length} markets (concurrency: ${this.concurrency})`);

    // Periodic tasks:
    // 1. Refresh market list every 15 scans
    if (this.scanCount % 15 === 0) {
      await this._refreshMarkets();
    }

    // 2. Run Watchdog Health Check every 5 scans
    if (this.scanCount % 5 === 0) {
      const health = await this.watchdog.checkHealth();
      if (health.status !== 'HEALTHY') {
        logger.warn(`Watchdog report: ${health.status} issues: ${health.issues.join(', ')}`);
      }
    }

    // 3. Run Reconciliation if in LIVE mode
    if (config.isLive) {
      // In a live system, query Bybit positions & reconcile with journal
      const localOpen = journal.getRecentSignals(20);
      await this.reconciliation.reconcile(localOpen, [], [], []);
    }

    const newSignals = [];

    // Controlled concurrent batch evaluation
    for (let i = 0; i < this.markets.length; i += this.concurrency) {
      if (!this.running) break;
      const batch = this.markets.slice(i, i + this.concurrency);

      await Promise.all(batch.map(async (market) => {
        try {
          const result = await this.paperEngine.evaluateMarket(market.symbol);

          if (result.action === 'OPENED' && result.signal) {
            newSignals.push(result.signal);
            journal.saveSignal({
              ...result.signal,
              mode: config.mode,
              decision: 'TRADE',
            });
            journal.savePaperTrade(result.trade);

            // Dispatch multi-channel notification
            await this.notifier.notifySignal(result.signal, config.mode);
            await this.notifier.notifyTradeOpened(result.trade);
          }

          // Update open paper trades against current price
          const currentPrice = market.lastPrice;
          if (currentPrice) {
            const closed = this.paperEngine.updateTrades(market.symbol, currentPrice);
            for (const t of closed) {
              journal.savePaperTrade(t);
              await this.notifier.notifyTradeClosed(t);
            }
          }
        } catch (err) {
          logger.error(`Error scanning ${market.symbol}: ${err.message}`);
        }
      }));
    }

    this.lastSignals = newSignals;
    this._updateState();
    logger.scan(`Scan #${this.scanCount} completed. Qualified: ${newSignals.length}`);
  }

  async _refreshMarkets() {
    try {
      this.markets = await discoverMarkets(true);
      journal.setState('market_count', this.markets.length);
      logger.info(`Markets refreshed: ${this.markets.length} eligible crypto markets`);
    } catch (err) {
      logger.error(`Market discovery failed: ${err.message}`);
    }
  }

  _updateState() {
    const perf = this.paperEngine.getPerformance();
    journal.setState('performance', perf);
    journal.setState('scan_count', this.scanCount);
    journal.setState('last_scan', Date.now());
  }

  getStatus() {
    const perf = this.paperEngine.getPerformance();
    const watchdogStatus = this.watchdog.getStatus();
    const reconStatus = this.reconciliation.getStatus();
    const opState = this.liveExecution.getOperationalState();

    return {
      running: this.running,
      mode: config.mode,
      operationalState: opState,
      scanCount: this.scanCount,
      marketCount: this.markets.length,
      uptime: this._startTime ? Math.floor((Date.now() - this._startTime) / 1000) : 0,
      strategies: this.strategyRegistry.status(),
      riskStatus: this.riskEngine.getStatus(),
      watchdog: watchdogStatus,
      reconciliation: reconStatus,
      performance: perf,
      lastSignals: this.lastSignals.slice(0, 10),
    };
  }
}

// ── Entry Point ────────────────────────────────────────────────────────────

if (require.main === module) {
  const robot = new TradingRobot();

  const args = process.argv.slice(2);
  const modeArg = args.find(a => a.startsWith('--mode='));
  if (modeArg) {
    const m = modeArg.split('=')[1].toUpperCase();
    process.env.TRADING_MODE = m;
  }

  robot.start().catch(err => {
    logger.error(`Robot startup failed: ${err.message}`);
    process.exit(1);
  });
}

module.exports = TradingRobot;
