'use strict';

const config = require('../config');
const logger = require('../utils/logger');

const sentHashes = new Map(); // deduplication: hash → timestamp
const COOLDOWN_MS = 5 * 60 * 1000; // 5 min per same message

function hash(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) {
    h = (Math.imul(31, h) + text.charCodeAt(i)) | 0;
  }
  return h.toString();
}

async function send(text, force = false) {
  if (!config.telegram.enabled || !config.telegram.botToken || !config.telegram.chatId) {
    logger.alert(`[TELEGRAM NOT CONFIGURED] ${text.split('\n')[0]}`);
    return false;
  }

  const key = hash(text);
  const now = Date.now();
  if (!force && sentHashes.has(key) && (now - sentHashes.get(key)) < COOLDOWN_MS) {
    logger.alert('Telegram: duplicate suppressed');
    return false;
  }
  sentHashes.set(key, now);

  try {
    const url = `https://api.telegram.org/bot${config.telegram.botToken}/sendMessage`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: config.telegram.chatId,
        text,
        parse_mode: 'HTML',
      }),
      signal: AbortSignal.timeout(10000),
    });

    const data = await res.json();
    if (data.ok) {
      logger.alert('Telegram message sent successfully');
      return true;
    } else {
      logger.error(`Telegram API error: ${data.description}`);
      return false;
    }
  } catch (err) {
    logger.error(`Telegram send failed: ${err.message}`);
    return false;
  }
}

// ── Alert formatters ───────────────────────────────────────────────────────

function signalAlert(signal, mode) {
  const icon = signal.direction === 'LONG' ? '📈' : '📉';
  return [
    `🚨 <b>${signal.strategyName} SIGNAL</b>`,
    ``,
    `<b>${signal.symbol}</b> — ${icon} ${signal.direction}`,
    ``,
    `Score: <b>${signal.score}/100</b>`,
    `R:R: <b>${signal.riskReward}</b>`,
    ``,
    `Entry:  <code>${signal.entry}</code>`,
    `SL:     <code>${signal.stopLoss}</code>`,
    `TP:     <code>${signal.takeProfit}</code>`,
    ``,
    `Mode: <b>${mode || 'PAPER'}</b>`,
    `Strategy: ${signal.strategyName} v${signal.strategyVersion}`,
  ].join('\n');
}

function tradeOpened(trade) {
  return [
    `✅ <b>TRADE OPENED</b> [${trade.mode}]`,
    ``,
    `<b>${trade.symbol}</b> ${trade.direction}`,
    `Entry: <code>${trade.entry}</code>`,
    `SL:    <code>${trade.stopLoss}</code>`,
    `TP:    <code>${trade.takeProfit}</code>`,
    `Size:  ${trade.positionSize}`,
  ].join('\n');
}

function tradeClosed(trade) {
  const icon = trade.outcome === 'WIN' ? '✅' : '❌';
  return [
    `${icon} <b>TRADE CLOSED</b> [${trade.mode}]`,
    ``,
    `<b>${trade.symbol}</b> ${trade.direction}`,
    `Result: <b>${trade.outcome}</b>`,
    `P&L: <code>${trade.pnl >= 0 ? '+' : ''}${trade.pnl}</code>`,
    `Exit: <code>${trade.exitPrice}</code>`,
  ].join('\n');
}

function errorAlert(message) {
  return `⚠️ <b>ERROR</b>\n${message}`;
}

function robotStopped() {
  return `🛑 <b>ROBOT STOPPED</b>\n${new Date().toISOString()}`;
}

function emergencyStop() {
  return `🆘 <b>EMERGENCY STOP ACTIVATED</b>\nNo new trades will be opened.`;
}

function riskLimitAlert(reason) {
  return `⚠️ <b>RISK LIMIT TRIGGERED</b>\n${reason}`;
}

module.exports = {
  send,
  signalAlert,
  tradeOpened,
  tradeClosed,
  errorAlert,
  robotStopped,
  emergencyStop,
  riskLimitAlert,
};
