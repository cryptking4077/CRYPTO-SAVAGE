'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const RiskEngine = require('../src/risk/engine');
const { getAssetCluster } = require('../src/risk/engine');

describe('Correlation-Aware Risk Engine', () => {
  test('correctly maps symbols to asset clusters', () => {
    assert.equal(getAssetCluster('SOLUSDT'), 'LAYER_1');
    assert.equal(getAssetCluster('BTCUSDT'), 'LAYER_1');
    assert.equal(getAssetCluster('DOGEUSDT'), 'MEME');
    assert.equal(getAssetCluster('1000PEPEUSDT'), 'MEME');
    assert.equal(getAssetCluster('UNIUSDT'), 'DEFI');
    assert.equal(getAssetCluster('AAVEUSDT'), 'DEFI');
    assert.equal(getAssetCluster('TAOUSDT'), 'AI_DEPIN');
    assert.equal(getAssetCluster('OPUSDT'), 'INFRA_L2');
    assert.equal(getAssetCluster('XYZUSDT'), 'ALT_GENERAL');
  });

  test('enforces maximum correlated cluster exposure limit', () => {
    const risk = new RiskEngine({
      accountBalance: 10000,
      riskPerTrade: 0.01,
      maxPortfolioExposure: 0.40,
      maxCorrelatedExposure: 0.20, // 20% max per cluster = $2000
    });

    // Existing positions in MEME cluster totaling $1800
    const openPositions = [
      { symbol: 'DOGEUSDT', entry: 0.10, positionSize: 10000 }, // $1000
      { symbol: 'SHIBUSDT', entry: 0.00002, positionSize: 40000000 }, // $800
    ];

    // Incoming signal in same MEME cluster with size that pushes over $2000
    const signalMeme = {
      symbol: '1000PEPEUSDT',
      direction: 'LONG',
      entry: 0.005,
      stopLoss: 0.004, // $0.001 risk -> $100 / $0.001 = 100,000 units -> $500 value
      takeProfit: 0.007,
      riskReward: 2.0,
    };

    const res = risk.check(signalMeme, openPositions);
    assert.equal(res.approved, false);
    assert.ok(res.reason.includes('MAX_CORRELATED_EXPOSURE: MEME'));

    // Incoming signal in different cluster (e.g. DEFI) should pass
    const signalDefi = {
      symbol: 'UNIUSDT',
      direction: 'LONG',
      entry: 10,
      stopLoss: 9, // $1 risk -> 100 units -> $1000 value (10% < 20%)
      takeProfit: 13,
      riskReward: 3.0,
    };

    const resDefi = risk.check(signalDefi, openPositions);
    assert.equal(resDefi.approved, true);
    assert.equal(resDefi.cluster, 'DEFI');
  });

  test('blocks trades on regime conflict', () => {
    const risk = new RiskEngine({
      accountBalance: 10000,
      regimeFilterEnabled: true,
    });

    const signalLong = {
      symbol: 'SOLUSDT',
      direction: 'LONG',
      entry: 100,
      stopLoss: 95,
      takeProfit: 115,
      riskReward: 3.0,
      regime: { regime: 'TRENDING_DOWN', confidence: 85 },
    };

    const res = risk.check(signalLong, []);
    assert.equal(res.approved, false);
    assert.ok(res.reason.includes('REGIME_CONFLICT: Cannot LONG in TRENDING_DOWN'));
  });
});
