'use strict';

const indicators = require('../../indicators');
const { detectRegime } = require('../../market/regime');

const PASS = 'PASS';
const FAIL = 'FAIL';
const NA   = 'NOT_AVAILABLE';

const DEFAULT_CONFIG = {
  bbPeriod: 20,
  bbMultiplier: 2.0,
  rsiPeriod: 14,
  rsiOverbought: 65,
  rsiOversold: 35,
  minScore: 80,
  minRR: 1.8,
  weights: {
    regimeAlignment: 25,
    bollingerExtreme: 25,
    rsiExtreme: 20,
    reversalTrigger: 20,
    volumeConfirmation: 10,
  },
};

class MeanReversionStrategy {
  constructor(options = {}) {
    this.id = 'mean_reversion_v1';
    this.name = options.name || 'Mean Reversion';
    this.version = '1.0.0';
    this.enabled = options.enabled !== undefined ? options.enabled : true;
    this.cfg = { ...DEFAULT_CONFIG, ...options };
  }

  evaluate(marketData) {
    const { symbol, candles4H = [], candles1H = [], candles15M = [], meta = {} } = marketData;

    if (!this.enabled) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'STRATEGY_DISABLED',
        timestamp: Date.now(),
      };
    }

    const regime = detectRegime(candles4H, candles1H, candles15M);
    const conditions = {};
    const details = {};

    // 1. Regime Alignment (RANGE, COMPRESSION, or LOW_VOLATILITY)
    const isRangeRegime = ['RANGE', 'COMPRESSION', 'LOW_VOLATILITY'].includes(regime.canonicalRegime || regime.regime);
    conditions.regimeAlignment = isRangeRegime ? PASS : FAIL;
    details.regime = regime.summary;

    if (candles1H.length < 30) {
      return {
        strategyId: this.id,
        strategyName: this.name,
        strategyVersion: this.version,
        symbol,
        direction: null,
        score: 0,
        qualified: false,
        criticalFail: 'INSUFFICIENT_1H_CANDLES',
        regime,
        timestamp: Date.now(),
      };
    }

    // 2. 1H Bollinger Bands
    const bb = indicators.bollingerBands(candles1H, this.cfg.bbPeriod, this.cfg.bbMultiplier);
    const last1H = candles1H[candles1H.length - 1];
    const prev1H = candles1H[candles1H.length - 2];
    const upper1H = bb.upper[bb.upper.length - 1];
    const lower1H = bb.lower[bb.lower.length - 1];
    const mid1H = bb.middle[bb.middle.length - 1];

    let direction = null;
    let bbExtreme = false;

    if (prev1H.low <= lower1H || last1H.low <= lower1H) {
      direction = 'LONG';
      bbExtreme = true;
    } else if (prev1H.high >= upper1H || last1H.high >= upper1H) {
      direction = 'SHORT';
      bbExtreme = true;
    }
    conditions.bollingerExtreme = bbExtreme ? PASS : FAIL;
    details.bollinger = `Price: ${last1H.close.toFixed(4)}, Lower: ${lower1H?.toFixed(4)}, Upper: ${upper1H?.toFixed(4)}`;

    // 3. 1H RSI Extremes
    const rsiValues = indicators.rsi(candles1H, this.cfg.rsiPeriod);
    const lastRsi = rsiValues[rsiValues.length - 1];
    let rsiExtreme = false;

    if (direction === 'LONG' && lastRsi <= this.cfg.rsiOversold + 5) {
      rsiExtreme = true;
    } else if (direction === 'SHORT' && lastRsi >= this.cfg.rsiOverbought - 5) {
      rsiExtreme = true;
    }
    conditions.rsiExtreme = isNaN(lastRsi) ? NA : (rsiExtreme ? PASS : FAIL);
    details.rsi = `RSI: ${isNaN(lastRsi) ? 'N/A' : lastRsi.toFixed(1)}`;

    // 4. 15M Reversal Trigger
    let reversalTrigger = false;
    if (candles15M && candles15M.length >= 2) {
      const last15M = candles15M[candles15M.length - 1];
      const prev15M = candles15M[candles15M.length - 2];
      if (direction === 'LONG') {
        // Bullish close or reclaim
        reversalTrigger = last15M.close > last15M.open || last15M.close > prev15M.close;
      } else if (direction === 'SHORT') {
        // Bearish close or reclaim
        reversalTrigger = last15M.close < last15M.open || last15M.close < prev15M.close;
      }
    }
    conditions.reversalTrigger = reversalTrigger ? PASS : FAIL;

    // 5. Volume Confirmation
    const volMA = indicators.volumeMA(candles1H, 20);
    const lastVolMA = volMA[volMA.length - 1];
    const volSurge = !isNaN(lastVolMA) && lastVolMA > 0 && (last1H.volume >= lastVolMA * 0.9);
    conditions.volumeConfirmation = volSurge ? PASS : FAIL;

    // Calculate score
    let totalWeight = 0;
    let earnedWeight = 0;
    for (const [key, res] of Object.entries(conditions)) {
      const w = this.cfg.weights[key] || 0;
      if (res === NA) continue;
      totalWeight += w;
      if (res === PASS) earnedWeight += w;
    }
    const score = totalWeight > 0 ? Math.round((earnedWeight / totalWeight) * 100) : 0;

    // Trade Levels (SL outside sweep extreme, TP at mid band or 2R)
    const entry = last1H.close;
    let stopLoss, takeProfit;
    const atrVals = indicators.atr(candles1H, 14);
    const atrNow = atrVals[atrVals.length - 1] || (entry * 0.01);

    if (direction === 'LONG') {
      const recentLow = Math.min(...candles1H.slice(-5).map(c => c.low));
      stopLoss = Math.min(recentLow - atrNow * 0.2, entry - atrNow * 1.2);
      const risk = entry - stopLoss;
      takeProfit = Math.max(mid1H, entry + risk * this.cfg.minRR);
    } else if (direction === 'SHORT') {
      const recentHigh = Math.max(...candles1H.slice(-5).map(c => c.high));
      stopLoss = Math.max(recentHigh + atrNow * 0.2, entry + atrNow * 1.2);
      const risk = stopLoss - entry;
      takeProfit = Math.min(mid1H, entry - risk * this.cfg.minRR);
    } else {
      stopLoss = entry;
      takeProfit = entry;
    }

    const riskDist = Math.abs(entry - stopLoss);
    const rewardDist = Math.abs(takeProfit - entry);
    const riskReward = riskDist > 0 ? parseFloat((rewardDist / riskDist).toFixed(2)) : 0;

    const criticalFail = !isRangeRegime ? 'REGIME_MISMATCH' : (direction === null ? 'NO_DIRECTION' : null);
    const qualified = !criticalFail && score >= this.cfg.minScore && riskReward >= this.cfg.minRR;

    return {
      strategyId: this.id,
      strategyName: this.name,
      strategyVersion: this.version,
      symbol,
      direction,
      score,
      qualified,
      criticalFail,
      regime,
      entry: parseFloat(entry.toFixed(6)),
      stopLoss: parseFloat(stopLoss.toFixed(6)),
      takeProfit: parseFloat(takeProfit.toFixed(6)),
      riskReward,
      conditions,
      details,
      timestamp: Date.now(),
      configuration: this.cfg,
    };
  }
}

module.exports = MeanReversionStrategy;
