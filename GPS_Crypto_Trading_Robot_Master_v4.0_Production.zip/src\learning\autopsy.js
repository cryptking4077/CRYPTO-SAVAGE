'use strict';

const journal = require('../journal/store');
const { eventBus } = require('../events/bus');
const logger = require('../utils/logger');

/**
 * Trade Autopsy & Memory Learning Engine
 *
 * Performs deep post-trade diagnostic analysis for every closed trade:
 * - Maximum Favorable Excursion (MFE) in R
 * - Maximum Adverse Excursion (MAE) in R
 * - Stop Loss Tightness Diagnostic
 * - Take Profit Ambition Diagnostic
 * - Trailing Stop Efficiency Diagnostic
 * - Experience Recording & Setup Similarity Engine
 */
class TradeAutopsyEngine {

  /**
   * Run diagnostic autopsy on a closed trade
   * @param {object} trade - Closed trade record
   * @param {Array<object>} [candles] - Candle history during trade lifespan
   * @returns {object} Autopsy record
   */
  diagnoseTrade(trade, candles = []) {
    const entry = parseFloat(trade.entry || 0);
    const sl = parseFloat(trade.stopLoss || trade.stop_loss || entry);
    const tp = parseFloat(trade.takeProfit || trade.take_profit || entry);
    const exitPrice = parseFloat(trade.exitPrice || trade.exit_price || entry);
    const pnl = parseFloat(trade.pnl || 0);
    const direction = trade.direction || 'LONG';
    const positionSize = parseFloat(trade.positionSize || trade.position_size || 1);
    const outcome = trade.outcome || (pnl > 0 ? 'WIN' : (pnl < 0 ? 'LOSS' : 'BREAKEVEN'));

    const riskPerUnit = Math.abs(entry - sl);
    const totalRisk = riskPerUnit * positionSize;
    const rMultiple = totalRisk > 0 ? parseFloat((pnl / totalRisk).toFixed(2)) : (pnl >= 0 ? 1 : -1);

    // MFE and MAE calculation from candle history if available, else from exit / levels
    let mfe = 0;
    let mae = 0;

    if (candles && candles.length > 0) {
      if (direction === 'LONG') {
        const peakHigh = Math.max(...candles.map(c => c.high));
        const troughLow = Math.min(...candles.map(c => c.low));
        mfe = Math.max(0, peakHigh - entry);
        mae = Math.max(0, entry - troughLow);
      } else {
        const troughLow = Math.min(...candles.map(c => c.low));
        const peakHigh = Math.max(...candles.map(c => c.high));
        mfe = Math.max(0, entry - troughLow);
        mae = Math.max(0, peakHigh - entry);
      }
    } else {
      // Fallback heuristics based on exit price and outcome
      if (outcome === 'WIN') {
        mfe = Math.abs(exitPrice - entry);
        mae = riskPerUnit * 0.3;
      } else {
        mfe = riskPerUnit * 0.4;
        mae = Math.abs(exitPrice - entry);
      }
    }

    const mfeR = riskPerUnit > 0 ? parseFloat((mfe / riskPerUnit).toFixed(2)) : 0;
    const maeR = riskPerUnit > 0 ? parseFloat((mae / riskPerUnit).toFixed(2)) : 0;

    // Diagnostic Classifications
    let slTightness = 'OPTIMAL';
    let tpAmbition = 'REALISTIC';
    let trailingEfficiency = 'NEUTRAL';
    const lessons = [];

    // 1. SL Tightness
    if (outcome === 'LOSS' && mfeR >= 1.2) {
      slTightness = 'TOO_TIGHT';
      lessons.push('Trade reached > 1.2R in favor before reversing to SL; consider locking breakeven earlier or widening initial SL');
    } else if (outcome === 'LOSS' && mfeR < 0.2 && maeR >= 0.95) {
      slTightness = 'PRECISE_HIT';
      lessons.push('Immediate adverse move into SL; setup lacked initial buyer/seller momentum');
    }

    // 2. TP Ambition
    if (mfeR >= 2.0 && outcome !== 'WIN') {
      tpAmbition = 'OVER_AMBITIOUS';
      lessons.push('Price exceeded 2.0R favorable excursion but failed to reach target; consider partial scaling');
    } else if (outcome === 'WIN' && mfeR > (rMultiple + 1.5)) {
      tpAmbition = 'CONSERVATIVE';
      lessons.push('Trade exited early at TP while move continued for > 1.5R additional excursion');
    }

    // 3. Trailing Stop Efficiency
    const exitReason = (trade.exitReason || trade.exit_reason || '').toUpperCase();
    if (exitReason.includes('TRAILING')) {
      if (pnl > 0) {
        trailingEfficiency = 'PROTECTIVE';
        lessons.push('Trailing stop successfully secured profit after trend extension');
      } else {
        trailingEfficiency = 'PREMATURE_CUT';
        lessons.push('Trailing stop triggered at minor pullback before target');
      }
    }

    const autopsy = {
      id: `autopsy-${trade.id || Date.now()}`,
      tradeId: String(trade.id || `trade-${Date.now()}`),
      symbol: trade.symbol,
      strategyId: trade.strategyId || trade.strategy_id || 'unknown',
      direction,
      regime: trade.regime || 'UNKNOWN',
      outcome,
      pnl: parseFloat(pnl.toFixed(4)),
      rMultiple,
      mfe: parseFloat(mfe.toFixed(6)),
      mae: parseFloat(mae.toFixed(6)),
      mfeR,
      maeR,
      slTightness,
      tpAmbition,
      trailingEfficiency,
      lessons,
      createdAt: Date.now(),
    };

    // Persist autopsy
    try {
      journal.saveAutopsy(autopsy);
      logger.info(`Autopsy recorded for trade ${autopsy.tradeId}: ${outcome} (${rMultiple}R) | SL: ${slTightness} | TP: ${tpAmbition}`);
    } catch (err) {
      logger.error(`Failed to save autopsy for ${autopsy.tradeId}: ${err.message}`);
    }

    // Emit event
    eventBus.emitEvent('trade.autopsy.completed', autopsy);

    return autopsy;
  }

  /**
   * Find historical similarity match for a new setup candidate
   * @param {object} opportunity - { symbol, strategyId, direction, regime }
   * @param {number} [limit=10]
   * @returns {object} Historical performance match
   */
  findSimilarSetups(opportunity, limit = 20) {
    const autopsies = journal.getAutopsies(100);
    if (!autopsies || autopsies.length === 0) {
      return {
        sampleSize: 0,
        winRate: 0,
        avgR: 0,
        confidence: 'LOW_SAMPLE',
        recommendation: 'PROCEED_WITH_STANDARD_RISK',
      };
    }

    const matched = autopsies.filter(a => {
      const matchStrat = !opportunity.strategyId || a.strategyId === opportunity.strategyId;
      const matchDir = !opportunity.direction || a.direction === opportunity.direction;
      const matchRegime = !opportunity.regime || a.regime === (opportunity.regime?.canonicalRegime || opportunity.regime);
      return matchStrat && (matchDir || matchRegime);
    }).slice(0, limit);

    if (matched.length === 0) {
      return {
        sampleSize: 0,
        winRate: 0,
        avgR: 0,
        confidence: 'NO_PRIOR_MATCHES',
        recommendation: 'EXECUTE_BY_RULEBOOK',
      };
    }

    const wins = matched.filter(a => a.outcome === 'WIN').length;
    const winRate = parseFloat(((wins / matched.length) * 100).toFixed(1));
    const totalR = matched.reduce((sum, a) => sum + (a.rMultiple || 0), 0);
    const avgR = parseFloat((totalR / matched.length).toFixed(2));

    let recommendation = 'STANDARD_EXECUTION';
    if (matched.length >= 5 && winRate >= 65 && avgR >= 0.8) {
      recommendation = 'HIGH_HISTORICAL_EDGE';
    } else if (matched.length >= 5 && winRate < 40) {
      recommendation = 'CAUTION_LOW_HISTORICAL_WINRATE';
    }

    return {
      sampleSize: matched.length,
      winRate,
      avgR,
      confidence: matched.length >= 5 ? 'MEDIUM_HIGH' : 'LOW_SAMPLE',
      recommendation,
      recentMatches: matched.slice(0, 5),
    };
  }
}

// Singleton instance
const autopsyEngine = new TradeAutopsyEngine();

module.exports = {
  TradeAutopsyEngine,
  autopsyEngine,
};
